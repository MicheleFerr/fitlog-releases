# 📚 GymBro Documentation Index

**Last Updated**: October 21, 2025
**Version**: 2.0 (Cleaned & Consolidated)

---

## 🚀 START HERE

### For AI Assistants (Claude, Copilot, etc.)
**⚠️ MANDATORY**: Read [`CLAUDE.md`](../../CLAUDE.md) (30 min) before making ANY code changes
- Multilingua rules (context.l10n)
- Theme rules (context.colors)
- Architecture patterns (Riverpod, Clean Architecture)
- iOS-specific features (Live Activities, Apple Sign-In)
- Security rules (Firebase, input validation)
- Pre-commit checklist

### For New Developers
1. **Read First**: [`QUICK_REFERENCE.md`](./QUICK_REFERENCE.md) (15 min)
   - Where to find everything in this codebase
   - Quick commands and common tasks

2. **Understand Architecture**: [`EXERCISE_DATABASE_SYNC_ARCHITECTURE.md`](./EXERCISE_DATABASE_SYNC_ARCHITECTURE.md) (30 min)
   - High-level system design
   - Data flow and storage strategy

3. **Pick Your Path**:
   - Working on **Exercises** → Start with Exercise section below
   - Working on **Workouts** → Start with Workout section below
   - Working on **Setup/Config** → Start with Setup section below

### For Resuming After Break
```bash
# 1. Check current progress
cat docs/IMPLEMENTATION_STATUS.json | jq '.current_phase, .overall_progress_percent'

# 2. Open quick reference
open docs/QUICK_REFERENCE.md

# 3. Jump to your feature section below
```

---

## 📂 Documentation Structure

### 🤖 AI ASSISTANT RULES
**⚠️ MANDATORY READ FOR ALL AI ASSISTANTS (Claude, Copilot, etc.)**

| Document | Purpose | Location | Audience |
|----------|---------|----------|----------|
| [`CLAUDE.md`](../../CLAUDE.md) | **OBBLIGATORIO**: Regole, linee guida e best practices per AI che lavorano su questo progetto | Root project | AI Assistants, All Developers |

**Key Topics in CLAUDE.md**:
- Multilingua obbligatorio (context.l10n)
- Tema scuro/chiaro (context.colors)
- Architettura Riverpod patterns
- iOS-specific features (Live Activities, Sign in with Apple)
- Firebase & sicurezza
- Performance & memoria
- Testing & debugging
- BuildContext Extensions (regole FASE 1)
- Componenti unificati (LoadingIndicator, SnackBarService, ModalService)
- Documentazione feature-specific (Workout, Exercise Card, Exercise Insertion)
- Git & versioning rules

### 📈 PRODUCT STRATEGY & MARKET ANALYSIS
**Critical Reference Documents for Product Direction**

| Document | Purpose | Audience | Read Time |
|----------|---------|----------|----------|
| [`../STRATEGY/MARKET_AND_RETENTION_STRATEGY.md`](../STRATEGY/MARKET_AND_RETENTION_STRATEGY.md) | **Complete market analysis, retention strategy, UX principles, GDPR compliance, conversion funnel design** | All (especially PM/Product), Dev Leads | 45 min |

**Key Topics**:
- Market sizing (USD 10.59B → USD 33.58B by 2033, 25% CAGR)
- Retention crisis: 77% churn by Day 3, only 25% reach Day 30
- 4 user personas with retention rates and messaging strategies
- Push notification ROI: 820% higher retention with daily+ notifications
- Freemium-to-Premium conversion (14-day trial, 25-35% conversion target)
- GDPR compliance checklist (Critical for EU launch)
- First 90 days implementation plan
- Competitive differentiation vs MyFitnessPal, Strava, Strong
- Success metric: **20% Day 30 retention** (vs 10% industry average)

---

### 🔒 SECURITY & AUDITS

| Document | Purpose | Audience | Last Audit |
|----------|---------|----------|------------|
| [`SECURITY_AUDIT_2025-01-18.md`](../security/SECURITY_AUDIT_2025-01-18.md) | **LATEST** Comprehensive security audit with detailed findings and remediation plans | All developers, DevOps | Jan 18, 2025 |
| [`SECURITY_IMPLEMENTATION_CHECKLIST.md`](../security/SECURITY_IMPLEMENTATION_CHECKLIST.md) | Step-by-step implementation checklist for security fixes | Developers implementing fixes | Jan 18, 2025 |

**Latest Audit Summary** (Jan 18, 2025):
- **Overall Risk**: ⚠️ MEDIUM → ✅ LOW (after fixes)
- **1 CRITICAL**: Unencrypted sensitive data storage (Hive boxes)
- **2 MEDIUM**: Missing input length limits, range validation
- **10 FIXED**: Print statements secured with kDebugMode
- **Total Effort Required**: ~4-5 hours to implement all fixes

**Quick Start**: Read `SECURITY_IMPLEMENTATION_CHECKLIST.md` for step-by-step implementation

### 🏗️ ARCHITECTURE & FUNDAMENTALS
| Document | Purpose | Audience | Read Time |
|----------|---------|----------|-----------|
| [`EXERCISE_DATABASE_SYNC_ARCHITECTURE.md`](./EXERCISE_DATABASE_SYNC_ARCHITECTURE.md) | System design, data flow, storage strategy | All developers | 30 min |
| [`HYBRID_ARCHITECTURE.md`](./HYBRID_ARCHITECTURE.md) | Local-first + cloud-sync pattern | Backend/Storage devs | 20 min |
| [`EXERCISE_FEEDBACK_SYSTEM_ARCHITECTURE.md`](./EXERCISE_FEEDBACK_SYSTEM_ARCHITECTURE.md) | Admin feedback system, user submissions, real-time sync | All developers | 45 min |
| [`WORKOUT_SYSTEM_OVERVIEW.md`](./WORKOUT_SYSTEM_OVERVIEW.md) | Non-technical overview of workout flow | PM/Designers/Devs | 15 min |
| [`EXERCISE_CARD_SYSTEM_OVERVIEW.md`](./EXERCISE_CARD_SYSTEM_OVERVIEW.md) | Non-technical overview of exercise UI | PM/Designers/Devs | 15 min |
| [`EXERCISE_INSERTION_SYSTEM_OVERVIEW.md`](./EXERCISE_INSERTION_SYSTEM_OVERVIEW.md) | Non-technical overview of insertion flow | PM/Designers/Devs | 15 min |
| **[`HIVE_BOX_MANAGER_MIGRATION_REPORT.md`](../TECHNICAL_FOUNDATION/HIVE_BOX_MANAGER_MIGRATION_REPORT.md)** | **✅ Complete migration report: HiveBoxManager centralized pattern (68+ calls)** | **All developers** | **20 min** |
| **[`HIVE_BOX_MANAGER_CHECKLIST.md`](../TECHNICAL_FOUNDATION/HIVE_BOX_MANAGER_CHECKLIST.md)** | **🚨 Mandatory checklist for all Hive storage (prevents memory leaks)** | **All developers** | **10 min** |

### 🏋️ APRE SYSTEM DOCUMENTATION
**⚠️ Complete documentation for APRE (Auto-Regulated Progressive Resistance Exercise) system**

| Document | Purpose | Audience | Read Time |
|----------|---------|----------|-----------|
| [`APRE_INDEX.md`](../APRE/APRE_INDEX.md) | **START HERE** - Navigation guide for all APRE docs | All | 10 min |
| [`APRE_QUICK.md`](../APRE/APRE_QUICK.md) | **TL;DR** - 2-minute summary: 4 problems + 4 solutions | All | 2 min |
| [`APRE_EXECUTIVE.md`](../APRE/APRE_EXECUTIVE.md) | Strategic overview, ROI analysis, implementation timeline | PM/Stakeholders | 15 min |
| [`APRE_SYSTEM_EXPLORATION.md`](../APRE/APRE_SYSTEM_EXPLORATION.md) | Complete system exploration: 15 files analyzed, workflows, learning path | Developers | 30 min |
| [`APRE_INTEGRATION_MAP.md`](../APRE/APRE_INTEGRATION_MAP.md) | Architecture diagrams, data flow, state dependencies, debugging | Developers | 25 min |
| [`APRE_MIGLIORAMENTI.md`](../APRE/APRE_MIGLIORAMENTI.md) | **Detailed solutions** with complete Dart code examples | Developers | 40 min |
| [`APRE_CASI_USO.md`](../APRE/APRE_CASI_USO.md) | Real scenarios, flowcharts, test cases | Developers/QA | 30 min |
| [`APRE_ACTION_ITEMS.md`](../APRE/APRE_ACTION_ITEMS.md) | **Implementation roadmap** - 17 tasks with timing and code | Developers/Team Lead | 45 min |

**Total Documentation**: 8 files, 36+ pages, ~12 hours implementation

**Key Problems Addressed**:
1. 🔍 **Transparency** - 1RM calculation "black box" → metadata display
2. 🛡️ **Robustness** - No history crash → manual input modal
3. 🎨 **UX Clarity** - Protocol change silent → validation + warnings
4. 📊 **Configurability** - Hardcoded "top 10" → flexible config

### 💻 IMPLEMENTATION GUIDES (ROE - Rules of Engagement)
These are **mandatory** before implementing features in their domain:

| Document | Domain | Must Read? | Implementation Time |
|----------|--------|-----------|------------------|
| [`EXERCISE_IMPLEMENTATION_PLAYBOOK.md`](./EXERCISE_IMPLEMENTATION_PLAYBOOK.md) | Exercise Database (Phases 1-4) | ✅ YES | 2-3 hours |
| [`EXERCISE_CARD_DEVELOPMENT_GUIDE.md`](./EXERCISE_CARD_DEVELOPMENT_GUIDE.md) | Exercise UI Components | ✅ YES (if modifying cards) | 90 min |
| [`EXERCISE_INSERTION_DEVELOPMENT_GUIDE.md`](./EXERCISE_INSERTION_DEVELOPMENT_GUIDE.md) | Exercise Modal/Insertion | ✅ YES (if modifying insertion) | 2 hours |
| [`EXERCISE_INSERTION_CUSTOMIZATION_GUIDE.md`](./EXERCISE_INSERTION_CUSTOMIZATION_GUIDE.md) | Exercise Toggles & Settings | ✅ YES (if adding toggles) | 1 hour |
| [`WORKOUT_FEATURE_DEVELOPMENT_GUIDE.md`](./WORKOUT_FEATURE_DEVELOPMENT_GUIDE.md) | Workout Features | ✅ YES (if modifying workouts) | 2 hours |
| [`EXERCISE_FEEDBACK_DEV_GUIDE.md`](./EXERCISE_FEEDBACK_DEV_GUIDE.md) | Exercise Feedback System | ✅ YES (if modifying feedback) | 15 min (quick) + 45 min (full) |
| [`DROPSET_RESTPAUSE_WORKFLOWS.md`](./DROPSET_RESTPAUSE_WORKFLOWS.md) | Advanced Exercise Types | Reference | 45 min |

### 🎓 KNOWLEDGE BASES (Reference & Troubleshooting)
Use these to understand specific systems:

| Document | Subject | Use When |
|----------|---------|----------|
| [`TIMER_AUDIO_KB.md`](./TIMER_AUDIO_KB.md) | Timer system & audio playback | Debugging timer/audio issues |
| [`LIVE_ACTIVITY_KB.md`](./LIVE_ACTIVITY_KB.md) | iOS Live Activities system | Implementing/fixing Live Activities |
| [`NOTIFICATION_SYSTEM_KB.md`](./NOTIFICATION_SYSTEM_KB.md) | Notification flows & triggers (v1.0) | Debugging notification issues |
| [`../features/notifications/NOTIFICATION_SYSTEM_V2_COMPLETE_DOCUMENTATION.md`](../features/notifications/NOTIFICATION_SYSTEM_V2_COMPLETE_DOCUMENTATION.md) | **Notification System v2.0** (GDPR, cross-device sync, frequency caps) | Implementing v2.0 features |
| [`ERROR_KB.md`](./ERROR_KB.md) | Common errors & solutions | When you hit a build/runtime error |

### 🔧 SETUP & CONFIGURATION
These cover initial setup and configuration:

| Document | Topic | For Whom |
|----------|-------|----------|
| [`LOCALIZATION_GUIDE.md`](./LOCALIZATION_GUIDE.md) | i18n/l10n patterns & best practices | All developers |
| [`FIREBASE_APP_CHECK_SETUP.md`](./FIREBASE_APP_CHECK_SETUP.md) | Firebase security setup | DevOps/Backend |
| [`PRODUCTION_LOGGING_GUIDE.md`](./PRODUCTION_LOGGING_GUIDE.md) | Logging standards (debugPrint, kDebugMode) | All developers |
| [`PERFORMANCE_OPTIMIZATIONS.md`](./PERFORMANCE_OPTIMIZATIONS.md) | Performance best practices | All developers |
| [`IAP_SETUP_GUIDE.md`](./IAP_SETUP_GUIDE.md) | In-App Purchases (if needed) | Payment systems |

### 📊 PROJECT TRACKING
| Document | Purpose |
|----------|---------|
| [`IMPLEMENTATION_STATUS.json`](./IMPLEMENTATION_STATUS.json) | Current progress on Exercise Database project |

### 📱 PLATFORM-SPECIFIC
| Document | Platform | Topic |
|----------|----------|-------|
| [`ios_native_error_analysis.md`](./ios_native_error_analysis.md) | iOS | Native error debugging reference |
| [`ANDROID_TIMER_INTEGRATION.md`](./ANDROID_TIMER_INTEGRATION.md) | Android | Timer integration specifics |

---

## 🎯 Quick Navigation by Task

### "I want to implement a new feature..."

**Exercise-Related Feature**:
1. Read: [`EXERCISE_IMPLEMENTATION_PLAYBOOK.md`](./EXERCISE_IMPLEMENTATION_PLAYBOOK.md)
2. Reference: [`EXERCISE_CARD_DEVELOPMENT_GUIDE.md`](./EXERCISE_CARD_DEVELOPMENT_GUIDE.md)
3. Reference: [`EXERCISE_INSERTION_DEVELOPMENT_GUIDE.md`](./EXERCISE_INSERTION_DEVELOPMENT_GUIDE.md)

**Workout-Related Feature**:
1. Read: [`WORKOUT_FEATURE_DEVELOPMENT_GUIDE.md`](./WORKOUT_FEATURE_DEVELOPMENT_GUIDE.md)
2. Reference: [`WORKOUT_SYSTEM_OVERVIEW.md`](./WORKOUT_SYSTEM_OVERVIEW.md)

**Timer/Audio Feature**:
1. Reference: [`TIMER_AUDIO_KB.md`](./TIMER_AUDIO_KB.md)
2. Reference: [`EXERCISE_DATABASE_SYNC_ARCHITECTURE.md`](./EXERCISE_DATABASE_SYNC_ARCHITECTURE.md)

**Live Activity Feature (iOS)**:
1. Reference: [`LIVE_ACTIVITY_KB.md`](./LIVE_ACTIVITY_KB.md)
2. Reference: [`ios_native_error_analysis.md`](./ios_native_error_analysis.md)

**Notification Feature**:
1. Reference: [`NOTIFICATION_SYSTEM_KB.md`](./NOTIFICATION_SYSTEM_KB.md)

**Admin Feedback System (User Submissions & Reviews)**:
1. Read: [`EXERCISE_FEEDBACK_SYSTEM_ARCHITECTURE.md`](./EXERCISE_FEEDBACK_SYSTEM_ARCHITECTURE.md)
2. Reference: [`EXERCISE_DATABASE_SYNC_ARCHITECTURE.md`](./EXERCISE_DATABASE_SYNC_ARCHITECTURE.md) (parent system)

**APRE System (Auto-Regulated Progressive Resistance)**:
1. Start: [`APRE_INDEX.md`](../APRE/APRE_INDEX.md) - Navigation guide
2. Quick read: [`APRE_QUICK.md`](../APRE/APRE_QUICK.md) - 2-min summary
3. Understand: [`APRE_SYSTEM_EXPLORATION.md`](../APRE/APRE_SYSTEM_EXPLORATION.md) - Complete system analysis
4. Implement: [`APRE_ACTION_ITEMS.md`](../APRE/APRE_ACTION_ITEMS.md) - Roadmap with code
5. Test: [`APRE_CASI_USO.md`](../APRE/APRE_CASI_USO.md) - Scenarios & test cases

**Routine Center & Smart Workout CTA**:
1. **🆕 START HERE**: [`UX_FLOWS/routine_center/ROUTINE_CENTER_V2_IMPLEMENTATION.md`](../UX_FLOWS/routine_center/ROUTINE_CENTER_V2_IMPLEMENTATION.md) - ✅ **v2.0 Complete Implementation** (Jan 2025, 37/37 tasks, 100% test coverage)
   - FlexibleRoutine entity (12 fields, 67% complexity reduction)
   - 5 preset templates (PPL, Upper/Lower, Full Body, Bro Split, Custom)
   - Smart template scoring (Jaccard similarity 0.0-1.0)
   - 111 tests (Unit + Widget + Integration + E2E)
   - Full localization (EN + IT, 23 keys)
2. **🎨 NEW**: [`UX_FLOWS/routine_center/FASE_1_PRESET_TEMPLATES_UI_ENHANCEMENT.md`](../UX_FLOWS/routine_center/FASE_1_PRESET_TEMPLATES_UI_ENHANCEMENT.md) - ✅ **FASE 1 Complete** (Jan 2025, 5 tasks, design system compliant)
   - Enhanced preset cards with gradient headers
   - Difficulty badges (Beginner/Intermediate/Advanced)
   - Duration estimates + frequency display
   - Localized descriptions (EN + IT, 5 keys)
   - Full Material 3 design system compliance
3. Read: [`UX_FLOWS/routine_center/SMART_WORKOUT_CTA_SYSTEM_REPORT.md`](../UX_FLOWS/routine_center/SMART_WORKOUT_CTA_SYSTEM_REPORT.md) - **Current system** (FlexibleRoutine-based, Nov 2025)
4. Reference: [`UX_FLOWS/routine_center/ROUTINE_CENTER_SYSTEM_REPORT.md`](../UX_FLOWS/routine_center/ROUTINE_CENTER_SYSTEM_REPORT.md) - Routine architecture
5. **SIMPLIFIED**: [`UX_FLOWS/routine_center/WORKOUT_SUGGESTION_SIMPLIFIED_ARCHITECTURE.md`](../UX_FLOWS/routine_center/WORKOUT_SUGGESTION_SIMPLIFIED_ARCHITECTURE.md) - ✅ **Simplified 2-level system** (Nov 2024, -211 lines, zero dependencies)
6. Reference: [`UX_FLOWS/routine_center/ROUTINE_CENTER_IMPROVEMENTS_PLAN.md`](../UX_FLOWS/routine_center/ROUTINE_CENTER_IMPROVEMENTS_PLAN.md) - Future improvements
7. Historical: [`UX_FLOWS/routine_center/WORKOUT_SUGGESTION_SYSTEM_REPORT_DEPRECATED.md`](../UX_FLOWS/routine_center/WORKOUT_SUGGESTION_SYSTEM_REPORT_DEPRECATED.md) - ⚠️ OLD 4-level system (deprecated Oct 2025)

**AI Coach Feature (Feature Gating System)**:
1. Read: [`AI_COACH_COMPREHENSIVE_DOCUMENTATION.md`](../AI_COACH_COMPREHENSIVE_DOCUMENTATION.md) - **Complete system** (800+ lines, Jan 2025)
   - Architecture: Clean Architecture with Domain/Data/Presentation layers
   - Entities: FeatureGateConfig, UserContext, FeatureGateStatus (8 features)
   - Repositories: FeatureGateRepository with AND rule logic
   - Providers: FeatureGateProvider (Riverpod state management)
   - Testing: 40 unit tests (21 entity + 19 repository)
   - Features: Progressive unlock (beginner → intermediate → advanced)
2. Reference: [`AI_COACH_USER_SCENARIOS.md`](../AI_COACH_USER_SCENARIOS.md) - **User scenarios & use cases** (1,000+ lines, Jan 2025)
   - 3 user personas (Marco/Sofia/Luca: beginner/intermediate/advanced)
   - 5 detailed use cases with UI mockups
   - 2 complete user journeys (90-day progression)
   - Edge cases, metrics, consultant review questions
3. **Critical**: [`AI_COACH_CRITICAL_IMPLEMENTATION_GUIDE.md`](../AI_COACH_CRITICAL_IMPLEMENTATION_GUIDE.md) - **Implementation priorities & GDPR compliance** (1,000+ lines, Jan 2025)
   - Top 3 priorities with ROI impact (unlock timing, persistence, error handling)
   - Health data integration analysis (HealthKit vs Health Connect, +61% D30 retention)
   - GDPR compliance requirements (Articles 9, 17, 20, 32) with code examples
   - 6-week implementation roadmap
   - Expected results table (+60% D7, +61% D30, +153% D90 retention)
   - 30+ references to market research and compliance docs
4. **Implementation Plan** 🆕: [`../plans/2025-11-16-ai-coach-optimizations-plan.md`](../plans/2025-11-16-ai-coach-optimizations-plan.md) - **53 atomic tasks for P0-P1 optimizations** (Jan 2025)
   - P0 Quick Wins: 12 tasks, ~12h (Firebase optimization, polling strategy, unlock timing)
   - P1 Strategic: 20 tasks, ~40h (HealthKit + Health Connect integration)
   - P1 Polish: 21 tasks, ~24h (Recovery insights, GDPR breach plan, consent separation)
   - Total: 53 tasks, ~76h (9.5 days)
   - Generated via task-master.dev with verified ROI metrics

### "I'm hitting an error..."

1. Check: [`ERROR_KB.md`](./ERROR_KB.md) - Common solutions
2. Check relevant KB:
   - Timer issues → [`TIMER_AUDIO_KB.md`](./TIMER_AUDIO_KB.md)
   - Live Activity issues → [`LIVE_ACTIVITY_KB.md`](./LIVE_ACTIVITY_KB.md)
   - Notification issues → [`NOTIFICATION_SYSTEM_KB.md`](./NOTIFICATION_SYSTEM_KB.md)
3. Check platform-specific guide:
   - iOS → [`ios_native_error_analysis.md`](./ios_native_error_analysis.md)
   - Android → [`ANDROID_TIMER_INTEGRATION.md`](./ANDROID_TIMER_INTEGRATION.md)

### "I need to add translations..."

1. Read: [`LOCALIZATION_GUIDE.md`](./LOCALIZATION_GUIDE.md)

### "I need to optimize performance..."

1. Read: [`PERFORMANCE_OPTIMIZATIONS.md`](./PERFORMANCE_OPTIMIZATIONS.md)

### "I'm setting up the project..."

1. **AI Assistants**: Read [`CLAUDE.md`](../../CLAUDE.md) (MANDATORY)
2. Start: [`QUICK_REFERENCE.md`](./QUICK_REFERENCE.md)
3. Check: [`FIREBASE_APP_CHECK_SETUP.md`](./FIREBASE_APP_CHECK_SETUP.md)
4. Setup logging: [`PRODUCTION_LOGGING_GUIDE.md`](./PRODUCTION_LOGGING_GUIDE.md)

### "I need to review security..."

1. Read: [`SECURITY_AUDIT_2025-10-20.md`](../audit/SECURITY_AUDIT_2025-10-20.md)
2. Check remediation roadmap (Sprint 1-3 priorities)
3. Review Firestore security rules: `firestore.rules`

---

## 📋 Complete File List (by category)

### AI Assistant Rules & Security (Critical)
- `../../CLAUDE.md` 🤖 ⭐ **MANDATORY for all AI assistants**
- `../audit/SECURITY_AUDIT_2025-10-20.md` 🔒

### Getting Started (Read These First)
- `QUICK_REFERENCE.md` ⭐
- `EXERCISE_DATABASE_SYNC_ARCHITECTURE.md` ⭐

### System Overviews (Non-Technical)
- `EXERCISE_CARD_SYSTEM_OVERVIEW.md`
- `EXERCISE_INSERTION_SYSTEM_OVERVIEW.md`
- `WORKOUT_SYSTEM_OVERVIEW.md`

### Implementation Guides (Technical)
- `EXERCISE_IMPLEMENTATION_PLAYBOOK.md`
- `EXERCISE_CARD_DEVELOPMENT_GUIDE.md`
- `EXERCISE_INSERTION_DEVELOPMENT_GUIDE.md`
- `EXERCISE_INSERTION_CUSTOMIZATION_GUIDE.md`
- `WORKOUT_FEATURE_DEVELOPMENT_GUIDE.md`
- `EXERCISE_FEEDBACK_DEV_GUIDE.md`
- `DROPSET_RESTPAUSE_WORKFLOWS.md`

### Knowledge Bases
- `TIMER_AUDIO_KB.md`
- `LIVE_ACTIVITY_KB.md`
- `NOTIFICATION_SYSTEM_KB.md`
- `ERROR_KB.md`

### UX Flows & System Reports

#### 📊 Analytics System
- `UX_FLOWS/analytics/ANALYTICS_SYSTEM_OVERVIEW.md` ✅ **NEW!** 🎯 **START HERE** (Complete Analytics System - v2.0, Muscle Distribution, Streak Calendar, Volume Modals, Jan 2025)
- `UX_FLOWS/analytics/MUSCLE_DISTRIBUTION_DOCUMENTATION.md` ✅ **NEW!** (Muscle Distribution with Radar Chart - 6 muscle groups, time period filtering, comparison, Jan 2025)
- `UX_FLOWS/analytics/STREAK_MODAL_DOCUMENTATION.md` ✅ **NEW!** (GitHub-style Calendar - Monthly view, streak tracking, milestone animations, Jan 2025)
- `UX_FLOWS/analytics/VOLUME_MODAL_DOCUMENTATION.md` ✅ **NEW!** (Weekly Volume Breakdown - Bar chart, top exercises, trend indicators, Jan 2025)

#### 🏋️ Routine Center
- `UX_FLOWS/routine_center/ROUTINE_CENTER_V2_IMPLEMENTATION.md` ✅ **NEW!** 🎯 **START HERE** (v2.0 Complete Implementation - 37/37 tasks, 100% test coverage, Jan 2025)
- `UX_FLOWS/routine_center/SMART_WORKOUT_CTA_SYSTEM_REPORT.md` 🎯 **UPDATED!** (Smart Workout CTA - FlexibleRoutine-based system, Nov 2025)
- `UX_FLOWS/routine_center/ROUTINE_CENTER_SYSTEM_REPORT.md` 📋 (Routine Center architecture & complete system)
- `UX_FLOWS/routine_center/WORKOUT_SUGGESTION_SIMPLIFIED_ARCHITECTURE.md` ✅ **NEW!** (Simplified 2-level prediction system, Nov 2024, -211 lines, zero deps)
- `UX_FLOWS/routine_center/ROUTINE_CENTER_IMPROVEMENTS_PLAN.md` 🚀 (Future improvements: Pattern detection, multi-level suggestions)
- `UX_FLOWS/routine_center/WORKOUT_TEMPLATES_SCREEN_REPORT.md` 📋 (Templates screen architecture & flow analysis)
- `UX_FLOWS/routine_center/WORKOUT_TEMPLATES_SCREEN_IMPROVEMENT_REPORT.md` 🔧 (Improvement plan for AI consultants)
- `UX_FLOWS/routine_center/WORKOUT_TEMPLATES_SCREEN_COMPLIANCE_SECURITY_REPORT.md` 🔒 (Compliance & security audit: WCAG 2.2, OWASP, GDPR)
- `UX_FLOWS/routine_center/UNUSED_TEMPLATE_SCREENS_AUDIT.md` 🔍 (Dead code audit: 3 unused template screens - COMPLETED)
- `UX_FLOWS/routine_center/WORKOUT_SUGGESTION_SYSTEM_REPORT_DEPRECATED.md` ⚠️ **DEPRECATED** (Old frequency-based system, Oct 2025 - historical reference only)

### Architecture & Design
- `EXERCISE_DATABASE_SYNC_ARCHITECTURE.md`
- `HYBRID_ARCHITECTURE.md`
- `EXERCISE_FEEDBACK_SYSTEM_ARCHITECTURE.md`

### Setup & Config
- `LOCALIZATION_GUIDE.md`
- `FIREBASE_APP_CHECK_SETUP.md`
- `PRODUCTION_LOGGING_GUIDE.md`
- `PERFORMANCE_OPTIMIZATIONS.md`
- `IAP_SETUP_GUIDE.md`

### Platform-Specific
- `ios_native_error_analysis.md`
- `ANDROID_TIMER_INTEGRATION.md`

### Project Tracking
- `IMPLEMENTATION_STATUS.json`

---

## 🔄 How to Use This Index

### When Starting New Work
1. **Go to "Quick Navigation by Task"** section above
2. **Find your task type**
3. **Follow the reading order**
4. **Open the linked documents**

### When You Get Stuck
1. **Go to "I'm hitting an error..."** section
2. **Check ERROR_KB.md first**
3. **Then check relevant KB**
4. **Fallback to platform-specific guides**

### When Onboarding Developers
1. **Share this file** (INDEX.md)
2. **Point them to "START HERE"** section
3. **Let them pick their path** based on work
4. **Bookmark "Quick Navigation by Task"** for reference

---

## 📊 Documentation Statistics

- **Total active docs**: 29 files
- **Obsolete docs deleted**: 132 files
- **Documentation reduced**: 91% cleanup
- **Maintained categories**: 8 (AI Rules, Security, Architecture, Implementation, KB, Setup, Platform, Tracking)
- **Latest Additions**:
  - Workout Templates Compliance & Security Report (Oct 21, 2025) 🔒
  - Workout Suggestion System Report (Oct 21, 2025) 🎯
  - Security Audit Report (Oct 20, 2025) 🔒
  - AI Assistant Rules linked (Oct 20, 2025) 🤖
  - Exercise Feedback System Architecture (Oct 18, 2025)
  - Exercise Feedback Dev Guide (Oct 18, 2025)

---

## 🎯 Document Maintenance

### Keep Updated When
- Adding new features → Update relevant ROE guide
- Changing architecture → Update EXERCISE_DATABASE_SYNC_ARCHITECTURE.md or EXERCISE_FEEDBACK_SYSTEM_ARCHITECTURE.md
- Creating new error pattern → Add to ERROR_KB.md
- Implementing new system → Create new KB file
- Changing setup steps → Update QUICK_REFERENCE.md
- Modifying feedback system → Update EXERCISE_FEEDBACK_SYSTEM_ARCHITECTURE.md
- Adding AI rules/patterns → Update CLAUDE.md
- Security changes → Run new security audit, update docs/audit/

### Review Quarterly
- Security audit (run `/audit` command, update docs/audit/)
- Performance optimizations (real metrics)
- Error patterns (new common errors)
- Setup procedures (new tools/steps)
- Dependency updates (security patches)

---

## 💎 RETENTION FEATURES (P0-P4)
**Habit Formation & Engagement Systems**

### Overview
Retention-focused features implementing evidence-based habit formation strategies targeting 15-20% stickiness improvement.

| Priority | Feature | Status | Impact | Evidence |
|----------|---------|--------|--------|----------|
| **P0** | Workout Streak Counter | ✅ Implemented | +5-10% | Duolingo: 3.7x retention with streaks |
| **P1** | Exercise History & Templates | ✅ Implemented | +10-15% | Reduces friction, creates habits |
| **P2** | Progressive Overload Analyzer | ✅ Implemented | +10-15% | Transparent progression = trust |
| **P3** | Smart Notifications | ✅ Implemented | +15-20% | 48-hour nudge timing optimal |
| **P4** | Goal-Based Onboarding | ✅ Implemented | +10-15% | Personalization increases commitment |

### Feature Documentation

#### P0: Workout Streak Counter
- **Entity**: `WorkoutStreak` (Freezed, currentStreak, longestStreak)
- **Repository**: `StreakRepository` (getCurrentStreak, checkAndNotifyMilestone)
- **Provider**: `currentStreakProvider` (Riverpod)
- **UI**: Streak counter widget with fire emoji, progress bar
- **Notifications**: Milestone achievements (3, 7, 14, 30, 60 day streaks)

#### P1: Exercise History & Smart Templates
- **Use Case**: `GetRecentExercises` (last 7 days, grouped by exercise)
- **Entity**: `ExerciseTemplate` (Hive-based storage)
- **UI**: `QuickAddExerciseSheet` with smart set prefill
- **Logic**: Auto-fills sets/reps/weight from last successful workout

#### P2: Progressive Overload Intelligence
- **Use Case**: `AnalyzeProgression` (rule-based, no AI)
- **Entity**: `ProgressionSuggestion` (suggestedWeight, targetReps, confidence, reason)
- **UI**: `ProgressionSuggestionBanner` with visual confidence indicators
- **Rules**: Deterministic progression logic (transparent, explainable)

#### P3: Intelligent Notifications
- **Use Case**: `CheckNotificationRules` (4 transparent rules)
- **Use Case**: `ScheduleWorkoutReminders` (optimal timing calculation)
- **Entity**: `NotificationDecision` + `ScheduleResult`
- **Rules**:
  1. NO notification if worked out today
  2. NO notification if already notified today
  3. YES notification if 48+ hours since last workout
  4. Schedule for tomorrow if preferred time passed

#### P4: Goal-Oriented Onboarding
- **Entities**:
  - `UserGoal` (Freezed) - Domain entity for goal representation
  - `OnboardingState` (Hive, extended with P4 fields: `userGoal`, `weeklyWorkoutTarget`)
- **Enums**:
  - `GoalType` (buildMuscle, loseWeight, getStronger, stayFit)
  - `ExperienceLevel` (beginner, intermediate, advanced) - reuses existing field
- **Provider**: `OnboardingStateNotifier.selectGoal(goalType, weeklyTarget)` - persists goal selection
- **UI**: `GoalSelectionScreen` (ConsumerWidget, auto-navigates to home after selection)
- **Routing**: `/goal-selection` route with redirect logic (post-QuickStart, pre-home)
- **Default Targets**: Evidence-based weekly workout defaults (buildMuscle/loseWeight: 4x, getStronger/stayFit: 3x)

### Testing Status
- **All entity tests**: 11/11 passing (UserGoal 5/5, OnboardingState 6/6)
- **All use case tests**: 9/9 passing (CheckNotificationRules 5/5, ScheduleWorkoutReminders 4/4)
- **All widget tests**: 7/7 passing (ProgressionBanner 4/4, GoalSelection 3/3)
- **Total**: 27/27 tests passing across P0-P4 features

### Implementation Notes
- All domain entities use **Freezed** for immutability
- All timestamps use **DateTime** (no Firebase Timestamp in domain)
- All UI text uses **context.l10n** (fully localized)
- All colors use **context.colors** (theme-aware)
- All icons use **AppIcons.*** and **AppIconSize.*** (design system compliant)
- TDD workflow: RED → GREEN → REFACTOR → COMMIT (all features)

### Future Enhancements (Deferred)
- P4: Weekly goal selection screen (skeleton exists)
- P4: First workout guided tutorial (skeleton exists)
- P2: Machine learning-based progression (currently rule-based)
- P3: Adaptive notification timing based on user behavior
- P0: Social streak sharing (requires social features)

### Related Documentation
- Market Strategy: [`../STRATEGY/MARKET_AND_RETENTION_STRATEGY.md`](../STRATEGY/MARKET_AND_RETENTION_STRATEGY.md)
- Security Audit: [`../audit/SECURITY_AUDIT_2025-10-20.md`](../audit/SECURITY_AUDIT_2025-10-20.md)
- CLAUDE Rules: [`../../CLAUDE.md`](../../CLAUDE.md)

---

**Last Audit**: October 20, 2025
**Next Audit**: January 20, 2026
**Last Updated**: January 15, 2025 (Added P0-P4 Retention Features documentation)
