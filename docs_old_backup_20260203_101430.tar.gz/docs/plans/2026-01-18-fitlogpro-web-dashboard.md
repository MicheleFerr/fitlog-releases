# FitLog Pro Web Dashboard - Design Document

**Data**: 2026-01-18
**Versione**: 1.0
**Status**: Draft

---

## 1. Overview

### 1.1 Obiettivo
Creare una web dashboard per FitLog Pro che permetta agli utenti di visualizzare i propri workout e analytics da browser, con lo stesso account Firebase dell'app mobile.

### 1.2 Scope MVP
- Landing page marketing
- Autenticazione (login/register con Firebase Auth)
- Dashboard personale
- Lista workout completati
- Grafici analytics (peso, volume, reps, PR)
- Dettaglio per esercizio

### 1.3 Out of Scope (v1)
- Creazione/modifica workout
- Creazione template
- Coach portal
- Body measurements
- Progress photos

---

## 2. Tech Stack

### 2.1 Frontend
| Tecnologia | Versione | Motivo |
|------------|----------|--------|
| **Next.js** | 14.x | App Router, SSR, ottimo SEO |
| **React** | 18.x | Incluso in Next.js |
| **TypeScript** | 5.x | Type safety |
| **Tailwind CSS** | 3.x | Styling veloce, design system |
| **Tremor** | 3.x | Componenti dashboard (grafici, cards) |

### 2.2 Backend/Services
| Servizio | Uso |
|----------|-----|
| **Firebase Auth** | Autenticazione (stesso progetto app) |
| **Cloud Firestore** | Database (stesso progetto app) |
| **Vercel** | Hosting (free tier) |

### 2.3 Librerie Aggiuntive
```json
{
  "firebase": "^10.x",
  "react-firebase-hooks": "^5.x",
  "@tanstack/react-query": "^5.x",
  "date-fns": "^3.x",
  "zod": "^3.x"
}
```

---

## 3. Architettura

### 3.1 Struttura Progetto
```
fitlogpro-web/
├── app/
│   ├── (marketing)/          # Landing pages (public)
│   │   ├── page.tsx          # Home/Landing
│   │   ├── features/
│   │   └── pricing/
│   ├── (auth)/               # Auth pages
│   │   ├── login/
│   │   └── register/
│   ├── (dashboard)/          # Protected pages
│   │   ├── layout.tsx        # Dashboard layout with sidebar
│   │   ├── page.tsx          # Dashboard home
│   │   ├── workouts/
│   │   │   ├── page.tsx      # Lista workout
│   │   │   └── [id]/page.tsx # Dettaglio workout
│   │   ├── analytics/
│   │   │   └── page.tsx      # Grafici e stats
│   │   └── exercises/
│   │       └── [name]/page.tsx # Storico esercizio
│   └── api/                  # API routes (se necessarie)
├── components/
│   ├── ui/                   # Componenti base (Button, Card, etc.)
│   ├── dashboard/            # Componenti dashboard
│   ├── charts/               # Grafici
│   └── layout/               # Header, Sidebar, Footer
├── lib/
│   ├── firebase/             # Firebase config e hooks
│   ├── hooks/                # Custom React hooks
│   └── utils/                # Utilities
├── types/                    # TypeScript types
└── public/                   # Assets statici
```

### 3.2 Flusso Autenticazione
```
┌─────────────────────────────────────────────────────────────┐
│                      NEXT.JS APP                             │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  1. User visita /login                                       │
│  2. Firebase Auth JS SDK gestisce login                      │
│  3. onAuthStateChanged aggiorna stato                        │
│  4. Middleware Next.js protegge route /dashboard/*           │
│  5. Firestore queries usano uid per filtrare dati            │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

## 4. Pagine e Features

### 4.1 Landing Page (`/`)
**Obiettivo**: Convertire visitatori in download app

**Sezioni**:
- Hero: "Traccia i tuoi allenamenti" + screenshot app
- Features: 3-4 feature principali con icone
- Testimonials (opzionale)
- CTA: Link App Store / Play Store
- Footer: Legal links

### 4.2 Login (`/login`)
**Features**:
- Email/password login
- Google Sign-In
- "Password dimenticata" link
- Link a Register

### 4.3 Dashboard Home (`/dashboard`)
**Features**:
- Welcome message con nome utente
- Stats rapide (workout questa settimana, PR recenti)
- Ultimi 5 workout (mini lista)
- Quick links ad altre sezioni

**Query Firestore**:
```typescript
// Ultimi workout
const workoutsQuery = query(
  collection(db, 'workouts'),
  where('userId', '==', uid),
  where('status', '==', 'completed'),
  orderBy('endTime', 'desc'),
  limit(5)
);
```

### 4.4 Lista Workout (`/workouts`)
**Features**:
- Tabella/lista workout con:
  - Data
  - Nome workout
  - Durata
  - Numero esercizi
  - Volume totale
- Filtri: data range, nome
- Pagination (20 per pagina)
- Click → dettaglio

**Query Firestore**:
```typescript
const workoutsQuery = query(
  collection(db, 'workouts'),
  where('userId', '==', uid),
  where('status', '==', 'completed'),
  orderBy('endTime', 'desc'),
  limit(20)
);
```

### 4.5 Dettaglio Workout (`/workouts/[id]`)
**Features**:
- Header: nome, data, durata
- Lista esercizi con:
  - Nome esercizio
  - Set completati (peso x reps)
  - Volume per esercizio
- Note workout (se presenti)

### 4.6 Analytics (`/analytics`)
**Features**:
- Selezione periodo (1M, 3M, 6M, 1Y, All)
- Grafici:
  - Volume totale nel tempo (bar chart)
  - Frequenza allenamenti (calendar heatmap)
  - Top esercizi per volume (horizontal bar)
- Personal Records recenti

**Query Firestore**:
```typescript
// Workout nel periodo
const workoutsQuery = query(
  collection(db, 'workouts'),
  where('userId', '==', uid),
  where('status', '==', 'completed'),
  where('endTime', '>=', startDate),
  orderBy('endTime', 'desc')
);
```

### 4.7 Storico Esercizio (`/exercises/[name]`)
**Features**:
- Grafico peso nel tempo
- Grafico volume nel tempo
- Grafico reps nel tempo
- Tabella sessioni passate
- PR per questo esercizio

---

## 5. Struttura Dati Firestore

### 5.1 Collezioni Utilizzate

#### `/workouts/{workoutId}`
```typescript
interface Workout {
  id: string;
  userId: string;
  name: string;
  status: 'completed' | 'inProgress' | 'abandoned';
  createdAt: Timestamp;
  endTime?: Timestamp;
  exercises: WorkoutExercise[];
  notes?: string;
}

interface WorkoutExercise {
  exerciseId: string;
  name: string;
  sets: ExerciseSet[];
}

interface ExerciseSet {
  weight?: number;
  reps?: number;
  actualReps?: number;
  isCompleted: boolean;
  completedAt?: Timestamp;
}
```

#### `/users/{userId}`
```typescript
interface User {
  uid: string;
  email: string;
  displayName?: string;
  photoURL?: string;
  tier: 'free' | 'premium' | 'pro';
  createdAt: Timestamp;
}
```

---

## 6. Ottimizzazioni Costi

### 6.1 Caching Strategy
- **React Query**: cache 5 minuti per lista workout
- **staleTime**: 5 minuti per dati che cambiano raramente
- **Aggregazioni**: calcolare stats client-side da dati già fetchati

### 6.2 Query Limits
- Lista workout: max 20 per pagina
- Analytics: max 100 workout per calcoli
- Dettaglio: singolo documento

### 6.3 Stima Letture per Sessione
| Azione | Letture |
|--------|---------|
| Login + Dashboard | ~10 |
| Lista workout | ~20 |
| Dettaglio workout | ~1 |
| Analytics (3 mesi) | ~30 |
| **Totale sessione tipica** | **~60** |

Con cache, sessioni successive: ~10 letture.

---

## 7. Timeline

### Fase 1: Setup (2-3 giorni)
- [ ] Creare repo `fitlogpro-web`
- [ ] Setup Next.js + TypeScript + Tailwind
- [ ] Configurare Firebase
- [ ] Deploy iniziale su Vercel
- [ ] Landing page base

### Fase 2: Auth (2-3 giorni)
- [ ] Login page
- [ ] Register page
- [ ] Auth middleware
- [ ] Protected routes
- [ ] User context/provider

### Fase 3: Dashboard (3-4 giorni)
- [ ] Dashboard layout (sidebar, header)
- [ ] Dashboard home page
- [ ] Lista workout
- [ ] Dettaglio workout

### Fase 4: Analytics (4-5 giorni)
- [ ] Grafici volume/frequenza
- [ ] Storico per esercizio
- [ ] Personal Records
- [ ] Period selector

### Fase 5: Polish (2-3 giorni)
- [ ] Responsive design
- [ ] Loading states
- [ ] Error handling
- [ ] SEO meta tags
- [ ] Privacy Policy / Terms

**Totale stimato: ~2 settimane**

---

## 8. Rischi e Mitigazioni

| Rischio | Probabilità | Impatto | Mitigazione |
|---------|-------------|---------|-------------|
| Costi Firebase alti | Bassa | Medio | Cache aggressivo, limits |
| Performance lenta | Media | Alto | React Query, pagination |
| Security issues | Bassa | Alto | Firestore rules già OK |
| SEO scarso | Media | Basso | Next.js SSG per landing |

---

## 9. Metriche Successo

- **Utenti attivi web**: >10% degli utenti app
- **Tempo su sito**: >2 minuti
- **Costo Firebase**: <€5/mese (primi 6 mesi)
- **Performance**: LCP <2.5s, FID <100ms

---

## 10. Prossimi Passi

1. **Approvazione design** (oggi)
2. **Setup repo e progetto** (prossima sessione)
3. **Sviluppo iterativo** per fasi

---

*Documento creato da Claude - FitLog Pro Development*
