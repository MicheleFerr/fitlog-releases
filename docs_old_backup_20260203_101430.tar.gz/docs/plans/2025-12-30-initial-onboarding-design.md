# Initial Onboarding Design

**Data**: 2025-12-30
**Status**: Approved
**Autore**: Claude + Michele

---

## Overview

Onboarding iniziale per nuovi utenti dopo login/registrazione. Raccoglie dati essenziali per personalizzare l'esperienza (suggerimenti peso, volume, analytics).

### Flow

```
[Splash] → [Login/Register] → [ONBOARDING] → [Home]
```

### Principi di Design

| Principio | Implementazione |
|-----------|-----------------|
| Progress Bar | Step indicator in alto (6 pallini) |
| 1 azione/schermo | Focus su una sola scelta per step |
| Skip friendly | Bottone "Salta" per step opzionali |
| Reversibile | Freccia "Indietro" su ogni step |
| Immagini > Testo | Icone/illustrazioni per ogni opzione |
| <60 secondi | Obiettivo: completare in 45-60 sec |

---

## Step Details

### Step 1: Welcome

```
┌────────────────────────────────────────┐
│  ○ ○ ○ ○ ○ ○                    [Skip] │
├────────────────────────────────────────┤
│                                        │
│         [App Logo/Illustration]        │
│                                        │
│      Benvenuto in FitLog Pro           │
│                                        │
│   "Il tuo diario di allenamento        │
│    intelligente che ti aiuta a         │
│    raggiungere i tuoi obiettivi"       │
│                                        │
│   ✓ Traccia workout e progressi        │
│   ✓ Suggerimenti peso personalizzati   │
│   ✓ Analisi avanzate                   │
│                                        │
│     ┌──────────────────────────┐       │
│     │      Iniziamo! →         │       │
│     └──────────────────────────┘       │
└────────────────────────────────────────┘
```

**Dati raccolti**: Nessuno

---

### Step 2: Obiettivo

```
┌────────────────────────────────────────┐
│  ● ○ ○ ○ ○ ○                     [←]   │
├────────────────────────────────────────┤
│                                        │
│      Qual è il tuo obiettivo?          │
│                                        │
│  ┌────────────────────────────────┐    │
│  │  💪  Aumentare i muscoli       │    │
│  │      Costruire massa muscolare │    │
│  └────────────────────────────────┘    │
│                                        │
│  ┌────────────────────────────────┐    │
│  │  🦾  Diventare più forte       │    │
│  │      Sollevare pesi maggiori   │    │
│  └────────────────────────────────┘    │
│                                        │
│  ┌────────────────────────────────┐    │
│  │  🏃  Migliorare la resistenza  │    │
│  │      Più ripetizioni, più energia│  │
│  └────────────────────────────────┘    │
│                                        │
│  ┌────────────────────────────────┐    │
│  │  ❤️  Mantenermi in forma       │    │
│  │      Fitness generale          │    │
│  └────────────────────────────────┘    │
│                                        │
└────────────────────────────────────────┘
```

**Dati raccolti**: `TrainingGoalUI`

| UI Label | TrainingGoal enum |
|----------|-------------------|
| Aumentare muscoli | `hypertrophy` |
| Diventare più forte | `strength` |
| Migliorare resistenza | `endurance` |
| Mantenermi in forma | `hypertrophy` (default) |

---

### Step 3: Dati Fisici

```
┌────────────────────────────────────────┐
│  ● ● ○ ○ ○ ○                     [←]   │
├────────────────────────────────────────┤
│                                        │
│      Parlaci di te                     │
│                                        │
│   Sesso biologico                      │
│   ┌─────────────┐ ┌─────────────┐      │
│   │   🚹 Uomo   │ │  🚺 Donna   │      │
│   └─────────────┘ └─────────────┘      │
│                                        │
│   Peso corporeo                        │
│   ┌────────────────────────────────┐   │
│   │  [    75    ] kg               │   │
│   └────────────────────────────────┘   │
│   ┌────────────────────────────────┐   │
│   │ 📱 Importa da Salute           │   │
│   └────────────────────────────────┘   │
│                                        │
│   ────────────────────────────────     │
│   ℹ️ Usiamo questi dati per            │
│      suggerirti i pesi corretti        │
│                                        │
│     ┌──────────────────────────┐       │
│     │       Continua →         │       │
│     └──────────────────────────┘       │
└────────────────────────────────────────┘
```

**Dati raccolti**:
- `BiologicalSex` (male/female)
- `bodyweightKg` (double, 30-300 kg)

**Comportamento "Importa da Salute"**:
1. Richiede permesso `HealthDataType.bodyWeight` (read only)
2. Se autorizzato → legge ultimo peso da HealthKit
3. Se negato → mostra toast "Inserisci manualmente"

---

### Step 4: Esperienza

```
┌────────────────────────────────────────┐
│  ● ● ● ○ ○ ○                     [←]   │
├────────────────────────────────────────┤
│                                        │
│      Qual è la tua esperienza?         │
│                                        │
│  ┌────────────────────────────────┐    │
│  │  🌱  Principiante              │    │
│  │      Mai o raramente in palestra│   │
│  └────────────────────────────────┘    │
│                                        │
│  ┌────────────────────────────────┐    │
│  │  📈  Qualche esperienza        │    │
│  │      6 mesi - 2 anni           │    │
│  └────────────────────────────────┘    │
│                                        │
│  ┌────────────────────────────────┐    │
│  │  💪  Esperto                   │    │
│  │      2+ anni consistenti       │    │
│  └────────────────────────────────┘    │
│                                        │
│  ┌────────────────────────────────┐    │
│  │  🏆  Atleta avanzato           │    │
│  │      5+ anni, conosco i miei PR│    │
│  └────────────────────────────────┘    │
│                                        │
└────────────────────────────────────────┘
```

**Dati raccolti**: `ExperienceLevelUI`

| UI Label | ExperienceLevel enum | monthsOfTraining |
|----------|---------------------|------------------|
| Principiante | `novice` | 0-6 |
| Qualche esperienza | `intermediate` | 6-24 |
| Esperto | `advanced` | 24-60 |
| Atleta avanzato | `elite` | 60+ |

---

### Step 5: HealthKit

```
┌────────────────────────────────────────┐
│  ● ● ● ● ○ ○                     [←]   │
├────────────────────────────────────────┤
│                                        │
│      📱 Collega Salute                 │
│                                        │
│   Sincronizza i tuoi dati per          │
│   un'esperienza personalizzata         │
│                                        │
│  ┌────────────────────────────────┐    │
│  │  🏋️  Allenamenti               │    │
│  │      Salva workout in Salute   │    │
│  │                      [Toggle ●]│    │
│  └────────────────────────────────┘    │
│                                        │
│  ┌────────────────────────────────┐    │
│  │  ⚖️  Peso corporeo             │    │
│  │      Sincronizza peso          │    │
│  │                      [Toggle ●]│    │
│  └────────────────────────────────┘    │
│                                        │
│  ┌────────────────────────────────┐    │
│  │  😴  Sonno           PRO       │    │
│  │      Per Recovery Insight      │    │
│  │                      [Toggle ○]│    │
│  └────────────────────────────────┘    │
│                                        │
│  ┌────────────────────────────────┐    │
│  │  💓  HRV             PRO       │    │
│  │      Per Stress Index          │    │
│  │                      [Toggle ○]│    │
│  └────────────────────────────────┘    │
│                                        │
│   🔒 I tuoi dati restano sul device    │
│                                        │
│  ┌──────────────────────────────┐      │
│  │     Collega Salute →         │      │
│  └──────────────────────────────┘      │
│        [Salta per ora]                 │
└────────────────────────────────────────┘
```

**Dati raccolti**: Lista permessi selezionati

| Toggle | Default | HealthDataType | Richiede PRO |
|--------|---------|----------------|--------------|
| Allenamenti | ON | `workout` | No |
| Peso | ON | `bodyWeight` | No |
| Sonno | OFF | `sleep` | Sì |
| HRV | OFF | `hrv` | Sì |

---

### Step 6: Frequenza + Riepilogo

```
┌────────────────────────────────────────┐
│  ● ● ● ● ● ○                     [←]   │
├────────────────────────────────────────┤
│                                        │
│      Quante volte ti alleni?           │
│                                        │
│   Workout a settimana                  │
│                                        │
│      ┌───┬───┬───┬───┬───┬───┬───┐    │
│      │ 1 │ 2 │ 3 │ 4 │ 5 │ 6 │ 7 │    │
│      └───┴───┴─●─┴───┴───┴───┴───┘    │
│                                        │
│   ────────────────────────────────     │
│                                        │
│      📋 Riepilogo                      │
│                                        │
│      Obiettivo:    💪 Muscoli          │
│      Peso:         75 kg               │
│      Esperienza:   📈 Intermedio       │
│      Frequenza:    3x / settimana      │
│      Salute:       ✓ Collegato         │
│                                        │
│  ┌──────────────────────────────┐      │
│  │   🚀 Inizia ad allenarti!    │      │
│  └──────────────────────────────┘      │
│                                        │
│   Puoi modificare tutto dalle          │
│   Impostazioni in qualsiasi momento    │
└────────────────────────────────────────┘
```

**Dati raccolti**: `workoutsPerWeek` (1-7, default: 3)

---

## Architettura Tecnica

### Struttura File

```
lib/features/onboarding/
├── domain/
│   ├── entities/
│   │   ├── initial_onboarding_data.dart      # Dati raccolti
│   │   ├── onboarding_step.dart              # Enum step
│   │   └── training_goal_ui.dart             # Mapping UI → enum
│   └── services/
│       └── onboarding_completion_service.dart # Salvataggio finale
│
├── data/
│   ├── repositories/
│   │   └── initial_onboarding_repository.dart # Hive + Firestore
│   └── datasources/
│       └── onboarding_local_datasource.dart   # Hive persistence
│
└── presentation/
    ├── providers/
    │   └── initial_onboarding_provider.dart   # State management
    ├── screens/
    │   └── initial_onboarding_screen.dart     # PageView container
    └── widgets/
        └── steps/
            ├── welcome_step.dart
            ├── goal_selection_step.dart
            ├── body_data_step.dart
            ├── experience_step.dart
            ├── healthkit_step.dart
            └── frequency_summary_step.dart
```

### Entità Principale

```dart
@freezed
class InitialOnboardingData with _$InitialOnboardingData {
  const factory InitialOnboardingData({
    required TrainingGoalUI goal,
    required BiologicalSex sex,
    required double bodyweightKg,
    required ExperienceLevelUI experience,
    @Default(false) bool healthKitConnected,
    @Default([]) List<String> healthKitPermissionsGranted,
    @Default(3) int workoutsPerWeek,
    DateTime? completedAt,
  }) = _InitialOnboardingData;
}

enum TrainingGoalUI {
  buildMuscle,    // → TrainingGoal.hypertrophy
  getStronger,    // → TrainingGoal.strength
  endurance,      // → TrainingGoal.endurance
  stayFit,        // → TrainingGoal.hypertrophy (default)
}

enum ExperienceLevelUI {
  beginner,       // → ExperienceLevel.novice
  someExperience, // → ExperienceLevel.intermediate
  experienced,    // → ExperienceLevel.advanced
  athlete,        // → ExperienceLevel.elite
}
```

### Integrazione con Sistemi Esistenti

```dart
class OnboardingCompletionService {
  Future<void> complete(InitialOnboardingData data) async {
    // 1. Aggiorna UserFitnessQuestionnaire
    final questionnaire = UserFitnessQuestionnaire(
      bodyweightKg: data.bodyweightKg,
      sex: data.sex,
      experienceLevel: data.experience.toExperienceLevel(),
      trainingGoal: data.goal.toTrainingGoal(),
      age: 30,        // Default
      heightCm: 175,  // Default
      completedAt: DateTime.now(),
    );
    await _fitnessProfileDatasource.save(questionnaire);

    // 2. Aggiorna UserGoals
    await _userGoalsNotifier.setWorkoutsPerWeek(data.workoutsPerWeek);

    // 3. Marca completato
    await _appConfigService.setInitialOnboardingCompleted(true);

    // 4. Sync Firestore (background)
    unawaited(_syncToFirestore(data));
  }
}
```

### Routing

```dart
// app_router.dart
if (isLoggedIn && !hasCompletedInitialOnboarding) {
  return '/initial-onboarding';
} else if (isLoggedIn) {
  return '/home';
}
```

---

## File da Creare

| File | Priorità |
|------|----------|
| `initial_onboarding_data.dart` | Alta |
| `initial_onboarding_provider.dart` | Alta |
| `initial_onboarding_screen.dart` | Alta |
| `onboarding_completion_service.dart` | Alta |
| 6x step widgets | Media |
| `onboarding_progress_bar.dart` | Bassa |

---

## Sources

- [Zfort - Fitness App UX Best Practices](https://www.zfort.com/blog/How-to-Design-a-Fitness-App-UX-UI-Best-Practices-for-Engagement-and-Retention)
- [Perpet.io - Fitness App Design](https://perpet.io/blog/what-should-be-ui-ux-design-of-fitness-app/)
- [Medium - FitHealth Onboarding UX](https://medium.com/@ankitsingh.iitb/onboarding-experience-for-health-and-fitness-app-fithealth-ca8538541979)
