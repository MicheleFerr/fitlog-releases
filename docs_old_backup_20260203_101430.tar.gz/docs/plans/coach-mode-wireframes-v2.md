# Coach Mode - Wireframe Completi Rivisti v2

> Basato su UX Best Practices + FitLog Design System
> Data: 2025-12-27

---

## Design System Reference

```dart
// Spacing (4px base)
AppSpacing.xxs = 4    // Micro gaps
AppSpacing.xs = 8     // Icon-text gaps
AppSpacing.sm = 12    // Compact padding
AppSpacing.md = 16    // Card padding (default)
AppSpacing.lg = 20    // Screen margins
AppSpacing.xl = 24    // Dialog/sheet padding

// Border Radius
Small: 8px   // Chips, badges
Medium: 12px // Buttons, inputs
Large: 16px  // Cards (default)
XL: 20px     // Modal sheets
Hero: 24px   // Feature cards

// Colors (via context.colors.*)
primary, secondary, tertiary
surface, surfaceContainerLow/High/Highest
onSurface, onSurfaceVariant
success, warning, error (via extensions)

// Touch targets: minimum 48x48dp
// Card shadows: blur 10-12, offset (0, 3-4)
```

---

## 1. ONBOARDING FLOW (Rivisto - Max 60 secondi)

### 1.1 Welcome Screen (Step 1/2)

```
┌─────────────────────────────────────────┐
│                                         │
│                                         │
│              [AppLogo]                  │
│             FitLog Pro                  │
│                                         │
│     "Il tuo diario di allenamento       │
│          intelligente"                  │
│                                         │
│                                         │
│ ┌─────────────────────────────────────┐ │
│ │  ○ ○ ○  Come userai FitLog?         │ │
│ │                                     │ │
│ │  ┌─────────────────────────────┐    │ │
│ │  │ 💪  Mi alleno da solo       │    │ │  ← Card selezionabile
│ │  │     Gestisco i miei workout │    │ │    borderRadius: 16
│ │  └─────────────────────────────┘    │ │    padding: AppSpacing.md
│ │                                     │ │
│ │  ┌─────────────────────────────┐    │ │
│ │  │ 🏋️  Ho un coach/PT          │    │ │
│ │  │     Mi vengono assegnati    │    │ │
│ │  │     workout dal mio coach   │    │ │
│ │  └─────────────────────────────┘    │ │
│ │                                     │ │
│ │  ┌─────────────────────────────┐    │ │
│ │  │ 📋  Sono un coach/PT        │    │ │
│ │  │     Gestisco atleti in      │    │ │
│ │  │     palestra                │    │ │
│ │  └─────────────────────────────┘    │ │
│ └─────────────────────────────────────┘ │
│                                         │
│         [Continua →]                    │  ← Abilitato dopo selezione
│                                         │
│     Puoi cambiare dopo nelle           │
│     impostazioni                        │
│                                         │
└─────────────────────────────────────────┘

Design specs:
- Cards: surfaceContainerHighest, borderRadius: 16
- Selected: border primary 2px, background primaryContainer
- Icon size: AppIconSize.large (28)
- Text: titleMedium (nome), bodySmall (descrizione)
- CTA button: FilledButton, full width, minHeight 48
```

### 1.2 Quick Setup (Step 2/2) - Condizionale per ruolo

#### 1.2a Solo Mode - Obiettivo

```
┌─────────────────────────────────────────┐
│ ← Indietro           Step 2/2           │
│                                         │
│  ━━━━━━━━━━━━━━━━━━ 100% ━━━━━━━━━━━━━  │  ← Progress bar
│                                         │
│        Qual è il tuo obiettivo?         │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │  🎯  Forza & Muscoli           │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │  🔥  Perdita peso              │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │  ❤️  Fitness generale          │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │  🏃  Sport specifico           │    │
│  └─────────────────────────────────┘    │
│                                         │
│                                         │
│         [Inizia ad allenarti →]         │
│                                         │
│    Potrai personalizzare tutto dopo     │
│                                         │
└─────────────────────────────────────────┘

→ Dopo: Home screen, account opzionale
```

#### 1.2b Coached Mode - Codice Coach

```
┌─────────────────────────────────────────┐
│ ← Indietro           Step 2/2           │
│                                         │
│  ━━━━━━━━━━━━━━━━━━ 100% ━━━━━━━━━━━━━  │
│                                         │
│     Inserisci il codice del coach       │
│                                         │
│     Il tuo PT ti avrà fornito un        │
│     codice di 6 caratteri               │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │  [A] [B] [C] [1] [2] [3]       │    │  ← 6 celle OTP-style
│  └─────────────────────────────────┘    │
│                                         │
│     ┌───────────────────────────┐       │
│     │ ✓ Coach trovato!          │       │  ← Success state
│     │   Mario Rossi PT          │       │
│     │   Palestra FitGym Milano  │       │
│     └───────────────────────────┘       │
│                                         │
│                                         │
│         [Collegati al coach →]          │
│                                         │
│     Non hai un codice? [Salta →]        │  ← Fallback a Solo mode
│                                         │
└─────────────────────────────────────────┘

Design specs:
- OTP cells: 48x56dp, borderRadius: 12, surfaceContainerHigh
- Success card: primaryContainer, borderRadius: 16
- Coach avatar: 48dp circle
```

#### 1.2c Coach Mode - Info base

```
┌─────────────────────────────────────────┐
│ ← Indietro           Step 2/2           │
│                                         │
│  ━━━━━━━━━━━━━━━━━━ 100% ━━━━━━━━━━━━━  │
│                                         │
│     Configurazione Coach                │
│                                         │
│     ┌───────────────────────────┐       │
│     │ Nome mostrato ai clienti  │       │
│     │ [Mario Rossi PT        ]  │       │
│     └───────────────────────────┘       │
│                                         │
│     ┌───────────────────────────┐       │
│     │ Nome palestra (opzionale) │       │
│     │ [FitGym Milano         ]  │       │
│     └───────────────────────────┘       │
│                                         │
│     Il tuo codice coach sarà:           │
│     ┌───────────────────────────┐       │
│     │      ABC123               │       │  ← Auto-generato
│     │   [Copia] [Condividi]     │       │
│     └───────────────────────────┘       │
│                                         │
│         [Inizia →]                      │
│                                         │
│     Richiede account (gratuito)         │
│                                         │
└─────────────────────────────────────────┘

→ Dopo: Registrazione account (obbligatoria per coach)
```

---

## 2. HOME SCREEN - Per Modalità

### 2.1 Solo Mode Home (Esistente - Minor tweaks)

```
┌─────────────────────────────────────────┐
│ FitLog          [👤]                    │  ← Profile avatar
├─────────────────────────────────────────┤
│                                         │
│  ┌─────────────────────────────────┐    │
│  │  Inizia Allenamento            │    │  ← Hero CTA
│  │  [Scegli template] [Libero]    │    │    InteractiveElement
│  └─────────────────────────────────┘    │    FeedbackConfig.high()
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ 📊 Stress Index    🔥 Streak   │    │  ← Stats row
│  │    42/100             7 giorni │    │
│  └─────────────────────────────────┘    │
│                                         │
│  I tuoi template                        │
│  ┌──────┐ ┌──────┐ ┌──────┐           │
│  │Push  │ │Pull  │ │Legs  │ [+]       │  ← Carousel orizzontale
│  └──────┘ └──────┘ └──────┘           │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ 💡 Recovery Insight            │    │
│  │ Petto recuperato. Pronto per   │    │
│  │ Push day!                      │    │
│  └─────────────────────────────────┘    │
│                                         │
│  Ultimi allenamenti                     │
│  ┌─────────────────────────────────┐    │
│  │ Ieri - Push Day         45min  │    │
│  │ Volume: 12,500kg   ●●●○○       │    │
│  └─────────────────────────────────┘    │
│                                         │
└─────────────────────────────────────────┘

Tab bar: [🏠 Home] [📊 Stats] [📝 History] [👤 Profile]
```

### 2.2 Coached Mode Home

```
┌─────────────────────────────────────────┐
│ FitLog        [Coach: Mario R.]    [👤] │  ← Badge coach collegato
├─────────────────────────────────────────┤
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ 📋 WORKOUT DI OGGI              │    │  ← Card evidenziata
│  │                                 │    │    primaryContainer bg
│  │    Push Day - Settimana 3       │    │
│  │    Assegnato da Mario Rossi     │    │
│  │                                 │    │
│  │    [Inizia workout →]           │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ 💬 Nota dal coach               │    │  ← Se presente
│  │ "Oggi focus su ROM completo.    │    │
│  │  Aumenta peso solo se riesci    │    │
│  │  a fare tutte le rep pulite"    │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ 📊 Il tuo progresso             │    │
│  │ ━━━━━━━━━━━━━━━━━ 67%          │    │
│  │ Settimana 3 di 12               │    │
│  │ Prossimo check-in: tra 4 giorni │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ Allenamento libero  [+]        │    │  ← Workout non assegnati
│  │ Per esercizi extra non nel     │    │
│  │ programma                       │    │
│  └─────────────────────────────────┘    │
│                                         │
└─────────────────────────────────────────┘

Tab bar: [🏠 Home] [📋 Programma] [📊 Stats] [👤 Profile]
```

### 2.3 Coach Mode Home (Dashboard)

```
┌─────────────────────────────────────────┐
│ FitLog Coach              [⚙️]     [👤] │
├─────────────────────────────────────────┤
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ 👥 I tuoi atleti         [+]   │    │  ← Aggiunta rapida
│  │                                 │    │
│  │ ┌──────────────────────────┐    │    │
│  │ │ 🟢 Marco B.    Push Day  │    │    │  ← Online/workout oggi
│  │ │    In allenamento...     │    │    │
│  │ └──────────────────────────┘    │    │
│  │                                 │    │
│  │ ┌──────────────────────────┐    │    │
│  │ │ 🟡 Laura S.    Rest Day  │    │    │  ← Warning: 3 giorni
│  │ │    Ultimo: 3 giorni fa   │    │    │    senza workout
│  │ └──────────────────────────┘    │    │
│  │                                 │    │
│  │ ┌──────────────────────────┐    │    │
│  │ │ ⚪ Giulia M.   Pull Day  │    │    │  ← Offline
│  │ │    Ultimo: ieri          │    │    │
│  │ └──────────────────────────┘    │    │
│  │                                 │    │
│  │ [Vedi tutti (12) →]            │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ 📊 Oggi                        │    │
│  │                                 │    │
│  │  3 workout    2 in corso       │    │
│  │  completati   ora              │    │
│  │                                 │    │
│  │  1 check-in   5 da             │    │
│  │  richiesto    programmare      │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ 🔔 Da fare                     │    │
│  │ • Programmare settimana Marco  │    │
│  │ • Check-in con Laura           │    │
│  │ • Review workout Giulia        │    │
│  └─────────────────────────────────┘    │
│                                         │
└─────────────────────────────────────────┘

Tab bar: [🏠 Home] [👥 Atleti] [📋 Programmi] [👤 Profile]
```

---

## 3. LISTA ATLETI (Coach Mode)

### 3.1 Lista principale

```
┌─────────────────────────────────────────┐
│ ← Dashboard        Atleti         [+]   │
├─────────────────────────────────────────┤
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ 🔍 Cerca atleta...             │    │  ← Search field
│  └─────────────────────────────────┘    │
│                                         │
│  Filtri: [Tutti ▼] [Attivi] [Pausa]    │  ← Chip filters
│                                         │
│  ───────────────────────────────────    │
│  🟢 IN ALLENAMENTO (1)                  │  ← Section header
│  ───────────────────────────────────    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ [👤]  Marco Bianchi            │    │
│  │       Push Day • Set 4/6       │    │  ← Live progress
│  │       ━━━━━━━━━━━ 67%          │    │
│  │                          [→]   │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ───────────────────────────────────    │
│  📋 WORKOUT OGGI (3)                    │
│  ───────────────────────────────────    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ [👤]  Laura Santi              │    │
│  │       Pull Day • Non iniziato  │    │
│  │       ⚠️ 3 giorni inattiva     │    │  ← Warning badge
│  │                          [→]   │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ [👤]  Giulia Mori              │    │
│  │       Legs Day • Non iniziato  │    │
│  │                          [→]   │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ───────────────────────────────────    │
│  😴 REST DAY (8)                        │
│  ───────────────────────────────────    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ [👤]  Andrea Verdi             │    │
│  │       Prossimo: Pull Day (dom) │    │
│  │                          [→]   │    │
│  └─────────────────────────────────┘    │
│                                         │
└─────────────────────────────────────────┘

Design specs:
- Athlete card: surfaceContainerLow, borderRadius: 16
- Avatar: 48dp circle con iniziali o foto
- Status indicator: 12dp circle (success/warning/outline)
- Progress bar: LinearProgressIndicator, height: 4
- Touch target: intera card tappabile
```

### 3.2 Aggiunta nuovo atleta

```
┌─────────────────────────────────────────┐
│ ← Atleti       Nuovo Atleta             │
├─────────────────────────────────────────┤
│                                         │
│  Come vuoi aggiungere l'atleta?         │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ 📱 Condividi codice             │    │
│  │                                 │    │
│  │ L'atleta scarica FitLog e      │    │
│  │ inserisce il tuo codice coach   │    │
│  │                                 │    │
│  │ Il tuo codice: ABC123          │    │
│  │                                 │    │
│  │ [Copia]  [Condividi WhatsApp]  │    │
│  └─────────────────────────────────┘    │
│                                         │
│               oppure                    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ 👤 Crea profilo manuale        │    │
│  │                                 │    │
│  │ Per atleti che non useranno    │    │
│  │ l'app in autonomia. Tu        │    │
│  │ registrerai i loro workout.    │    │
│  │                                 │    │
│  │ [Crea profilo →]               │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ℹ️ Gli atleti con app propria         │
│     possono vedere il loro progresso   │
│     e ricevere workout assegnati       │
│                                         │
└─────────────────────────────────────────┘
```

---

## 4. PROFILO ATLETA (Coach View)

### 4.1 Overview atleta

```
┌─────────────────────────────────────────┐
│ ← Atleti                          [⋮]  │
├─────────────────────────────────────────┤
│                                         │
│           [Avatar 80dp]                 │
│          Marco Bianchi                  │
│       Attivo da: 3 mesi                 │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ [📋 Programma] [📊 Stats]       │    │  ← Tab switcher
│  │ [📝 Anamnesi]  [💬 Note]        │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ═══════════════════════════════════    │
│  📋 PROGRAMMA ATTUALE                   │
│  ═══════════════════════════════════    │
│                                         │
│  Push Pull Legs - Settimana 3/12        │
│  ━━━━━━━━━━━━━━━━━━ 25%                │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ Lun  Mar  Mer  Gio  Ven  Sab   │    │
│  │ Push Pull Rest Legs Push Rest  │    │
│  │  ✓    ✓    -    ○    ○    -    │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ Prossimo workout: Legs Day     │    │
│  │ Giovedì                        │    │
│  │                                 │    │
│  │ [Modifica] [Assegna diverso]   │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ═══════════════════════════════════    │
│  📊 QUESTA SETTIMANA                    │
│  ═══════════════════════════════════    │
│                                         │
│  ┌───────┬───────┬───────┐             │
│  │ 2     │ 18.5k │ 42    │             │
│  │workout│ volume│ stress│             │
│  └───────┴───────┴───────┘             │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ 📈 Trend: +12% volume vs       │    │
│  │    settimana scorsa            │    │
│  └─────────────────────────────────┘    │
│                                         │
└─────────────────────────────────────────┘
```

### 4.2 Tab Anamnesi

```
┌─────────────────────────────────────────┐
│ ← Marco Bianchi                   [⋮]  │
├─────────────────────────────────────────┤
│                                         │
│  [Programma] [Stats] [📝 Anamnesi] [Note]│
│  ═══════════════════════════════════    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ ℹ️ Dati forniti dall'atleta     │    │
│  │    Ultimo aggiornamento: 3 mesi│    │
│  │    [Richiedi aggiornamento]    │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ───────────────────────────────────    │
│  INFORMAZIONI BASE                      │
│  ───────────────────────────────────    │
│                                         │
│  Età                          28 anni   │
│  Sesso                       Maschile   │
│  Esperienza              2-5 anni       │
│                                         │
│  ───────────────────────────────────    │
│  OBIETTIVI                              │
│  ───────────────────────────────────    │
│                                         │
│  Obiettivo primario    Forza & Muscoli  │
│  Disponibilità         4 giorni/sett    │
│  Durata sessione       60-75 min        │
│                                         │
│  ───────────────────────────────────    │
│  SALUTE (PAR-Q)                         │
│  ───────────────────────────────────    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ ✓ Nessuna condizione medica    │    │  ← Green badge
│  │   segnalata                     │    │
│  │                                 │    │
│  │ [Vedi dettagli PAR-Q]          │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ───────────────────────────────────    │
│  NOTE ATLETA                            │
│  ───────────────────────────────────    │
│                                         │
│  "Fastidio spalla destra da vecchio    │
│   infortunio. Evito dip e overhead     │
│   press pesante."                       │
│                                         │
│  ───────────────────────────────────    │
│  LIMITAZIONI SEGNALATE                  │
│  ───────────────────────────────────    │
│                                         │
│  ┌──────────┐ ┌──────────┐             │
│  │ 🚫 Dip   │ │⚠️ OHP    │             │  ← Chips rossi/gialli
│  └──────────┘ └──────────┘             │
│                                         │
└─────────────────────────────────────────┘

Design specs:
- Section headers: bodySmall, onSurfaceVariant
- Values: bodyMedium, onSurface
- Warning chips: errorContainer bg, error text
- Caution chips: tertiaryContainer bg, tertiary text
- PAR-Q success: successContainer bg
```

---

## 5. PAR-Q FLOW (Anamnesi Salute)

### 5.1 Intro PAR-Q

```
┌─────────────────────────────────────────┐
│ ← Indietro                              │
├─────────────────────────────────────────┤
│                                         │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━ Step 1/8    │
│                                         │
│              [❤️ Icon 64dp]             │
│                                         │
│     Questionario di idoneità            │
│     all'attività fisica                 │
│                                         │
│  Queste domande ci aiutano a            │
│  personalizzare il tuo allenamento      │
│  in sicurezza.                          │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ 🔒 I tuoi dati sono protetti    │    │
│  │                                 │    │
│  │ Solo tu e il tuo coach potete  │    │
│  │ vedere queste informazioni.    │    │
│  │ Non vengono condivise con      │    │
│  │ terzi.                         │    │
│  │                                 │    │
│  │ [Leggi informativa privacy →]  │    │
│  └─────────────────────────────────┘    │
│                                         │
│                                         │
│                                         │
│         [Inizia questionario →]         │
│                                         │
│                                         │
└─────────────────────────────────────────┘
```

### 5.2 Domanda PAR-Q (1 per schermata)

```
┌─────────────────────────────────────────┐
│ ← Indietro                              │
├─────────────────────────────────────────┤
│                                         │
│  ━━━━━━━━━━━━━ 25% ━━━━━━━━  Step 2/8   │
│                                         │
│                                         │
│                                         │
│     Il tuo medico ti ha mai detto       │
│     che hai una condizione cardiaca     │
│     e che dovresti fare solo            │
│     attività fisica raccomandata        │
│     da un medico?                       │
│                                         │
│                                         │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │                                 │    │
│  │              Sì                 │    │  ← Full width button
│  │                                 │    │    height: 56dp
│  └─────────────────────────────────┘    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │                                 │    │
│  │              No                 │    │
│  │                                 │    │
│  └─────────────────────────────────┘    │
│                                         │
│                                         │
│                                         │
│                                         │
│         Domanda 1 di 7                  │
│                                         │
└─────────────────────────────────────────┘

Design specs:
- Question: titleLarge, centered, letterSpacing: -0.5
- Buttons: OutlinedButton, height: 56dp, borderRadius: 16
- Progress: 4dp height, primary color
- 1 tap = avanza automaticamente
```

### 5.3 Domanda con follow-up

```
┌─────────────────────────────────────────┐
│ ← Indietro                              │
├─────────────────────────────────────────┤
│                                         │
│  ━━━━━━━━━━━━━━━ 62% ━━━━━━  Step 5/8   │
│                                         │
│                                         │
│     Hai problemi ossei o articolari     │
│     che potrebbero peggiorare con       │
│     l'attività fisica?                  │
│                                         │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │              Sì ✓               │    │  ← Selected state
│  └─────────────────────────────────┘    │    primary border
│                                         │
│  ┌─────────────────────────────────┐    │
│  │              No                 │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ Specifica (opzionale)          │    │  ← Appare se "Sì"
│  │                                 │    │
│  │ Es: ginocchio sinistro,        │    │
│  │ spalla destra...               │    │
│  │                                 │    │
│  │ [                            ] │    │
│  │                                 │    │
│  └─────────────────────────────────┘    │
│                                         │
│         [Continua →]                    │  ← Appare dopo selezione
│                                         │
└─────────────────────────────────────────┘
```

### 5.4 Riepilogo PAR-Q

```
┌─────────────────────────────────────────┐
│ ← Indietro                              │
├─────────────────────────────────────────┤
│                                         │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━ Step 8/8    │
│                                         │
│              [✓ Icon 64dp]              │
│                                         │
│     Questionario completato             │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ Riepilogo                       │    │
│  │                                 │    │
│  │ ✓ Condizione cardiaca    No    │    │
│  │ ✓ Dolore al petto        No    │    │
│  │ ✓ Perdita equilibrio     No    │    │
│  │ ⚠️ Problemi articolari   Sì    │    │  ← Warning
│  │   "Ginocchio sinistro"         │    │
│  │ ✓ Farmaci pressione      No    │    │
│  │ ✓ Altri motivi           No    │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ 💡 Consiglio                    │    │
│  │                                 │    │
│  │ Hai segnalato problemi al      │    │
│  │ ginocchio. Ti consigliamo di   │    │
│  │ informare il tuo coach e       │    │
│  │ valutare esercizi alternativi  │    │
│  │ per le gambe.                  │    │
│  └─────────────────────────────────┘    │
│                                         │
│         [Salva e continua →]            │
│                                         │
│     [Modifica risposte]                 │
│                                         │
└─────────────────────────────────────────┘
```

---

## 6. WORKOUT LOGGING (Rivisto - 1 tap per set)

### 6.1 Durante workout

```
┌─────────────────────────────────────────┐
│ Push Day              [⏸️] [✕]         │
│ 00:32:15                               │  ← Timer attivo
├─────────────────────────────────────────┤
│                                         │
│  ━━━━━━━━━━━━━━━━ 4/6 esercizi         │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ 🏋️ Panca Piana                  │    │
│  │                                 │    │
│  │ Target: 4x8 @ 80kg              │    │
│  │                                 │    │
│  │ ┌─────────────────────────────┐ │    │
│  │ │ Set 1    8 rep   80kg   ✓  │ │    │  ← Completato
│  │ └─────────────────────────────┘ │    │
│  │ ┌─────────────────────────────┐ │    │
│  │ │ Set 2    8 rep   80kg   ✓  │ │    │
│  │ └─────────────────────────────┘ │    │
│  │ ┌─────────────────────────────┐ │    │  ← Set attivo
│  │ │ Set 3    8 rep   80kg       │ │    │    surfaceContainerHigh
│  │ │                             │ │    │
│  │ │   [Fatto ✓]  [Modifica]    │ │    │  ← 1 tap = conferma target
│  │ └─────────────────────────────┘ │    │
│  │ ┌─────────────────────────────┐ │    │
│  │ │ Set 4    8 rep   80kg   ○  │ │    │  ← Pending
│  │ └─────────────────────────────┘ │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ ⏱️ Rest Timer                   │    │
│  │                                 │    │
│  │        2:30 / 3:00              │    │
│  │    ━━━━━━━━━━━━━━━ 83%         │    │
│  │                                 │    │
│  │    [Salta]  [+30s]             │    │
│  └─────────────────────────────────┘    │
│                                         │
│  Prossimo: Panca Inclinata Manubri      │
│                                         │
└─────────────────────────────────────────┘

Design specs:
- [Fatto ✓] button: FilledButton, primary, height 48dp
- [Modifica]: TextButton, secondary
- Active set: elevated (surfaceContainerHigh)
- Completed set: success tint, check icon
- 1 TAP = conferma valori target (80% dei casi)
- Modifica solo se necessario
```

### 6.2 Modifica set (Sheet)

```
┌─────────────────────────────────────────┐
│                 ───                     │  ← Drag handle
│                                         │
│  Modifica Set 3                         │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ Ripetizioni                     │    │
│  │                                 │    │
│  │  [-]    [    8    ]    [+]     │    │  ← Stepper
│  └─────────────────────────────────┘    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ Peso (kg)                       │    │
│  │                                 │    │
│  │  [-]    [   80   ]    [+]      │    │
│  │                                 │    │
│  │  [75] [77.5] [80] [82.5] [85]  │    │  ← Quick picks
│  └─────────────────────────────────┘    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ RPE (opzionale)                 │    │
│  │                                 │    │
│  │  [6] [7] [8] [9] [10]          │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ 📝 Note                         │    │
│  │ [                            ] │    │
│  └─────────────────────────────────┘    │
│                                         │
│         [Conferma ✓]                    │
│                                         │
└─────────────────────────────────────────┘

Design specs:
- Bottom sheet: borderRadius top 24
- Stepper buttons: 48x48dp touch target
- Quick picks: Chips, 40dp height
- RPE: ToggleButtons style
```

---

## 7. ASSEGNAZIONE WORKOUT (Coach)

### 7.1 Seleziona workout da assegnare

```
┌─────────────────────────────────────────┐
│ ← Marco B.       Assegna Workout        │
├─────────────────────────────────────────┤
│                                         │
│  Per quando?                            │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ L   M   M   G   V   S   D      │    │
│  │ ✓   ✓   -   ○   ○   -   -      │    │  ← Week picker
│  │             ↑                   │    │
│  │           Oggi                  │    │
│  └─────────────────────────────────┘    │
│                                         │
│  Selezionato: Giovedì 28 Dic            │
│                                         │
│  ═══════════════════════════════════    │
│  I TUOI TEMPLATE                        │
│  ═══════════════════════════════════    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ 💪 Push Day - Forza             │    │
│  │ Panca, OHP, Dip, Tricipiti     │    │
│  │ ~60 min • 5 esercizi            │    │
│  │                           [→]  │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ 🏋️ Pull Day - Volume            │    │
│  │ Trazioni, Row, Curl            │    │
│  │ ~55 min • 6 esercizi            │    │
│  │                           [→]  │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ 🦵 Legs Day - Forza             │    │
│  │ Squat, RDL, Leg Press          │    │
│  │ ~65 min • 5 esercizi            │    │
│  │                           [→]  │    │
│  └─────────────────────────────────┘    │
│                                         │
│  [+ Crea workout personalizzato]        │
│                                         │
└─────────────────────────────────────────┘
```

### 7.2 Personalizza per atleta

```
┌─────────────────────────────────────────┐
│ ← Indietro       Push Day per Marco     │
├─────────────────────────────────────────┤
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ ⚠️ Limitazioni Marco            │    │  ← Warning banner
│  │ • Evitare OHP pesante          │    │    se presenti
│  │ • Attenzione spalla destra     │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ 1. Panca Piana                  │    │
│  │    4x8 @ 80kg                   │    │
│  │    Rest: 3min                   │    │
│  │                        [⋮]     │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ 2. OHP Manubri        ⚠️       │    │  ← Warning icon
│  │    3x10 @ 20kg                  │    │
│  │    [Sostituisci] [Rimuovi]     │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ 3. Panca Inclinata              │    │
│  │    3x10 @ 60kg                  │    │
│  │                        [⋮]     │    │
│  └─────────────────────────────────┘    │
│                                         │
│  [+ Aggiungi esercizio]                 │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ 💬 Nota per Marco (opzionale)   │    │
│  │ [                            ] │    │
│  │ "Oggi focus su ROM completo"   │    │
│  └─────────────────────────────────┘    │
│                                         │
│         [Assegna workout →]             │
│                                         │
└─────────────────────────────────────────┘
```

---

## 8. ROLE SWITCHING (Account Switcher)

### 8.1 Trigger nel Profile

```
┌─────────────────────────────────────────┐
│ Profilo                                 │
├─────────────────────────────────────────┤
│                                         │
│  ┌─────────────────────────────────┐    │
│  │      [Avatar 80dp]              │    │
│  │      Mario Rossi                │    │
│  │      mario@email.com            │    │
│  │                                 │    │
│  │  ┌───────────────────────┐      │    │
│  │  │ 📋 Coach Mode    [→]  │      │    │  ← Account switcher
│  │  │ 12 atleti attivi      │      │    │
│  │  └───────────────────────┘      │    │
│  │                                 │    │
│  │  ┌───────────────────────┐      │    │
│  │  │ 💪 I miei workout [→] │      │    │  ← Personal mode
│  │  │ (allena te stesso)    │      │    │
│  │  └───────────────────────┘      │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ───────────────────────────────────    │
│  IMPOSTAZIONI                           │
│  ───────────────────────────────────    │
│                                         │
│  [Aspetto]                         [→]  │
│  [Notifiche]                       [→]  │
│  [Privacy e dati]                  [→]  │
│  [Unità di misura]                 [→]  │
│                                         │
│  ───────────────────────────────────    │
│  ACCOUNT                                │
│  ───────────────────────────────────    │
│                                         │
│  [Piano: Gratuito]                 [→]  │
│  [Esci]                                 │
│                                         │
└─────────────────────────────────────────┘
```

### 8.2 Switch Modal (stile Slack)

```
┌─────────────────────────────────────────┐
│                 ───                     │
│                                         │
│  Cambia modalità                        │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ [👤]  I miei workout      [✓]  │    │  ← Attivo ora
│  │       Allenati per te stesso   │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ [📋]  Coach Mode               │    │
│  │       Gestisci 12 atleti       │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ───────────────────────────────────    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ [+]  Diventa Coach             │    │  ← Se non ancora coach
│  │      Inizia a gestire atleti   │    │
│  └─────────────────────────────────┘    │
│                                         │
│  ┌─────────────────────────────────┐    │
│  │ [🔗] Collegati a un Coach      │    │  ← Se non ha coach
│  │      Inserisci codice coach    │    │
│  └─────────────────────────────────┘    │
│                                         │
└─────────────────────────────────────────┘

Design specs:
- Bottom sheet: borderRadius top 24
- Active item: primary border left 4px
- Touch target: 56dp height per item
- Smooth animation on switch
```

---

## 9. MICRO-INTERACTIONS

### 9.1 Haptic Feedback Map

| Azione | Haptic | Durata |
|--------|--------|--------|
| Tap button | lightImpact | - |
| Set completato | mediumImpact | - |
| Workout completato | notificationSuccess | - |
| Errore/Warning | notificationWarning | - |
| Swipe delete | selectionClick | - |
| Pull to refresh | selectionClick | - |
| Timer end | notificationSuccess × 3 | 500ms intervals |

### 9.2 Animazioni

```dart
// Card press - ExpandingStrip
InteractiveElement(
  feedbackConfig: FeedbackConfig.high(),
  visualStyle: VisualFeedbackStyle.expandingStrip,
)

// Set completion
AnimatedContainer(
  duration: Duration(milliseconds: 200),
  curve: Curves.easeOut,
  // Scale 1.0 → 0.98 → 1.0
)

// Progress bar fill
AnimatedContainer(
  duration: Duration(milliseconds: 300),
  curve: Curves.easeInOut,
)

// Page transitions
CupertinoPageRoute (iOS feel)
// or
MaterialPageRoute con SlideTransition
```

---

## 10. EMPTY STATES

### 10.1 Nessun atleta (Coach)

```
┌─────────────────────────────────────────┐
│                                         │
│                                         │
│           [👥 Icon 64dp]                │
│                                         │
│     Nessun atleta ancora                │
│                                         │
│     Condividi il tuo codice coach       │
│     per iniziare a gestire atleti       │
│                                         │
│     Il tuo codice: ABC123               │
│                                         │
│   [Condividi codice]  [Crea manuale]    │
│                                         │
│                                         │
└─────────────────────────────────────────┘

Design specs:
- Icon: AppIconSize.emptyState (48dp)
- Icon color: onSurfaceVariant.withValues(alpha: 0.5)
- Title: titleMedium
- Description: bodyMedium, onSurfaceVariant
- Buttons: horizontal, gap AppSpacing.sm
```

### 10.2 Nessun workout assegnato (Coached)

```
┌─────────────────────────────────────────┐
│                                         │
│                                         │
│           [📋 Icon 64dp]                │
│                                         │
│     Nessun workout per oggi             │
│                                         │
│     Il tuo coach non ha ancora          │
│     assegnato workout per questa        │
│     giornata.                           │
│                                         │
│     [Allenamento libero]                │
│                                         │
│                                         │
└─────────────────────────────────────────┘
```

---

## Appendice: Data Model Reference

```dart
enum AccountMode { solo, coached, coach }

class UserProfile {
  String id;
  String displayName;
  AccountMode primaryMode;
  String? coachId;        // Se coached
  String? coachCode;      // Se coach
  DateTime createdAt;
}

class CoachRelationship {
  String id;
  String coachId;
  String athleteId;
  RelationshipStatus status;
  DateTime connectedAt;
  bool athleteHasApp;
}

class HealthQuestionnaire {
  String id;
  String oderId;
  DateTime completedAt;
  List<ParqAnswer> answers;
  List<String> limitations;
  String? notes;
  ConsentRecord consent;
}

class AssignedWorkout {
  String id;
  String templateId;
  String coachId;
  String athleteId;
  DateTime scheduledFor;
  String? coachNote;
  Map<String, ExerciseCustomization> customizations;
}
```

---

## Next Steps

1. **Validazione UI** - Review con designer
2. **Prototipo Figma** - Convertire wireframes
3. **User testing** - 3-5 coach reali
4. **Implementation** - Priorità MVP

---

*Documento generato: 2025-12-27*
*Design System: FitLog v2.0*
*UX Guidelines: Material Design 3 + Custom*
