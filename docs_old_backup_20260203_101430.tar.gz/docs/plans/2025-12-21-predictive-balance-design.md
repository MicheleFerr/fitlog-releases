# Predictive Balance Design

> **Status**: Draft
> **Created**: 2025-12-21
> **Author**: Claude + Michele

---

## Overview

### Problem

L'utente fa Push (lunedì), Pull (mercoledì). È giovedì e l'app dice "Legs CRITICAL". Ma lui farà Legs venerdì - è nel suo pattern settimanale. L'avviso è **tecnicamente corretto ma contestualmente sbagliato**.

### Solution: Predictive Balance

Analizziamo lo storico workout per rilevare pattern settimanali ripetuti. Se l'utente segue un ciclo (es. Push→Pull→Legs), e questa settimana manca ancora Legs, mostriamo:

> "Completa Leg Day per bilanciare ✓"

invece di un avviso CRITICAL che genera ansia inutile.

### Scope

| In Scope | Out of Scope |
|----------|--------------|
| Pattern detection da storico | Machine Learning |
| Indicatori inline sulla UI esistente | Nuove schermate |
| Workout completati questa settimana | Scheduling/reminder |
| Template mapping se disponibile | Creazione automatica template |

### Success Criteria

1. Pattern rilevato con ≥66% confidence dopo 2 settimane
2. Messaggio contestuale mostrato entro 100ms
3. Zero false positive (non dire "completa X" se X non è nel pattern)

---

## Architecture

### Layer Structure (Clean Architecture)

```
lib/features/predictive_balance/
├── domain/
│   ├── entities/
│   │   ├── weekly_pattern.dart         # Pattern settimanale rilevato
│   │   ├── workout_fingerprint.dart    # Fingerprint muscolare
│   │   └── pattern_prediction.dart     # Predizione workout mancante
│   └── services/
│       ├── pattern_detector_service.dart    # Core detection logic
│       └── prediction_engine_service.dart   # Calcola cosa manca
├── data/
│   └── repositories/
│       └── pattern_cache_repository.dart    # Cache pattern in Hive
└── presentation/
    ├── providers/
    │   ├── weekly_pattern_provider.dart     # FutureProvider pattern
    │   └── missing_workout_provider.dart    # Cosa manca questa settimana
    └── widgets/
        └── predictive_balance_indicator.dart # UI inline
```

### Dependencies

```
predictive_balance/
    ├── depends on → workout_history (storico completati)
    ├── depends on → stress_index (exerciseMuscleMapProvider)
    ├── depends on → workout_templates (template opzionali)
    └── consumed by → analytics (muscle_balance_tab)
```

### Provider Graph

```dart
// Pattern detection
final weeklyPatternProvider = FutureProvider<WeeklyPattern?>((ref) async {
  final history = await ref.watch(workoutHistoryProvider.future);
  final muscleMap = await ref.watch(exerciseMuscleMapProvider.future);
  return PatternDetectorService.detect(history, muscleMap);
});

// Missing workout this week
final missingWorkoutProvider = Provider<PatternPrediction?>((ref) {
  final pattern = ref.watch(weeklyPatternProvider).valueOrNull;
  final thisWeek = ref.watch(thisWeekWorkoutsProvider);
  return PredictionEngineService.predict(pattern, thisWeek);
});
```

---

## Domain Entities

### WeeklyPattern

```dart
/// Pattern settimanale rilevato dallo storico
@freezed
class WeeklyPattern with _$WeeklyPattern {
  const factory WeeklyPattern({
    /// Fingerprint dei workout nel ciclo (es. [push, pull, legs])
    required List<WorkoutFingerprint> cycle,

    /// Confidence del pattern (0.0 - 1.0)
    required double confidence,

    /// Numero settimane analizzate
    required int weeksAnalyzed,

    /// Numero settimane con match
    required int weeksMatched,

    /// Data ultima analisi
    required DateTime analyzedAt,
  }) = _WeeklyPattern;

  /// Pattern valido se confidence ≥ 0.66 (2/3 settimane match)
  bool get isValid => confidence >= 0.66;
}
```

### WorkoutFingerprint

```dart
/// Fingerprint muscolare di un workout
@freezed
class WorkoutFingerprint with _$WorkoutFingerprint {
  const factory WorkoutFingerprint({
    /// ID univoco (hash dei muscoli dominanti)
    required String id,

    /// Nome template se disponibile
    String? templateName,

    /// Top 3 muscoli per volume
    required List<String> dominantMuscles,

    /// Categoria inferita: push/pull/legs/upper/lower/full
    required WorkoutCategory category,

    /// Volume totale (per ranking)
    required double totalVolume,
  }) = _WorkoutFingerprint;
}

enum WorkoutCategory { push, pull, legs, upper, lower, fullBody, other }
```

### PatternPrediction

```dart
/// Predizione di cosa manca questa settimana
@freezed
class PatternPrediction with _$PatternPrediction {
  const factory PatternPrediction({
    /// Fingerprint del workout mancante
    required WorkoutFingerprint missing,

    /// Muscoli che verrebbero coperti
    required List<String> musclesCovered,

    /// Messaggio localizzato (es. "Completa Leg Day")
    required String messageKey,

    /// Se c'è un template suggerito
    String? suggestedTemplateId,
  }) = _PatternPrediction;
}
```

---

## Pattern Detection Algorithm

### PatternDetectorService

```dart
class PatternDetectorService {
  /// Minimum workout per avere pattern
  static const int minWorkoutsForPattern = 6;

  /// Settimane da analizzare
  static const int weeksToAnalyze = 3;

  /// Detect weekly pattern from history
  static WeeklyPattern? detect(
    List<Workout> history,
    Map<String, ExerciseMuscleData> muscleMap,
  ) {
    // 1. Filter last N weeks
    final cutoff = DateTime.now().subtract(Duration(days: weeksToAnalyze * 7));
    final recent = history.where((w) => w.completedAt.isAfter(cutoff)).toList();

    if (recent.length < minWorkoutsForPattern) return null;

    // 2. Group by ISO week
    final byWeek = _groupByIsoWeek(recent);
    if (byWeek.length < 2) return null;

    // 3. Create fingerprints for each workout
    final weekFingerprints = byWeek.map((week) =>
      week.map((w) => _createFingerprint(w, muscleMap)).toList()
    ).toList();

    // 4. Find repeating cycle
    final cycle = _findRepeatingCycle(weekFingerprints);
    if (cycle == null) return null;

    // 5. Calculate confidence
    final matchedWeeks = _countMatchingWeeks(weekFingerprints, cycle);
    final confidence = matchedWeeks / weekFingerprints.length;

    return WeeklyPattern(
      cycle: cycle,
      confidence: confidence,
      weeksAnalyzed: weekFingerprints.length,
      weeksMatched: matchedWeeks,
      analyzedAt: DateTime.now(),
    );
  }

  /// Create fingerprint from workout
  static WorkoutFingerprint _createFingerprint(
    Workout workout,
    Map<String, ExerciseMuscleData> muscleMap,
  ) {
    // Calculate volume per muscle
    final muscleVolume = <String, double>{};

    for (final exercise in workout.exercises) {
      final data = muscleMap[exercise.name.toLowerCase()];
      if (data == null) continue;

      final volume = _calculateVolume(exercise);

      // Primary muscles get 100% volume credit
      for (final muscle in data.primary) {
        final normalized = _normalizeMuscle(muscle);
        muscleVolume[normalized] = (muscleVolume[normalized] ?? 0) + volume;
      }

      // Secondary muscles get 50% volume credit
      for (final muscle in data.secondary) {
        final normalized = _normalizeMuscle(muscle);
        muscleVolume[normalized] = (muscleVolume[normalized] ?? 0) + volume * 0.5;
      }
    }

    // Get top 3 muscles
    final sorted = muscleVolume.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    final dominantMuscles = sorted.take(3).map((e) => e.key).toList();

    // Infer category from dominant muscles
    final category = _inferCategory(dominantMuscles);

    return WorkoutFingerprint(
      id: _generateId(dominantMuscles),
      templateName: workout.templateName,
      dominantMuscles: dominantMuscles,
      category: category,
      totalVolume: muscleVolume.values.fold(0, (a, b) => a + b),
    );
  }

  /// Infer workout category from dominant muscles
  static WorkoutCategory _inferCategory(List<String> muscles) {
    final muscleSet = muscles.toSet();

    // Push: chest, shoulders, triceps
    if (muscleSet.contains('chest') &&
        (muscleSet.contains('shoulders') || muscleSet.contains('triceps'))) {
      return WorkoutCategory.push;
    }

    // Pull: back, biceps
    if (muscleSet.contains('back') && muscleSet.contains('biceps')) {
      return WorkoutCategory.pull;
    }

    // Legs: quadriceps, hamstrings, glutes
    if (muscleSet.containsAny(['quadriceps', 'hamstrings', 'glutes'])) {
      return WorkoutCategory.legs;
    }

    // Upper: mix of push + pull
    if (muscleSet.containsAny(['chest', 'back', 'shoulders'])) {
      return WorkoutCategory.upper;
    }

    return WorkoutCategory.other;
  }

  /// Normalize muscle codes from JSON to standard names
  static String _normalizeMuscle(String code) {
    return switch (code.toUpperCase()) {
      'PETT' => 'chest',
      'DELT' || 'SPALLE' => 'shoulders',
      'TRIC' => 'triceps',
      'BIC' => 'biceps',
      'DORSO' || 'LAT' => 'back',
      'QUAD' => 'quadriceps',
      'GLUT' => 'glutes',
      'FEMORALI' => 'hamstrings',
      'CORE' || 'ADD' => 'core',
      'POLP' => 'calves',
      _ => code.toLowerCase(),
    };
  }
}
```

---

## Prediction Engine

### PredictionEngineService

```dart
class PredictionEngineService {
  /// Predict missing workout for this week
  static PatternPrediction? predict(
    WeeklyPattern? pattern,
    List<Workout> thisWeekWorkouts,
  ) {
    if (pattern == null || !pattern.isValid) return null;

    // Create fingerprints for this week's workouts
    final doneFingerprints = thisWeekWorkouts
        .map((w) => _createFingerprint(w))
        .toList();

    // Find which cycle items haven't been done
    final missing = <WorkoutFingerprint>[];

    for (final cycleItem in pattern.cycle) {
      final isDone = doneFingerprints.any(
        (done) => _fingerprintMatches(done, cycleItem),
      );
      if (!isDone) {
        missing.add(cycleItem);
      }
    }

    if (missing.isEmpty) return null; // All done!

    // Return first missing (or prioritize by muscle neglect)
    final next = missing.first;

    return PatternPrediction(
      missing: next,
      musclesCovered: next.dominantMuscles,
      messageKey: _generateMessageKey(next),
      suggestedTemplateId: _findMatchingTemplate(next),
    );
  }

  /// Check if two fingerprints match (same workout type)
  static bool _fingerprintMatches(
    WorkoutFingerprint a,
    WorkoutFingerprint b,
  ) {
    // Same template name = match
    if (a.templateName != null &&
        a.templateName == b.templateName) {
      return true;
    }

    // Same category = match
    if (a.category == b.category &&
        a.category != WorkoutCategory.other) {
      return true;
    }

    // 2/3 dominant muscles overlap = match
    final overlap = a.dominantMuscles
        .where((m) => b.dominantMuscles.contains(m))
        .length;
    return overlap >= 2;
  }
}
```

---

## UI Integration

### PredictiveBalanceIndicator Widget

```dart
class PredictiveBalanceIndicator extends StatelessWidget {
  final PatternPrediction prediction;
  final NeglectedMuscle muscle;

  @override
  Widget build(BuildContext context) {
    final templateName = prediction.missing.templateName ??
        context.l10n.workoutCategoryLabel(prediction.missing.category);

    return GestureDetector(
      onTap: prediction.suggestedTemplateId != null
          ? () => _navigateToTemplate(context, prediction.suggestedTemplateId!)
          : null,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            AppIcons.checkCircleOutline,
            size: AppIconSize.small,
            color: context.colors.primary.withValues(alpha: 0.7),
          ),
          const SizedBox(width: 4),
          Flexible(
            child: Text(
              context.l10n.completeToBalance(templateName),
              style: context.textTheme.bodySmall?.copyWith(
                color: context.colors.onSurface.withValues(alpha: 0.6),
              ),
            ),
          ),
          if (prediction.suggestedTemplateId != null) ...[
            const SizedBox(width: 4),
            Icon(
              AppIcons.chevronRight,
              size: AppIconSize.small,
              color: context.colors.onSurface.withValues(alpha: 0.4),
            ),
          ],
        ],
      ),
    );
  }
}
```

### Visual Design

```
┌────────────────────────────────────────────────┐
│ 🦵 Quadriceps                                  │
│ ┌──────────┐                                   │
│ │ CRITICAL │                                   │
│ └──────────┘                                   │
│                                                │
│ ✓ Completa "Leg Day" per bilanciare           │
│   ↳ Tap per vedere il template                 │
└────────────────────────────────────────────────┘
```

---

## Localization

### English (app_en.arb)

```json
{
  "completeToBalance": "Complete {templateName} to balance",
  "workoutCategoryPush": "Push workout",
  "workoutCategoryPull": "Pull workout",
  "workoutCategoryLegs": "Leg workout",
  "workoutCategoryUpper": "Upper body workout",
  "workoutCategoryLower": "Lower body workout",
  "workoutCategoryFull": "Full body workout",
  "patternDetectedConfidence": "Based on your last {weeks} weeks"
}
```

### Italian (app_it.arb)

```json
{
  "completeToBalance": "Completa {templateName} per bilanciare",
  "workoutCategoryPush": "Allenamento push",
  "workoutCategoryPull": "Allenamento pull",
  "workoutCategoryLegs": "Allenamento gambe",
  "workoutCategoryUpper": "Allenamento upper body",
  "workoutCategoryLower": "Allenamento lower body",
  "workoutCategoryFull": "Allenamento full body",
  "patternDetectedConfidence": "Basato sulle ultime {weeks} settimane"
}
```

---

## Error Handling

### Edge Cases

| Scenario | Behavior |
|----------|----------|
| < 6 workout in history | No pattern, normal UI |
| Pattern confidence < 66% | No prediction, normal UI |
| All cycle workouts completed | No indicator (week complete!) |
| Workout without mapped exercises | Skip in fingerprint, use mapped ones |
| Template deleted | Fallback to category name |

### Graceful Degradation

```dart
final missingWorkoutProvider = Provider<PatternPrediction?>((ref) {
  try {
    final pattern = ref.watch(weeklyPatternProvider).valueOrNull;
    if (pattern == null) return null;

    final thisWeek = ref.watch(thisWeekWorkoutsProvider);
    return PredictionEngineService.predict(pattern, thisWeek);
  } catch (e, stack) {
    debugPrint('PredictiveBalance error: $e');
    return null;
  }
});
```

---

## Testing Strategy

### Unit Tests

```dart
group('PatternDetectorService', () {
  test('detects PPL pattern with 66% confidence', () {
    final history = [
      _createWorkout('Push Day', ['chest', 'shoulders', 'triceps'], week: 1),
      _createWorkout('Pull Day', ['back', 'biceps'], week: 1),
      _createWorkout('Leg Day', ['quadriceps', 'hamstrings'], week: 1),
      _createWorkout('Push Day', ['chest', 'shoulders'], week: 2),
      _createWorkout('Pull Day', ['back', 'biceps'], week: 2),
      _createWorkout('Leg Day', ['quadriceps', 'glutes'], week: 2),
    ];

    final pattern = PatternDetectorService.detect(history, mockMuscleMap);

    expect(pattern, isNotNull);
    expect(pattern!.cycle.length, 3);
    expect(pattern.confidence, greaterThanOrEqualTo(0.66));
  });

  test('returns null with insufficient data', () {
    final history = [_createWorkout('Day 1', ['chest'], week: 1)];
    final pattern = PatternDetectorService.detect(history, mockMuscleMap);
    expect(pattern, isNull);
  });
});

group('PredictionEngineService', () {
  test('predicts missing Legs when Push and Pull done', () {
    final pattern = WeeklyPattern(
      cycle: [pushFingerprint, pullFingerprint, legsFingerprint],
      confidence: 0.8,
      weeksAnalyzed: 3,
      weeksMatched: 3,
      analyzedAt: DateTime.now(),
    );

    final thisWeek = [pushWorkout, pullWorkout];
    final prediction = PredictionEngineService.predict(pattern, thisWeek);

    expect(prediction, isNotNull);
    expect(prediction!.missing.category, WorkoutCategory.legs);
    expect(prediction.musclesCovered, contains('quadriceps'));
  });
});
```

---

## Implementation Plan

| Phase | Task | Estimate |
|-------|------|----------|
| **1. Domain** | Entities (freezed) + Services | 2h |
| **2. Data** | Pattern cache repository | 1h |
| **3. Providers** | weeklyPatternProvider, missingWorkoutProvider | 1h |
| **4. UI** | PredictiveBalanceIndicator widget | 1h |
| **5. Integration** | Modify muscle_balance_tab | 30m |
| **6. L10n** | Add translation keys | 30m |
| **7. Tests** | Unit tests for services | 2h |
| **8. Polish** | Edge cases, error handling | 1h |

**Total estimated: ~9 hours**

---

## UX Research References

- [NNgroup: Indicators, Validations, Notifications](https://www.nngroup.com/articles/indicators-validations-notifications/)
- [Predictive UX Trends 2026](https://medium.com/procreator-design/6-predictive-ux-trends-you-cant-ignore-in-2026-4a07aefb0520)
- [Fitness App UX Best Practices](https://www.zfort.com/blog/How-to-Design-a-Fitness-App-UX-UI-Best-Practices-for-Engagement-and-Retention)
- [Push Notification UX Guide](https://uxcam.com/blog/push-notification-guide/)

---

## Decision Log

| Decision | Rationale |
|----------|-----------|
| Use local JSON instead of API | Already have exerciseMuscleMapProvider, offline-first |
| 3 weeks analysis window | Balance between recency and pattern reliability |
| 66% confidence threshold | 2/3 weeks matching = statistically significant |
| Inline indicator vs modal | NNgroup: contextual placement for passive notifications |
| Fingerprint by muscle volume | More accurate than just template name matching |
