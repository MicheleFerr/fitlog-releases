# FitLog Codebase Refactoring Plan

**Generated:** 2025-01-01
**Source:** Parallel codebase analysis + task-master.dev
**Status:** PENDING

---

## Executive Summary

| Metric | Value |
|--------|-------|
| **Total Tasks** | 11 |
| **Estimated Time** | ~68h (~2 weeks full-time) |
| **Complexity** | HIGH |
| **LOC Savings** | ~7,000+ |

---

## Phase 1: Foundation (P0 - CRITICAL)

### Task P0-1: Resolve Circular Dependency
**Priority:** P0 | **Estimate:** 8h | **Dependencies:** None

**Scope:** Break `exercise_database` ↔ `analytics` cycle
- Extract shared abstractions into domain layer
- Create `IExercise` and `IHealthDataProvider` interfaces
- Implement dependency inversion
- Establish unidirectional dependency graph

**Acceptance Criteria:**
- [ ] Zero circular imports detected by `dart analyze`
- [ ] All tests pass without modification
- [ ] Dependency graph verified acyclic

**Risk:** HIGH - touches core domain

---

### Task P0-2: AppConfig Decoupling
**Priority:** P0 | **Estimate:** 6h | **Dependencies:** P0-1

**Scope:** Break 10+ feature imports from AppConfig
- Create feature-specific config providers (Riverpod)
- Implement lazy-loading configuration
- Remove transitive feature dependencies

**Acceptance Criteria:**
- [ ] AppConfig imports reduced to <3 core features
- [ ] All features initialize independently
- [ ] No circular config dependencies

**Risk:** MEDIUM - breaking API changes

---

## Phase 2: Consolidation (P1 - HIGH PRIORITY)

### Task P1-1: Exercise Entity Unification
**Priority:** P1 | **Estimate:** 12h | **Dependencies:** P0-1, P0-2

**Scope:** Consolidate 2 Exercise types (537 + 125 imports)
- Create canonical `Exercise` entity in shared domain
- Deprecate redundant type; migrate all references
- Add deprecation warnings and migration guide

**Acceptance Criteria:**
- [ ] Single Exercise type across all layers
- [ ] Import count standardized
- [ ] Zero ambiguous references
- [ ] Migration tests verify compatibility

**Risk:** HIGH - widespread impact

---

### Task P1-2: Extract Timeout Wrapper Mixin
**Priority:** P1 | **Estimate:** 5h | **Dependencies:** P0-1

**Scope:** Consolidate 40+ timeout methods
- Create `FirestoreTimeoutMixin` with configurable duration
- Replace inline implementations
- Add unit tests for timeout scenarios

**Acceptance Criteria:**
- [ ] Timeout code reduced by ~70%
- [ ] Mixin covers 90%+ use cases
- [ ] All timeout tests pass

**Risk:** LOW - isolated pattern

---

### Task P1-3: Firebase Error Mapper Mixin
**Priority:** P1 | **Estimate:** 4h | **Dependencies:** P0-1

**Scope:** Consolidate 30+ try-catch blocks
- Create `FirebaseErrorMapperMixin`
- Map Firebase exceptions to domain failures
- Replace duplicate error handling logic

**Acceptance Criteria:**
- [ ] Error handling code reduced by ~65%
- [ ] All Firebase exceptions mapped uniformly
- [ ] Error tests cover edge cases

**Risk:** LOW - straightforward extraction

---

## Phase 3: Abstraction Creation (P2 - MEDIUM)

### Task P2-1: BaseHiveDatasource<T>
**Priority:** P2 | **Estimate:** 6h | **Dependencies:** P1-2, P1-3

**Scope:** Create generic base for 4 Hive datasources
- Extract CRUD patterns into generic base
- Implement type-safe operations
- Add transaction support

**Acceptance Criteria:**
- [ ] 4 datasources extend BaseHiveDatasource
- [ ] Hive code reduced by ~50%
- [ ] All datasource tests passing

**Risk:** LOW - internal implementation

---

### Task P2-2: ReusableModalBottomSheet<T>
**Priority:** P2 | **Estimate:** 7h | **Dependencies:** None

**Scope:** Consolidate 32 bottom sheet implementations (~2,500 LOC)
- Create parameterized widget
- Support custom headers, content, actions
- Handle scroll, sizing, animations generically

**Acceptance Criteria:**
- [ ] Generic component handles 80%+ use cases
- [ ] Bottom sheet code reduced by ~60%
- [ ] Visual regression testing passed

**Risk:** MEDIUM - UI-critical

---

### Task P2-3: SharedExpandableCard<T>
**Priority:** P2 | **Estimate:** 5h | **Dependencies:** P2-2

**Scope:** Unify expandable card pattern (4 files, ~3,000 LOC)
- Create generic expandable card component
- Support custom header/body templates
- Replace 4 existing implementations

**Acceptance Criteria:**
- [ ] Single SharedExpandableCard covers all patterns
- [ ] Code reduced by ~55%
- [ ] Animation performance verified

**Risk:** MEDIUM - animation edge cases

---

### Task P2-4: MetricDisplay & StatusBadge
**Priority:** P2 | **Estimate:** 4h | **Dependencies:** P1-1

**Scope:** Consolidate 6+ metric display widgets (~600 LOC)
- Create parameterized `MetricDisplay` component
- Create `StatusBadge` indicator system
- Support various metric types

**Acceptance Criteria:**
- [ ] 6 widgets replaced by single component
- [ ] Metric code reduced by ~50%
- [ ] Localization tested

**Risk:** LOW - presentation only

---

## Phase 4: Integration & Testing (P3)

### Task P3-1: Dependency Graph Validation
**Priority:** P3 | **Estimate:** 3h | **Dependencies:** All P0, P1

**Scope:** Verify refactoring integrity
- Run static analysis
- Generate dependency graph visualization
- Document final architecture

**Acceptance Criteria:**
- [ ] Zero analyzer warnings
- [ ] Acyclic graph confirmed
- [ ] Architecture doc updated

**Risk:** VERY LOW - validation only

---

### Task P3-2: Regression Testing Suite
**Priority:** P3 | **Estimate:** 8h | **Dependencies:** All tasks

**Scope:** Comprehensive testing
- Full test suite (unit + widget)
- Manual smoke tests on device
- Performance profiling
- E2E user workflows

**Acceptance Criteria:**
- [ ] 100% test pass rate
- [ ] Coverage ≥85%
- [ ] No performance regression >5%

**Risk:** MEDIUM - may uncover issues

---

## Timeline

| Phase | Tasks | Hours | Cumulative |
|-------|-------|-------|------------|
| **Foundation** | P0-1, P0-2 | 14h | 14h |
| **Consolidation** | P1-1, P1-2, P1-3 | 21h | 35h |
| **Abstraction** | P2-1 → P2-4 | 22h | 57h |
| **Integration** | P3-1, P3-2 | 11h | 68h |

---

## Execution Strategy

1. **Sequential phases** - complete P0 before P1
2. **Parallel within phase** - P1-2 and P1-3 can run together
3. **Feature branch per task** - easy rollback
4. **Test before merge** - no regressions

---

## Files to Create

```
lib/shared/domain/abstractions/
├── i_exercise.dart
├── i_workout.dart
└── i_health_data_provider.dart

lib/core/data/mixins/
├── firestore_timeout_mixin.dart
├── firebase_error_mapper_mixin.dart
└── base_hive_datasource.dart

lib/shared/presentation/widgets/
├── reusable_modal_bottom_sheet.dart
├── shared_expandable_card.dart
├── metric_display.dart
└── status_badge.dart
```

---

## Risk Matrix

| Task | Risk | Mitigation |
|------|------|------------|
| P0-1 | HIGH | Interface-first design, staged rollout |
| P1-1 | HIGH | Deprecation warnings, parallel types |
| P2-2 | MEDIUM | Visual QA, feature flags |
| P2-3 | MEDIUM | Animation profiling |
| Others | LOW | Standard TDD approach |
