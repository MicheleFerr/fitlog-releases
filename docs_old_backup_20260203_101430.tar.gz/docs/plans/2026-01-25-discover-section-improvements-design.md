# Design: Miglioramenti Sezione Scopri

**Data**: 2026-01-25
**Stato**: Approvato
**Autore**: Claude + Michele (brainstorming session)

---

## Obiettivo

Migliorare la sezione "Scopri" e l'integrazione dei template personalizzati con tre interventi:

1. **Localizzazione nomi template** - I template predefiniti devono mostrare nomi nella lingua dell'utente
2. **Template custom prioritari** - Mostrare i template dell'utente al posto dei consigliati
3. **Auto-salvataggio template usati** - Quando l'utente usa un predefinito, salvarlo nei suoi custom

---

## Decisioni di Design

### 1. Localizzazione Nomi Template

**Approccio: Ibrido**

| Tipo Template | Strategia |
|---------------|-----------|
| **Predefiniti** | Chiavi ARB (es. `templateChestBackFoundation`) |
| **Custom utente** | Nome scelto dall'utente (invariato) |

**Rationale (analisi personas):**
- Marco/Roberto usano predefiniti → localizzati via ARB
- Luca/Chiara/Sofia creano custom → mantengono i nomi scelti

**Implementazione:**
- Aggiungere campo `nameKey` nel JSON dei template predefiniti
- Se `nameKey` presente → usa `l10n.{nameKey}`
- Se assente (custom) → usa `name` direttamente

```json
// superset_templates.json
{
  "id": "marco_chest_back_foundation",
  "nameKey": "templateChestBackFoundation",  // NEW
  "name": "Petto + Schiena Base",            // Fallback
  ...
}
```

```dart
// Nel widget
final displayName = template.nameKey != null
    ? l10n.getMessage(template.nameKey!)
    : template.name;
```

---

### 2. Template Custom Prioritari con Fallback

**Logica di visualizzazione:**

```
SE utente ha template custom:
  → Mostra "I Tuoi Superset" con i custom
  → Mostra link "Scopri altri template"
  → Tap sul link → espande sezione "Template Consigliati" sotto

SE utente NON ha template custom:
  → Mostra "Superset Consigliati" (predefiniti)
```

**UI Mockup:**

```
┌─────────────────────────────────────────────────────┐
│ 🔗 Superset                                         │
├─────────────────────────────────────────────────────┤
│ I Tuoi Template                                     │
│ ┌─────────┐ ┌─────────┐ ┌─────────┐                │
│ │Custom 1 │ │Custom 2 │ │Custom 3 │ →              │
│ └─────────┘ └─────────┘ └─────────┘                │
│                                                     │
│ 💡 Scopri altri template                    [▼]    │
├ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─┤
│ Template Consigliati                      [Nascondi]│
│ ┌─────────┐ ┌─────────┐ ┌─────────┐                │
│ │Petto+   │ │Gambe+   │ │Braccia  │ →              │
│ │Schiena  │ │Core     │ │Express  │                │
│ └─────────┘ └─────────┘ └─────────┘                │
└─────────────────────────────────────────────────────┘
```

**Stato espansione:**
- Salvato in `SharedPreferences` per utente
- Default: collapsed (nascosto)

---

### 3. Auto-salvataggio Template Usati

**Comportamento:**
Quando l'utente seleziona un template predefinito per usarlo in un workout:
1. Il template viene aggiunto al workout (comportamento attuale)
2. **NUOVO**: Una copia viene salvata nei template custom dell'utente

**Logica:**

```dart
Future<void> _usePredefinedSuperset(SupersetTemplate template) async {
  // 1. Aggiungi al workout (esistente)
  _addSupersetToWorkout(template);

  // 2. NUOVO: Salva nei custom se non già presente
  final customTemplates = await repository.getCustomTemplates();
  final alreadySaved = customTemplates.any((t) => t.id == template.id);

  if (!alreadySaved) {
    final customCopy = template.copyWith(
      isCustom: true,
      createdAt: DateTime.now(),
    );
    await repository.saveCustomTemplate(customCopy);
  }
}
```

**Nota sui limiti:**
- Il salvataggio automatico rispetta i limiti tier (maxCustomSupersets)
- Se limite raggiunto → il template viene usato ma NON salvato
- Mostrare toast informativo: "Template usato. Passa a Premium per salvarlo nei tuoi preferiti."

---

## Impatto per Personas

| Persona | Prima | Dopo | Impatto |
|---------|-------|------|---------|
| **Marco** | Vede solo predefiniti, non sa cosa scegliere | Usa un template → diventa suo, sempre accessibile | ✅ Positivo |
| **Chiara** | Deve cercare tra tanti template | I suoi in cima, zero scroll | ✅✅ Molto positivo |
| **Luca** | Predefiniti inutili per lui | Vede solo i suoi, ignora il resto | ✅ Positivo |
| **Sofia** | Vuole ispirazione | Custom + "Scopri altri" per esplorare | ✅ Positivo |
| **Roberto** | Vuole efficienza | Template usati sempre pronti | ✅ Positivo |

**Nessun impatto negativo** su nessuna persona.

---

## File da Modificare

### Fase 1: Localizzazione Template

| File | Modifica |
|------|----------|
| `assets/data/superset_templates.json` | Aggiungere `nameKey` per ogni template |
| `assets/data/dropset_templates.json` | Aggiungere `nameKey` per ogni template |
| `assets/data/rest_pause_templates.json` | Aggiungere `nameKey` per ogni template |
| `assets/i18n/app_en.arb` | Aggiungere chiavi localizzazione template |
| `assets/i18n/app_it.arb` | Aggiungere chiavi localizzazione template |
| `lib/features/workout/domain/entities/superset_template.dart` | Aggiungere campo `nameKey` |
| `lib/features/workout/domain/entities/dropset_template.dart` | Aggiungere campo `nameKey` |
| `lib/features/workout/domain/entities/rest_pause_template.dart` | Aggiungere campo `nameKey` |

### Fase 2: UI Template Custom Prioritari

| File | Modifica |
|------|----------|
| `lib/features/workout_templates/presentation/screens/templates_home_screen.dart` | Refactor `_buildAdvancedTechniqueSection` per logica custom/predefiniti |
| `lib/features/workout/presentation/providers/superset_template_provider.dart` | Aggiungere provider combinato custom+predefiniti |
| `lib/features/workout/presentation/providers/dropset_template_provider.dart` | Stesso refactor |
| `lib/features/workout/presentation/providers/rest_pause_template_provider.dart` | Stesso refactor |

### Fase 3: Auto-salvataggio

| File | Modifica |
|------|----------|
| `lib/features/workout_templates/presentation/screens/templates_home_screen.dart` | Modificare `_usePredefinedSuperset`, `_usePredefinedDropset`, `_usePredefinedRestPause` |
| `lib/features/workout/data/repositories/superset_template_repository.dart` | Verificare metodo `saveCustomTemplate` gestisca duplicati |

---

## Rischi e Mitigazioni

| Rischio | Probabilità | Mitigazione |
|---------|-------------|-------------|
| Performance con molti custom | Bassa | I custom sono pochi (limite tier), lista corta |
| Confusione UI espansione | Media | Animazione chiara, stato persistito |
| Limite tier raggiunto silenziosamente | Media | Toast informativo quando auto-save fallisce |

---

## Metriche di Successo

- [ ] Template predefiniti mostrano nome localizzato
- [ ] Utenti con custom vedono i loro template in cima
- [ ] "Scopri altri" espande/collapse correttamente
- [ ] Template usati salvati automaticamente nei custom
- [ ] Limiti tier rispettati con feedback utente

---

## Approvazione

- [x] Analisi personas completata
- [x] Nessun impatto negativo identificato
- [x] Design approvato da Michele (2026-01-25)
