# 💬 Coach-Athlete Chat - Firebase Design

**Data**: Dicembre 2024
**Status**: Design per review
**Effort stimato**: 2-3 giorni

---

## 🎯 Obiettivo

Chat 1:1 minimalista tra coach e atleta per:
- Feedback su workout completati
- Domande su esercizi/tecnica
- Comunicazioni generali

**NON include** (out of scope): group chat, video call, voice messages, threads.

---

## 📐 Firestore Schema

### Collection: `conversations`

```
conversations/{conversationId}/
├── metadata (document fields):
│   ├── id: string
│   ├── coachId: string
│   ├── athleteId: string
│   ├── coachName: string (denormalized)
│   ├── athleteName: string (denormalized)
│   ├── lastMessage: string (preview, max 100 chars)
│   ├── lastMessageAt: timestamp
│   ├── lastMessageSenderId: string
│   ├── coachUnreadCount: int
│   ├── athleteUnreadCount: int
│   ├── createdAt: timestamp
│   └── updatedAt: timestamp
│
└── messages/ (subcollection)
    └── {messageId}/
        ├── id: string
        ├── senderId: string
        ├── senderName: string
        ├── text: string
        ├── type: "text" | "image" | "workout_link"
        ├── metadata: map (optional, for workout links)
        ├── createdAt: timestamp
        ├── readAt: timestamp | null
        └── isDeleted: bool
```

### Perché questa struttura?

| Scelta | Razionale |
|--------|-----------|
| `conversationId` = `{coachId}_{athleteId}` | Lookup O(1), no query |
| `lastMessage` denormalizzato | Lista conversazioni senza leggere messaggi |
| `unreadCount` per ruolo | Badge notifica senza query |
| Subcollection `messages` | Paginazione efficiente |

---

## 🔒 Firestore Rules

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    // Conversations
    match /conversations/{conversationId} {
      // Solo coach o atleta della conversazione
      allow read, write: if isParticipant(conversationId);

      // Messages subcollection
      match /messages/{messageId} {
        allow read: if isParticipant(conversationId);
        allow create: if isParticipant(conversationId)
                      && request.resource.data.senderId == request.auth.uid;
        allow update: if isParticipant(conversationId)
                      && resource.data.senderId == request.auth.uid;
        allow delete: if false; // Soft delete only
      }
    }

    function isParticipant(conversationId) {
      let parts = conversationId.split('_');
      return request.auth.uid == parts[0] || request.auth.uid == parts[1];
    }
  }
}
```

---

## 🧩 Dart Entities

### ChatConversation

```dart
/// lib/features/chat/domain/entities/chat_conversation.dart

@freezed
abstract class ChatConversation with _$ChatConversation {
  const factory ChatConversation({
    required String id,
    required String coachId,
    required String athleteId,
    required String coachName,
    required String athleteName,
    String? lastMessage,
    DateTime? lastMessageAt,
    String? lastMessageSenderId,
    @Default(0) int coachUnreadCount,
    @Default(0) int athleteUnreadCount,
    required DateTime createdAt,
    required DateTime updatedAt,
  }) = _ChatConversation;

  const ChatConversation._();

  /// Get unread count for current user
  int unreadCountFor(String userId) {
    if (userId == coachId) return coachUnreadCount;
    if (userId == athleteId) return athleteUnreadCount;
    return 0;
  }

  /// Check if user is coach in this conversation
  bool isCoach(String userId) => userId == coachId;

  /// Get the other participant's name
  String otherParticipantName(String myUserId) {
    return myUserId == coachId ? athleteName : coachName;
  }

  /// Generate conversation ID from participants
  static String generateId(String coachId, String athleteId) {
    return '${coachId}_$athleteId';
  }

  factory ChatConversation.fromJson(Map<String, dynamic> json) =>
      _$ChatConversationFromJson(json);
}
```

### ChatMessage

```dart
/// lib/features/chat/domain/entities/chat_message.dart

enum MessageType {
  text,
  image,
  workoutLink,
}

@freezed
abstract class ChatMessage with _$ChatMessage {
  const factory ChatMessage({
    required String id,
    required String senderId,
    required String senderName,
    required String text,
    @Default(MessageType.text) MessageType type,
    Map<String, dynamic>? metadata,
    required DateTime createdAt,
    DateTime? readAt,
    @Default(false) bool isDeleted,
  }) = _ChatMessage;

  const ChatMessage._();

  /// Check if message is from current user
  bool isFromMe(String myUserId) => senderId == myUserId;

  /// Check if message has been read
  bool get isRead => readAt != null;

  /// Format time for display (e.g., "14:32" or "Ieri")
  String formattedTime(BuildContext context) {
    // Implementation with intl
  }

  factory ChatMessage.fromJson(Map<String, dynamic> json) =>
      _$ChatMessageFromJson(json);
}
```

---

## 🏗️ Repository Interface

```dart
/// lib/features/chat/domain/repositories/chat_repository.dart

abstract class ChatRepository {
  /// Get all conversations for current user (coach or athlete)
  Stream<List<ChatConversation>> watchConversations();

  /// Get or create conversation between coach and athlete
  Future<ChatConversation> getOrCreateConversation({
    required String coachId,
    required String athleteId,
    required String coachName,
    required String athleteName,
  });

  /// Watch messages for a conversation (paginated)
  Stream<List<ChatMessage>> watchMessages({
    required String conversationId,
    int limit = 50,
    DateTime? before,
  });

  /// Send a text message
  Future<ChatMessage> sendMessage({
    required String conversationId,
    required String text,
    MessageType type = MessageType.text,
    Map<String, dynamic>? metadata,
  });

  /// Mark messages as read
  Future<void> markAsRead({
    required String conversationId,
    required List<String> messageIds,
  });

  /// Get total unread count for badge
  Stream<int> watchTotalUnreadCount();
}
```

---

## 🎨 UI Design

### 1. Conversations List Screen

```
┌─────────────────────────────────────┐
│  ← Messaggi                         │
├─────────────────────────────────────┤
│                                     │
│  ┌─────────────────────────────────┐│
│  │ 🔵 Giulia R.              14:32 ││
│  │ Coach: Ottimo workout oggi!     ││
│  └─────────────────────────────────┘│
│                                     │
│  ┌─────────────────────────────────┐│
│  │ 👤 Marco B.           ● 2  Ieri ││
│  │ Come faccio lo squat...         ││
│  └─────────────────────────────────┘│
│                                     │
│  ┌─────────────────────────────────┐│
│  │ 👤 Sara T.              Lun     ││
│  │ Grazie per il programma!        ││
│  └─────────────────────────────────┘│
│                                     │
│  ─────── Nessun altro messaggio ────│
│                                     │
└─────────────────────────────────────┘

● 2 = unread badge
🔵 = online (optional, future)
```

### 2. Chat Screen

```
┌─────────────────────────────────────┐
│  ← Marco B.                    •••  │
├─────────────────────────────────────┤
│                                     │
│                          ┌─────────┐│
│                          │ Ciao!   ││
│                          │   14:30 ││
│                          └─────────┘│
│                                     │
│  ┌──────────────────────┐          │
│  │ Come faccio lo squat │          │
│  │ bulgaro? Non capisco │          │
│  │ la posizione.        │          │
│  │ 14:32                │          │
│  └──────────────────────┘          │
│                                     │
│                          ┌─────────┐│
│                          │ Ti mando││
│                          │ un video││
│                          │   14:35 ││
│                          └─────────┘│
│                                     │
│  ┌──────────────────────┐          │
│  │ 🎥 Squat Bulgaro     │          │
│  │ [Workout Link]       │          │
│  │ 14:36                │          │
│  └──────────────────────┘          │
│                                     │
├─────────────────────────────────────┤
│ ┌─────────────────────────────┐ 📤 │
│ │ Scrivi un messaggio...      │    │
│ └─────────────────────────────┘    │
└─────────────────────────────────────┘
```

### 3. Entry Points

```
Coach:
├── Athletes List → AthleteCard → 💬 icon
├── Athlete Detail → Chat button
└── TabBar → Messages tab (con badge)

Atleta:
├── Profile → "Il mio Coach" → Chat
├── TabBar → Messages tab (se ha coach)
└── Push notification → Opens chat
```

---

## ⚡ Ottimizzazioni

### 1. Cache Locale (Hive)

```dart
/// Cached messages per conversation
@HiveType(typeId: 50)
class CachedConversation {
  @HiveField(0) final String id;
  @HiveField(1) final List<ChatMessage> messages;
  @HiveField(2) final DateTime lastSyncAt;
  @HiveField(3) final String? lastMessageId;
}
```

**Flow:**
```
1. Open chat → Load from Hive (instant)
2. Start Firestore listener (only new messages)
3. Merge and display
4. Save to Hive on new messages
```

### 2. Paginazione

```dart
// Initial load: last 50 messages
.orderBy('createdAt', descending: true)
.limit(50)

// Load more: before oldest loaded
.orderBy('createdAt', descending: true)
.endBefore([oldestTimestamp])
.limit(50)
```

### 3. Batch Writes

```dart
// Mark multiple as read in single write
final batch = firestore.batch();
for (final messageId in unreadIds) {
  batch.update(
    messagesRef.doc(messageId),
    {'readAt': FieldValue.serverTimestamp()},
  );
}
// Update conversation unread count
batch.update(conversationRef, {'${role}UnreadCount': 0});
await batch.commit(); // 1 write operation
```

### 4. Debounced Typing (Future)

```dart
// Optional: typing indicator
// Uses Firestore presence with TTL
conversations/{id}/typing/{oderId}: {
  isTyping: true,
  expiresAt: now + 5 seconds
}
```

---

## 📱 Push Notifications

### Cloud Function

```typescript
// functions/src/chat.ts

export const onNewMessage = functions.firestore
  .document('conversations/{conversationId}/messages/{messageId}')
  .onCreate(async (snap, context) => {
    const message = snap.data();
    const { conversationId } = context.params;

    // Get conversation to find recipient
    const convDoc = await admin.firestore()
      .collection('conversations')
      .doc(conversationId)
      .get();

    const conv = convDoc.data();
    const recipientId = message.senderId === conv.coachId
      ? conv.athleteId
      : conv.coachId;

    // Get recipient's FCM token
    const userDoc = await admin.firestore()
      .collection('users')
      .doc(recipientId)
      .get();

    const fcmToken = userDoc.data()?.fcmToken;
    if (!fcmToken) return;

    // Send push
    await admin.messaging().send({
      token: fcmToken,
      notification: {
        title: message.senderName,
        body: message.text.substring(0, 100),
      },
      data: {
        type: 'chat_message',
        conversationId,
        messageId: snap.id,
      },
      apns: {
        payload: {
          aps: {
            badge: 1,
            sound: 'default',
          },
        },
      },
    });
  });
```

---

## 📁 File Structure

```
lib/features/chat/
├── chat.dart                          # Barrel export
├── domain/
│   ├── entities/
│   │   ├── chat_conversation.dart
│   │   ├── chat_conversation.freezed.dart
│   │   ├── chat_conversation.g.dart
│   │   ├── chat_message.dart
│   │   ├── chat_message.freezed.dart
│   │   └── chat_message.g.dart
│   └── repositories/
│       └── chat_repository.dart
├── data/
│   ├── repositories/
│   │   └── chat_repository_impl.dart
│   └── datasources/
│       ├── chat_remote_datasource.dart
│       └── chat_local_datasource.dart  # Hive cache
└── presentation/
    ├── providers/
    │   └── chat_providers.dart
    ├── screens/
    │   ├── conversations_list_screen.dart
    │   └── chat_screen.dart
    └── widgets/
        ├── conversation_tile.dart
        ├── message_bubble.dart
        ├── chat_input.dart
        └── unread_badge.dart
```

---

## 📋 Implementation Checklist

### Phase 1: Core (Day 1)
- [ ] Firestore schema setup
- [ ] Security rules
- [ ] `ChatConversation` entity
- [ ] `ChatMessage` entity
- [ ] `ChatRepository` interface
- [ ] `ChatRepositoryImpl` (basic)

### Phase 2: UI (Day 2)
- [ ] `ConversationsListScreen`
- [ ] `ChatScreen`
- [ ] `ConversationTile` widget
- [ ] `MessageBubble` widget
- [ ] `ChatInput` widget
- [ ] Riverpod providers

### Phase 3: Polish (Day 3)
- [ ] Hive cache layer
- [ ] Paginazione scroll
- [ ] Cloud Function push notification
- [ ] Unread badge in navigation
- [ ] Entry points (AthleteCard, AthleteDetail)
- [ ] Traduzioni IT/EN

---

## 🔢 Stima Costi (Recap)

| Scenario | Letture/mese | Scritture/mese | Costo |
|----------|--------------|----------------|-------|
| 50 coach | ~150k | ~90k | **€0.50** |
| 200 coach | ~600k | ~360k | **€2.00** |
| 1000 coach | ~3M | ~1.8M | **€10.00** |

Con cache Hive + paginazione, i costi rimangono trascurabili.

---

## ✅ Domande Aperte

1. **Workout link**: Permettere di linkare workout specifici nella chat?
2. **Immagini**: Supportare invio foto (form check)?
3. **Read receipts UI**: Mostrare ✓✓ come WhatsApp?
4. **Typing indicator**: Implementare subito o dopo?

---

## 📚 References

- [Firestore Chat Tutorial](https://firebase.google.com/docs/firestore/solutions/presence)
- [Flutter Chat UI Package](https://pub.dev/packages/flutter_chat_ui)
- [FCM Flutter](https://firebase.flutter.dev/docs/messaging/overview/)
