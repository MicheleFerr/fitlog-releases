# Template-Aware Muscle Balance Design

**Date**: 2025-12-20
**Status**: Draft
**Author**: Claude + Michele

---

## Problem Statement

The current `MuscleBalanceCalculator` analyzes only **past workout history**. This creates confusing scenarios:

1. **False Positives**: "Back neglected!" - but user has a "Back Day" template scheduled
2. **Redundant Suggestions**: System suggests "Add lat pulldown" when exercise is already in 3 templates
3. **Lack of Context**: User sees warnings without knowing their programming addresses them

## Goal

Create a system that considers **both history and planned templates** to:
- Reduce severity of warnings when templates contain exercises for "neglected" muscles
- Filter exercise suggestions already present in templates
- Show user the system "understands" their programming

## Inspiration

> "Fitbod's personalization engine automatically builds muscle-balanced splits... If your push muscles are overworked, Fitbod shifts volume to pull movements."

**Key Difference**: We don't auto-generate workouts, but **inform** users intelligently about their existing plans.

---

## Architecture Decision

### Selected Approach: Post-Processing (Option A)

```
┌─────────────────────────────────────────────────────────┐
│  ExerciseHistory          WorkoutTemplates              │
│         │                        │                      │
│         ▼                        ▼                      │
│  MuscleBalanceCalculator   TemplateAnalyzer             │
│         │                        │                      │
│         ▼                        ▼                      │
│  MuscleBalanceMetrics      TemplateCoverage             │
│         │                        │                      │
│         └──────────┬─────────────┘                      │
│                    ▼                                    │
│         TemplateAwareBalanceService                     │
│                    │                                    │
│                    ▼                                    │
│         AdjustedNeglectedMuscles                        │
└─────────────────────────────────────────────────────────┘
```

**Rationale**:
- Does not modify core balance calculation
- Template logic is separate and testable
- Easily disabled/configurable
- Follows Single Responsibility Principle

### Rejected Alternatives

**Option B: Unified Calculation** - Modify `MuscleBalanceCalculator.calculateBalance()` to accept templates.
- Couples different concerns
- Harder to test
- Breaks SRP

**Option C: Pre-Filtering** - Calculate "planned volume" from templates and add to history.
- Difficult to estimate future volume (how many sets? what weight?)
- Mixes real data with estimates

---

## Domain Model

### New Entities

```dart
/// Coverage of a muscle in user's templates
class TemplateMuscleScore {
  /// Muscle group name (lowercase)
  final String muscleName;

  /// Number of templates containing exercises for this muscle
  final int templateCount;

  /// Total exercises targeting this muscle across all templates
  final int totalExercises;

  /// Estimated sets per week (sum of template sets × usage frequency)
  final int estimatedWeeklySets;

  /// Normalized coverage score (0.0 - 1.0)
  /// 0.0 = not covered at all
  /// 1.0 = well covered (≥3 templates or ≥9 exercises)
  final double coverageScore;

  /// List of template names containing this muscle
  final List<String> templateNames;
}

/// Result of template analysis
class TemplateCoverageResult {
  /// Coverage scores per muscle
  final Map<String, TemplateMuscleScore> muscleScores;

  /// Exercise name → list of template names containing it
  final Map<String, List<String>> exerciseToTemplates;

  /// Check if an exercise is already planned
  bool isExercisePlanned(String exerciseName) =>
      exerciseToTemplates.containsKey(exerciseName.toLowerCase());

  /// Get templates containing an exercise
  List<String> getTemplatesForExercise(String exerciseName) =>
      exerciseToTemplates[exerciseName.toLowerCase()] ?? [];

  /// Get coverage for a muscle
  TemplateMuscleScore? getCoverage(String muscleName) =>
      muscleScores[muscleName.toLowerCase()];
}

/// Adjusted neglected muscle with template context
class AdjustedNeglectedMuscle {
  /// Original neglected muscle data
  final NeglectedMuscle original;

  /// Adjusted severity based on template coverage
  final NeglectSeverity adjustedSeverity;

  /// Whether severity was reduced due to template coverage
  final bool hasPlannedExercises;

  /// Templates covering this muscle
  final List<String> coveringTemplates;

  /// Number of planned exercises for this muscle
  final int plannedExerciseCount;
}
```

### New Service

```dart
/// Template-Aware Balance Service
///
/// Combines MuscleBalanceMetrics with template analysis to:
/// 1. Adjust severity of neglected muscles
/// 2. Filter suggestions already covered by templates
///
/// **Usage**:
/// ```dart
/// final service = TemplateAwareBalanceService();
///
/// // Step 1: Analyze template coverage
/// final coverage = service.analyzeTemplateCoverage(
///   templates: userTemplates,
///   exerciseMuscleMap: muscleMap,
/// );
///
/// // Step 2: Adjust neglected muscles
/// final adjusted = service.adjustNeglectedMuscles(
///   neglected: detector.detectNeglectedMuscles(balance),
///   coverage: coverage,
/// );
///
/// // Step 3: Filter suggestions
/// final filtered = service.filterAlreadyPlanned(
///   suggestions: engine.getSuggestions(neglected),
///   coverage: coverage,
/// );
/// ```
class TemplateAwareBalanceService {

  /// Analyze which muscles are covered by templates
  ///
  /// Scans all exercises in templates and maps them to muscle groups
  /// using the exerciseMuscleMap.
  TemplateCoverageResult analyzeTemplateCoverage({
    required List<WorkoutTemplate> templates,
    required Map<String, ExerciseMuscleData> exerciseMuscleMap,
  });

  /// Adjust neglected muscles based on template coverage
  ///
  /// Severity adjustment rules:
  /// - If neglected muscle is in ≥2 templates → reduce severity by 1 level
  /// - If neglected muscle is in ≥3 templates → reduce severity by 2 levels
  /// - CRITICAL never drops below MEDIUM
  List<AdjustedNeglectedMuscle> adjustNeglectedMuscles({
    required List<NeglectedMuscle> neglected,
    required TemplateCoverageResult coverage,
  });

  /// Filter suggestions that are already in templates
  ///
  /// By default, removes exercises already present in any template.
  /// Can optionally include them with "planned" badge.
  List<ExerciseSuggestion> filterAlreadyPlanned({
    required List<ExerciseSuggestion> suggestions,
    required TemplateCoverageResult coverage,
    bool includeWithBadge = false,
  });
}
```

---

## UI Changes

### 1. Neglected Muscle Card - "Planned" Badge

```
┌──────────────────────────────────────────────────────┐
│ 🎯 BACK                         [MEDIUM] [⏰ Planned]│
│                                                      │
│ Volume: 3.2%                                         │
│ 📅 In 2 templates: "Pull Day", "Full Body A"         │
│                                                      │
│ Suggestions:                                         │
│ ├─ Lat Pulldown (in "Pull Day") ✓                   │
│ └─ Seated Row                      [+ Add]          │
└──────────────────────────────────────────────────────┘
```

**Changes to `ExerciseSuggestionsWidget`**:
- Add `isPlanned` boolean to display "Planned" badge
- Show list of covering templates below muscle name
- Exercises already in templates show checkmark instead of "Add" button

### 2. Exercise Suggestions - "Already Planned" Filter

- Default: hide exercises already in templates
- Toggle: "Show planned exercises too"
- Badge on each suggestion: "In [Template Name]"

### 3. Balance Score - Improved Tooltip

```
Balance Score: 6.5/10
"2 neglected muscles, but both
covered by your planned templates"
```

---

## Implementation Phases

### Phase 1: MVP (Core Logic)

**Files to create**:
- `lib/features/analytics/domain/entities/template_coverage.dart`
- `lib/features/analytics/domain/services/template_aware_balance_service.dart`

**Files to modify**:
- `lib/features/analytics/domain/services/exercise_suggestion_engine.dart`
  - Add filter for exercises already in templates
- `lib/features/analytics/presentation/providers/exercise_suggestion_provider.dart`
  - Inject template coverage into suggestion engine

**Tasks**:
- [ ] Create `TemplateMuscleScore` entity
- [ ] Create `TemplateCoverageResult` entity
- [ ] Implement `TemplateAwareBalanceService.analyzeTemplateCoverage()`
- [ ] Add `filterAlreadyPlanned()` to suggestion engine
- [ ] Create provider for template coverage
- [ ] Unit tests for coverage analysis

### Phase 2: Severity Adjustment

**Files to modify**:
- `lib/features/analytics/domain/services/template_aware_balance_service.dart`
  - Implement `adjustNeglectedMuscles()`
- `lib/features/analytics/domain/services/neglected_muscle_detector.dart`
  - Add `AdjustedNeglectedMuscle` entity
- `lib/features/analytics/presentation/widgets/exercise_suggestions_widget.dart`
  - Show "Planned" badge
  - Show covering templates list

**Tasks**:
- [ ] Create `AdjustedNeglectedMuscle` entity
- [ ] Implement severity adjustment logic
- [ ] Add "Planned" badge to UI
- [ ] Show covering templates in card
- [ ] Unit tests for adjustment logic

### Phase 3: Polish

**Files to modify**:
- `lib/features/analytics/presentation/widgets/exercise_suggestions_widget.dart`
  - Add toggle for showing planned exercises
  - Add "In [Template]" badge per suggestion
- `lib/features/analytics/presentation/tabs/muscle_balance_tab.dart`
  - Improve balance score tooltip

**Tasks**:
- [ ] Add toggle "Show planned exercises"
- [ ] Add per-exercise template badge
- [ ] Improve balance score tooltip
- [ ] Integration tests

---

## Provider Integration

```dart
/// Provider for template coverage analysis
@riverpod
Future<TemplateCoverageResult> templateCoverage(Ref ref) async {
  final templates = await ref.watch(workoutTemplatesProvider.future);
  final muscleMap = await ref.watch(exerciseMuscleMapProvider.future);

  final service = TemplateAwareBalanceService();
  return service.analyzeTemplateCoverage(
    templates: templates,
    exerciseMuscleMap: muscleMap,
  );
}

/// Provider for adjusted neglected muscles
@riverpod
Future<List<AdjustedNeglectedMuscle>> adjustedNeglectedMuscles(
  Ref ref,
  MuscleBalanceMetrics balance,
) async {
  final coverage = await ref.watch(templateCoverageProvider.future);
  final detector = NeglectedMuscleDetector();
  final neglected = detector.detectNeglectedMuscles(balance);

  final service = TemplateAwareBalanceService();
  return service.adjustNeglectedMuscles(
    neglected: neglected,
    coverage: coverage,
  );
}
```

---

## Edge Cases

1. **Empty templates**: No templates → use original neglected muscles unchanged
2. **Template without exercises**: Skip templates with no exercises
3. **Exercise not in muscleMap**: Use exercise category as fallback
4. **Superset exercises**: Analyze all sub-exercises in superset
5. **Custom exercises**: Check custom exercise focus muscles

---

## Success Metrics

1. **Reduced false positives**: Fewer "neglected" warnings when user has planned templates
2. **More actionable suggestions**: Only suggest exercises not already planned
3. **User satisfaction**: User feels system "understands" their programming

---

## Open Questions

1. **Should we weight by template usage frequency?**
   - Templates used more often could have higher weight
   - Adds complexity but more accurate

2. **Should we consider time since last template use?**
   - If "Pull Day" was used yesterday, back is probably not neglected today
   - Requires tracking template usage dates

3. **Should we show "scheduled for today" differently?**
   - If user has a template they typically do on Fridays, show special badge on Friday
   - Requires day-of-week tracking (complex)

---

## References

- [Fitbod Algorithm](https://www.fitbod.me/) - Auto-balance approach
- [MuscleBalanceCalculator](../lib/features/analytics/domain/services/muscle_balance_calculator.dart)
- [NeglectedMuscleDetector](../lib/features/analytics/domain/services/neglected_muscle_detector.dart)
- [ExerciseSuggestionEngine](../lib/features/analytics/domain/services/exercise_suggestion_engine.dart)
