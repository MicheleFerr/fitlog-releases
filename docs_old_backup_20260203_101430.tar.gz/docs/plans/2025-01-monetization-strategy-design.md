# 💰 FitLog Monetization Strategy - Design Document

**Data**: Dicembre 2024
**Autore**: Claude + Michele
**Status**: Draft per discussione

---

## 📊 Ricerca di Mercato

### Competitor Pricing (Coach Platforms)

| Piattaforma | Entry | Mid | Pro | Modello |
|-------------|-------|-----|-----|---------|
| [TrueCoach](https://truecoach.co/pricing/) | $20/mo (5 atleti) | $53/mo (20) | $107/mo (50) | Subscription |
| [TrainHeroic](https://www.trainheroic.com/coach/) | $10/mo + fee | $75/mo (26+) | $1,800/yr | Subscription + Marketplace |
| [Hevy Coach](https://hevycoach.com/pricing/) | $25/mo (10) | $50/mo (25) | $90-160/mo | Subscription |

**Insight chiave**: Tutti usano subscription, ma TrainHeroic ha anche un **Marketplace** dove i coach vendono programmi one-time.

### Prezzi Workout Programs (One-time)

| Tipo | Range Prezzo | Fonte |
|------|-------------|-------|
| PDF workout plan | $10-20 | [Sellfy](https://blog.sellfy.com/sell-workout-plans-online/) |
| eBook programma | $20-50 | [Sellfy](https://blog.sellfy.com/sell-workout-plans-online/) |
| Video course (5-12 settimane) | $80-200 | [Sellfy](https://blog.sellfy.com/sell-workout-plans-online/) |
| Bundle transazionale | $75-110 | [Uscreen study](https://www.exercise.com/grow/how-to-make-money-selling-workout-plans-online/) |

### Psicologia dei Micro-acquisti

Secondo la ricerca ([SubCodevs](https://subcodevs.com/micro%E2%80%91transactions-tiny-payments-monumental-impact-on-app-monetization/)):

- **Charm pricing**: $9.99 invece di $10 → +30% conversion
- **Low-friction**: Pagamenti piccoli percepiti come "non-eventi"
- **Urgency**: Timer countdown → +22% vendite
- **Personalization**: Offerte personalizzate → +400% conversion

---

## 🎯 Proposta FitLog: Modello Ibrido

### Filosofia Core

```
╔════════════════════════════════════════════════════════════════╗
║  I TEMPLATE COSTANO NIENTE su Firestore (~$0.001 per doc).    ║
║  Venderli one-time = margine quasi 100%.                      ║
║  L'abbonamento è per VALORE CONTINUO (analytics, supporto).   ║
╚════════════════════════════════════════════════════════════════╝
```

### Tier Structure Proposta

```
┌─────────────────────────────────────────────────────────────────┐
│                         FREE TIER                               │
├─────────────────────────────────────────────────────────────────┤
│  👥 Atleti: 3 max                                               │
│  📋 Template: 5 max                                             │
│  📊 Analytics: 7 giorni                                         │
│  💬 Supporto: Community/FAQ                                     │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                     PRO - €9.99/mese                            │
├─────────────────────────────────────────────────────────────────┤
│  👥 Atleti: 15 max                                              │
│  📋 Template: 20 max                                            │
│  📊 Analytics: 1 anno storico                                   │
│  💬 Supporto: Email prioritario                                 │
│  🔔 Notifiche avanzate                                          │
│  📤 Export CSV                                                  │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                   PRO+ - €17.99/mese                            │
├─────────────────────────────────────────────────────────────────┤
│  👥 Atleti: ILLIMITATI                                          │
│  📋 Template: ILLIMITATI                                        │
│  📊 Analytics: Storico completo + grafici avanzati              │
│  💬 Supporto: Chat prioritario                                  │
│  🎨 Branding personalizzato                                     │
│  📱 White-label (nome coach su app atleta)                      │
│  📈 Report PDF automatici settimanali                           │
└─────────────────────────────────────────────────────────────────┘
```

### One-Time Purchases (Add-ons)

| Pack | Prezzo | Cosa Include | Target |
|------|--------|--------------|--------|
| **+10 Template** | €4.99 | 10 slot template aggiuntivi | Tutti i tier |
| **+5 Atleti** | €6.99 | 5 slot atleta aggiuntivi | Free/Pro |
| **Export PDF Pro** | €2.99 | Export schede in PDF branded | Tutti |
| **Storico Illimitato** | €9.99 | Analytics senza limite tempo | Free/Pro |
| **Pack Coach Starter** | €14.99 | +10 template + +5 atleti + PDF | Bundle |

---

## 💡 Razionale Economico

### Costo Firestore per Template

```
1 template = ~2KB documento
1000 template = 2MB storage = $0.026/mese
10,000 scritture = $0.18
10,000 letture = $0.06

TOTALE per 1000 template attivi: ~$0.27/mese
```

**Margine vendita pack template**: ~99.9%

### Proiezione Revenue (100 coach attivi)

| Scenario | Mix | Revenue Mensile |
|----------|-----|-----------------|
| Solo Free | 100% free | €0 |
| 20% Pro | 20 × €9.99 | €200 |
| 10% Pro + 10% Pro+ | 10×€9.99 + 10×€17.99 | €280 |
| + One-time (avg 2/coach) | +200 × €5 avg | €1,000 boost |

### Perché One-Time Funziona per Template

1. **Basso rischio per utente**: "Provo €4.99, se non mi serve pazienza"
2. **Impulse purchase**: Prezzo sotto €5 = decisione veloce
3. **No subscription fatigue**: Non si aggiunge all'abbonamento
4. **Upgrade path**: Free → compra pack → vede valore → passa a Pro

---

## 🧪 Ipotesi da Validare

### Test A/B Proposti

| Test | Variante A | Variante B | Metrica |
|------|-----------|-----------|---------|
| Pricing template pack | €4.99 | €2.99 | Conversion rate |
| Bundle vs singoli | Pack €14.99 | Singoli €4.99×3 | Revenue totale |
| Limite free | 3 atleti | 5 atleti | Conversion to Pro |
| Anchor price | Mostra Pro+ prima | Mostra Pro prima | Pro+ uptake |

### Domande Aperte

1. **Atleti gratuiti per Pro+?** Se Pro+ = illimitato, ha senso far pagare pack atleti?
2. **Template marketplace?** I coach potrebbero vendere template ad altri coach?
3. **Lifetime deal?** €99 una tantum = Pro per sempre? (alto rischio)
4. **Referral?** Coach invita coach = 1 mese gratis?

---

## 🔧 Implementazione Tecnica

### Firestore Structure

```
users/{coachId}/
├── subscription: {
│   tier: "free" | "pro" | "pro_plus",
│   expiresAt: timestamp,
│   cancelledAt: timestamp | null
│ }
├── purchases: [
│   { type: "template_pack_10", purchasedAt: timestamp, quantity: 1 },
│   { type: "athlete_pack_5", purchasedAt: timestamp, quantity: 2 }
│ ]
├── limits: {
│   maxAthletes: 3,  // base + purchased
│   maxTemplates: 5, // base + purchased
│   analyticsHistoryDays: 7
│ }
```

### RevenueCat Integration

```dart
// Subscription products
static const kProMonthly = 'fitlog_pro_monthly';
static const kProPlusMonthly = 'fitlog_pro_plus_monthly';

// One-time products
static const kTemplatePack10 = 'fitlog_template_pack_10';
static const kAthletePack5 = 'fitlog_athlete_pack_5';
static const kPdfExport = 'fitlog_pdf_export_unlock';
```

### Limit Enforcement

```dart
class CoachLimitsService {
  Future<CoachLimits> calculateLimits(String coachId) async {
    final subscription = await _getSubscription(coachId);
    final purchases = await _getPurchases(coachId);

    return CoachLimits(
      maxAthletes: _baseAthletes(subscription.tier) +
                  purchases.athletePacks * 5,
      maxTemplates: _baseTemplates(subscription.tier) +
                   purchases.templatePacks * 10,
      analyticsHistoryDays: _analyticsHistory(subscription.tier),
    );
  }
}
```

---

## 📋 Next Steps

1. [ ] Validare pricing con 3-5 coach reali (interviste)
2. [ ] Creare mockup UI per upgrade flow
3. [ ] Setup RevenueCat con prodotti test
4. [ ] Implementare `CoachLimitsService`
5. [ ] A/B test su pricing template pack

---

## 📚 Fonti

- [Fitness App Monetization - Qodeca](https://www.qodeca.com/insights/article/monetizing-fitness-apps/)
- [Micro-transactions Impact - SubCodevs](https://subcodevs.com/micro%E2%80%91transactions-tiny-payments-monumental-impact-on-app-monetization/)
- [TrueCoach Pricing](https://truecoach.co/pricing/)
- [Hevy Coach Pricing](https://hevycoach.com/pricing/)
- [TrainHeroic Coach](https://www.trainheroic.com/coach/)
- [How to Sell Workout Programs - Sellfy](https://blog.sellfy.com/sell-workout-plans-online/)
- [Fitness App Profitability - Exercise.com](https://www.exercise.com/grow/how-profitable-are-fitness-apps/)
