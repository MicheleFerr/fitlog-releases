# Coach Mode - Piano di Implementazione

> Data: 2025-12-27
> Versione: 1.1 (Updated after codebase analysis)
> Riferimento: [coach-mode-wireframes-v2.md](./coach-mode-wireframes-v2.md)

---

## Executive Summary

**Obiettivo**: Permettere a Personal Trainer che lavorano IN PALESTRA di gestire i propri atleti tramite FitLog, senza funzionalità di coaching online (chat, video call, etc.).

**MVP Timeline stimato**: 3-4 settimane (1 sviluppatore) - RIDOTTO grazie a strutture esistenti

**Rischio principale**: Migrazione da `coach_delegations` esistente a nuovo modello

---

## CODEBASE ANALYSIS RESULTS

### Strutture GIA' Esistenti (riutilizzabili)

| Collection Firestore | Status | Utilizzo |
|----------------------|--------|----------|
| `coach_delegations/{id}` | ✅ Esiste | Relazioni coach-atleta (email-based) |
| `templateAssignments/{id}` | ✅ Esiste | Assegnazioni workout |
| `coachNotifications/{id}` | ✅ Esiste | Notifiche per coach |
| `athleteNotifications/{id}` | ✅ Esiste | Notifiche per atleti |
| `workoutTemplates/{id}` | ✅ Esiste | Supporta `coachId` + `userId` |

### Pattern OBBLIGATORI

```dart
// 1. TUTTI i repository DEVONO estendere BaseHybridRepository
class CoachRepository extends BaseHybridRepository<CoachRelationship> {
  CoachRepository() : super(
    featureName: 'coach',
    collectionName: 'coach_delegations',
    requiresPremiumForCloud: false,  // Coach mode GRATIS
  );

  // Metodi astratti obbligatori
  @override Map<String, dynamic> toJson(CoachRelationship entity);
  @override CoachRelationship fromJson(Map<String, dynamic> json);
  @override String getId(CoachRelationship entity);
  @override bool validate(CoachRelationship entity);
}

// 2. UserProfile esistente - ESTENDERE via preferences
// NON creare nuova entity, usare preferences map:
final accountMode = userProfile.preferences['accountMode'] ?? 'solo';
final coachCode = userProfile.preferences['coachCode'];
final linkedCoachId = userProfile.preferences['linkedCoachId'];
```

### Security Rules Esistenti (RIUTILIZZABILI)

```javascript
// coach_delegations - GIA' CONFIGURATO
match /coach_delegations/{delegationId} {
  allow read: if request.auth != null &&
    (resource.data.userId == request.auth.uid ||
     resource.data.coachEmail == request.auth.token.email);
  // ...
}

// templateAssignments - GIA' CONFIGURATO
match /templateAssignments/{assignmentId} {
  allow read: if request.auth != null &&
    (resource.data.coachId == request.auth.uid ||
     resource.data.athleteId == request.auth.uid);
  // ...
}
```

---

## 1. Scope MVP vs Future (UPDATED)

### MVP (Fase 1-3)

| Feature | Priorità | Note |
|---------|----------|------|
| Account mode selection (Solo/Coached/Coach) | P0 | Core |
| Coach code generation & sharing | P0 | Core |
| Athlete linking via code | P0 | Core |
| Coach: lista atleti | P0 | Core |
| Coach: profilo atleta base | P0 | Core |
| Coach: assegnazione workout da template | P0 | Core |
| Coached: vedere workout assegnato | P0 | Core |
| PAR-Q base (7 domande) | P1 | Safety |
| Coach: note per atleta | P1 | UX |
| Role switching | P1 | UX |

### Post-MVP (Fase 4+)

| Feature | Priorità | Note |
|---------|----------|------|
| Coach: visualizza workout live atleta | P2 | Nice to have |
| Coach: stats aggregate atleti | P2 | Analytics |
| Coach: programmi multi-settimana | P2 | Periodization |
| Coached: feedback post-workout | P2 | Communication |
| Coach: export dati atleta | P3 | GDPR compliance |
| Premium tier coach | P3 | Monetization |
| Profili atleta manuali (senza app) | P3 | Edge case |

---

## 2. Fasi di Implementazione

### Fase 1: Foundation (Week 1)
**Focus**: Data model, auth extensions, account mode

```
Deliverables:
├── Domain entities (AccountMode, CoachRelationship, etc.)
├── Firestore collections structure
├── Security rules per coach/athlete
├── Account mode provider
└── Onboarding flow aggiornato
```

### Fase 2: Coach Core (Week 2)
**Focus**: Coach dashboard, athlete management

```
Deliverables:
├── Coach code generation
├── Lista atleti screen
├── Profilo atleta base
├── Athlete linking flow
└── Coach home dashboard
```

### Fase 3: Workout Assignment (Week 3)
**Focus**: Assegnazione e visualizzazione workout

```
Deliverables:
├── Workout assignment flow
├── Coached mode home (workout del giorno)
├── Template customization per atleta
├── Coach notes system
└── Workout completion sync
```

### Fase 4: Health Questionnaire (Week 4)
**Focus**: PAR-Q e anamnesi

```
Deliverables:
├── PAR-Q flow (7 domande)
├── Health data storage (encrypted)
├── Coach view anamnesi
├── Limitations/warnings system
└── GDPR consent recording
```

### Fase 5: Polish & Testing (Week 5-6)
**Focus**: UX refinement, edge cases, testing

```
Deliverables:
├── Role switching UX
├── Empty states
├── Error handling
├── Offline support
├── Integration testing
└── Coach user testing (3-5 PT reali)
```

---

## 3. Data Model Dettagliato

### 3.1 Firestore Collections

```
firestore/
├── users/{userId}
│   ├── displayName: string
│   ├── email: string
│   ├── accountMode: 'solo' | 'coached' | 'coach'
│   ├── coachCode: string? (se coach)
│   ├── linkedCoachId: string? (se coached)
│   ├── createdAt: timestamp
│   └── updatedAt: timestamp
│
├── coach_relationships/{relationshipId}
│   ├── coachId: string
│   ├── athleteId: string
│   ├── status: 'pending' | 'active' | 'paused' | 'ended'
│   ├── athleteHasApp: boolean
│   ├── connectedAt: timestamp
│   └── endedAt: timestamp?
│
├── health_questionnaires/{oderId}
│   ├── oderId: string
│   ├── completedAt: timestamp
│   ├── answers: map<questionId, ParqAnswer>
│   ├── limitations: string[]
│   ├── notes: string?
│   ├── consent: ConsentRecord
│   └── lastUpdated: timestamp
│
├── assigned_workouts/{assignmentId}
│   ├── coachId: string
│   ├── athleteId: string
│   ├── templateId: string
│   ├── scheduledFor: timestamp
│   ├── status: 'assigned' | 'started' | 'completed' | 'skipped'
│   ├── coachNote: string?
│   ├── customizations: map<exerciseId, ExerciseCustomization>
│   ├── createdAt: timestamp
│   └── completedAt: timestamp?
│
└── coach_notes/{noteId}
    ├── coachId: string
    ├── athleteId: string
    ├── content: string
    ├── type: 'general' | 'workout' | 'progress'
    ├── relatedWorkoutId: string?
    └── createdAt: timestamp
```

### 3.2 Dart Entities

```dart
// lib/features/coach/domain/entities/

/// Account mode enum
enum AccountMode {
  solo,    // Utente indipendente
  coached, // Utente con coach
  coach,   // Personal trainer
}

/// Coach-Athlete relationship
@freezed
class CoachRelationship with _$CoachRelationship {
  const factory CoachRelationship({
    required String id,
    required String coachId,
    required String athleteId,
    required RelationshipStatus status,
    required bool athleteHasApp,
    required DateTime connectedAt,
    DateTime? endedAt,
  }) = _CoachRelationship;
}

enum RelationshipStatus { pending, active, paused, ended }

/// Health questionnaire (PAR-Q)
@freezed
class HealthQuestionnaire with _$HealthQuestionnaire {
  const factory HealthQuestionnaire({
    required String id,
    required String oderId,
    required DateTime completedAt,
    required Map<String, ParqAnswer> answers,
    required List<String> limitations,
    String? notes,
    required ConsentRecord consent,
  }) = _HealthQuestionnaire;
}

@freezed
class ParqAnswer with _$ParqAnswer {
  const factory ParqAnswer({
    required String questionId,
    required bool response,
    String? details,
  }) = _ParqAnswer;
}

@freezed
class ConsentRecord with _$ConsentRecord {
  const factory ConsentRecord({
    required DateTime acceptedAt,
    required String version,
    required bool healthDataConsent,
    required bool coachSharingConsent,
  }) = _ConsentRecord;
}

/// Assigned workout
@freezed
class AssignedWorkout with _$AssignedWorkout {
  const factory AssignedWorkout({
    required String id,
    required String coachId,
    required String athleteId,
    required String templateId,
    required DateTime scheduledFor,
    required AssignmentStatus status,
    String? coachNote,
    required Map<String, ExerciseCustomization> customizations,
    required DateTime createdAt,
    DateTime? completedAt,
  }) = _AssignedWorkout;
}

enum AssignmentStatus { assigned, started, completed, skipped }

@freezed
class ExerciseCustomization with _$ExerciseCustomization {
  const factory ExerciseCustomization({
    String? replacementExerciseId,
    int? customSets,
    int? customReps,
    double? customWeight,
    String? note,
  }) = _ExerciseCustomization;
}
```

### 3.3 Security Rules

```javascript
// firestore.rules

rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    // Users - own data only
    match /users/{userId} {
      allow read: if isAuthenticated() &&
        (isOwner(userId) || isCoachOf(userId));
      allow write: if isAuthenticated() && isOwner(userId);
    }

    // Coach relationships
    match /coach_relationships/{relationshipId} {
      allow read: if isAuthenticated() &&
        (resource.data.coachId == request.auth.uid ||
         resource.data.athleteId == request.auth.uid);
      allow create: if isAuthenticated() &&
        request.resource.data.athleteId == request.auth.uid;
      allow update: if isAuthenticated() &&
        (resource.data.coachId == request.auth.uid ||
         resource.data.athleteId == request.auth.uid);
    }

    // Health questionnaires - athlete + their coach
    match /health_questionnaires/{oderId} {
      allow read: if isAuthenticated() &&
        (isOwner(resource.data.oderId) || isCoachOf(resource.data.oderId));
      allow write: if isAuthenticated() &&
        isOwner(resource.data.oderId);
    }

    // Assigned workouts
    match /assigned_workouts/{assignmentId} {
      allow read: if isAuthenticated() &&
        (resource.data.coachId == request.auth.uid ||
         resource.data.athleteId == request.auth.uid);
      allow create, update: if isAuthenticated() &&
        resource.data.coachId == request.auth.uid;
    }

    // Helper functions
    function isAuthenticated() {
      return request.auth != null;
    }

    function isOwner(userId) {
      return request.auth.uid == userId;
    }

    function isCoachOf(athleteId) {
      return exists(/databases/$(database)/documents/coach_relationships/$(request.auth.uid + '_' + athleteId)) &&
        get(/databases/$(database)/documents/coach_relationships/$(request.auth.uid + '_' + athleteId)).data.status == 'active';
    }
  }
}
```

---

## 4. Provider Architecture

```dart
// lib/features/coach/presentation/providers/

/// Account mode provider
final accountModeProvider = StateNotifierProvider<AccountModeNotifier, AccountMode>((ref) {
  return AccountModeNotifier(ref);
});

/// Coach code provider (for coaches)
final coachCodeProvider = FutureProvider.autoDispose<String?>((ref) async {
  final user = ref.watch(firebaseUserProvider).valueOrNull;
  if (user == null) return null;

  final doc = await FirebaseFirestore.instance
      .collection('users')
      .doc(user.uid)
      .get();

  return doc.data()?['coachCode'] as String?;
});

/// Athletes list provider (for coaches)
final athletesListProvider = StreamProvider.autoDispose<List<AthleteWithStatus>>((ref) {
  final user = ref.watch(firebaseUserProvider).valueOrNull;
  if (user == null) return Stream.value([]);

  return ref.watch(coachRepositoryProvider).watchAthletes(user.uid);
});

/// Assigned workout for today (for coached users)
final todayAssignedWorkoutProvider = FutureProvider.autoDispose<AssignedWorkout?>((ref) async {
  final user = ref.watch(firebaseUserProvider).valueOrNull;
  if (user == null) return null;

  return ref.watch(assignedWorkoutRepositoryProvider)
      .getWorkoutForDate(user.uid, DateTime.now());
});

/// Athlete profile provider (for coach viewing athlete)
final athleteProfileProvider = FutureProvider.autoDispose
    .family<AthleteProfile, String>((ref, athleteId) async {
  return ref.watch(coachRepositoryProvider).getAthleteProfile(athleteId);
});

/// Health questionnaire provider
final healthQuestionnaireProvider = FutureProvider.autoDispose
    .family<HealthQuestionnaire?, String>((ref, oderId) async {
  return ref.watch(healthQuestionnaireRepositoryProvider)
      .getQuestionnaire(oderId);
});
```

---

## 5. File Structure

```
lib/features/coach/
├── domain/
│   ├── entities/
│   │   ├── account_mode.dart
│   │   ├── coach_relationship.dart
│   │   ├── assigned_workout.dart
│   │   ├── health_questionnaire.dart
│   │   └── athlete_profile.dart
│   ├── repositories/
│   │   ├── coach_repository.dart
│   │   ├── assigned_workout_repository.dart
│   │   └── health_questionnaire_repository.dart
│   └── services/
│       ├── coach_code_generator.dart
│       └── parq_evaluator.dart
│
├── data/
│   ├── repositories/
│   │   ├── coach_repository_impl.dart
│   │   ├── assigned_workout_repository_impl.dart
│   │   └── health_questionnaire_repository_impl.dart
│   └── datasources/
│       ├── coach_remote_datasource.dart
│       └── health_local_datasource.dart
│
└── presentation/
    ├── providers/
    │   ├── account_mode_provider.dart
    │   ├── athletes_provider.dart
    │   ├── assigned_workout_provider.dart
    │   └── health_questionnaire_provider.dart
    ├── screens/
    │   ├── coach/
    │   │   ├── coach_dashboard_screen.dart
    │   │   ├── athletes_list_screen.dart
    │   │   ├── athlete_profile_screen.dart
    │   │   ├── assign_workout_screen.dart
    │   │   └── athlete_anamnesis_screen.dart
    │   ├── coached/
    │   │   ├── coached_home_screen.dart
    │   │   └── link_coach_screen.dart
    │   └── shared/
    │       ├── account_mode_selector.dart
    │       ├── role_switcher_sheet.dart
    │       └── parq_flow_screen.dart
    └── widgets/
        ├── athlete_card.dart
        ├── athlete_status_badge.dart
        ├── assigned_workout_card.dart
        ├── coach_note_widget.dart
        ├── parq_question_widget.dart
        └── limitations_chips.dart
```

---

## 6. Task Breakdown Dettagliato

### Fase 1: Foundation (5-7 giorni)

| # | Task | Complessità | Dipendenze | File |
|---|------|-------------|------------|------|
| 1.1 | Creare AccountMode enum e entity | S | - | `domain/entities/account_mode.dart` |
| 1.2 | Creare CoachRelationship entity | S | - | `domain/entities/coach_relationship.dart` |
| 1.3 | Creare AssignedWorkout entity | M | - | `domain/entities/assigned_workout.dart` |
| 1.4 | Creare HealthQuestionnaire entity | M | - | `domain/entities/health_questionnaire.dart` |
| 1.5 | Setup Firestore collections | M | 1.1-1.4 | Firebase console |
| 1.6 | Scrivere security rules | M | 1.5 | `firestore.rules` |
| 1.7 | Creare AccountModeProvider | M | 1.1 | `providers/account_mode_provider.dart` |
| 1.8 | Modificare onboarding flow | L | 1.7 | `onboarding/` screens |
| 1.9 | Aggiungere mode switcher in Profile | M | 1.7 | `profile/` |

### Fase 2: Coach Core (5-7 giorni)

| # | Task | Complessità | Dipendenze | File |
|---|------|-------------|------------|------|
| 2.1 | Coach code generator service | S | - | `services/coach_code_generator.dart` |
| 2.2 | CoachRepository interface | S | - | `repositories/coach_repository.dart` |
| 2.3 | CoachRepository implementation | L | 2.2 | `data/repositories/` |
| 2.4 | AthletesListProvider | M | 2.3 | `providers/athletes_provider.dart` |
| 2.5 | CoachDashboardScreen | L | 2.4 | `screens/coach/coach_dashboard_screen.dart` |
| 2.6 | AthletesListScreen | M | 2.4 | `screens/coach/athletes_list_screen.dart` |
| 2.7 | AthleteCard widget | S | - | `widgets/athlete_card.dart` |
| 2.8 | AthleteProfileScreen (base) | M | 2.3 | `screens/coach/athlete_profile_screen.dart` |
| 2.9 | LinkCoachScreen (codice) | M | 2.3 | `screens/coached/link_coach_screen.dart` |
| 2.10 | Add athlete flow | M | 2.1, 2.3 | `screens/coach/` |

### Fase 3: Workout Assignment (5-7 giorni)

| # | Task | Complessità | Dipendenze | File |
|---|------|-------------|------------|------|
| 3.1 | AssignedWorkoutRepository interface | S | - | `repositories/assigned_workout_repository.dart` |
| 3.2 | AssignedWorkoutRepository impl | L | 3.1 | `data/repositories/` |
| 3.3 | AssignWorkoutScreen | L | 3.2 | `screens/coach/assign_workout_screen.dart` |
| 3.4 | Template customization per atleta | M | 3.3 | component in 3.3 |
| 3.5 | CoachedHomeScreen | M | 3.2 | `screens/coached/coached_home_screen.dart` |
| 3.6 | AssignedWorkoutCard widget | M | - | `widgets/assigned_workout_card.dart` |
| 3.7 | Coach notes system | M | 2.3 | `widgets/coach_note_widget.dart` |
| 3.8 | Workout completion sync | M | 3.2 | Modify existing workout flow |
| 3.9 | Week calendar picker | S | - | Component in 3.3 |

### Fase 4: Health Questionnaire (4-5 giorni)

| # | Task | Complessità | Dipendenze | File |
|---|------|-------------|------------|------|
| 4.1 | PAR-Q questions constants | S | - | `domain/constants/parq_questions.dart` |
| 4.2 | HealthQuestionnaireRepository | M | - | `repositories/health_questionnaire_repository.dart` |
| 4.3 | ParqFlowScreen | L | 4.1, 4.2 | `screens/shared/parq_flow_screen.dart` |
| 4.4 | ParqQuestionWidget | M | - | `widgets/parq_question_widget.dart` |
| 4.5 | Consent recording | M | 4.2 | Part of 4.3 |
| 4.6 | AthleteAnamnesisScreen (coach view) | M | 4.2 | `screens/coach/athlete_anamnesis_screen.dart` |
| 4.7 | LimitationsChips widget | S | - | `widgets/limitations_chips.dart` |
| 4.8 | Warning banners in workout | M | 4.2 | Modify assign screen |

### Fase 5: Polish (3-5 giorni)

| # | Task | Complessità | Dipendenze | File |
|---|------|-------------|------------|------|
| 5.1 | RoleSwitcherSheet | M | 1.7 | `screens/shared/role_switcher_sheet.dart` |
| 5.2 | Empty states (tutti) | S | - | Various |
| 5.3 | Error handling | M | - | Various |
| 5.4 | Offline caching | M | - | Repositories |
| 5.5 | Localizzazione (IT + EN) | M | - | ARB files |
| 5.6 | Integration tests | L | All | `test/integration/` |
| 5.7 | Manual QA | M | All | - |

---

## 7. Rischi e Mitigazioni

| Rischio | Probabilità | Impatto | Mitigazione |
|---------|-------------|---------|-------------|
| Sync conflicts multi-utente | Alta | Alto | Firestore transactions, optimistic UI |
| Security rules troppo restrittive | Media | Medio | Test approfonditi in emulator |
| Performance lista atleti | Media | Medio | Pagination, caching locale |
| GDPR compliance health data | Bassa | Alto | Consent recording, data minimization |
| Coach UX troppo complessa | Media | Medio | User testing fase 5 |

---

## 8. Metriche di Successo

### MVP Launch

- [ ] 3+ coach beta tester attivi
- [ ] 10+ atleti collegati
- [ ] < 3 bug critici in prima settimana
- [ ] Tempo medio assegnazione workout < 60 secondi

### Post-MVP (30 giorni)

- [ ] Retention coach > 50% dopo 2 settimane
- [ ] NPS coach > 30
- [ ] < 5 richieste supporto/settimana

---

## 9. Prossimi Passi Immediati

1. **Review piano** con stakeholder
2. **Setup branch** `feature/coach-mode`
3. **Iniziare Fase 1** - Task 1.1 (AccountMode entity)

---

## Appendice: Comandi Utili

```bash
# Genera freezed classes
dart run build_runner build --delete-conflicting-outputs

# Test security rules
firebase emulators:start --only firestore

# Analizza codebase
flutter analyze

# Run tests
flutter test test/features/coach/
```

---

*Piano creato: 2025-12-27*
*Autore: Claude + Michele*
*Prossima review: Prima di iniziare Fase 2*
