# Exercise Upgrade Inline Feature

**Data:** 2025-12-25
**Status:** In Progress

## Problema

Quando l'utente crea un esercizio custom (es. "Curl Manubri") e successivamente GymBro aggiunge lo stesso esercizio al database ufficiale con tutti i metadati, l'utente vuole poter "upgradare" il suo esercizio per avere tracking corretto.

Il sistema di merge esistente richiede di navigare in una schermata separata. L'utente vuole un'icona inline nel workout.

## Soluzione

Aggiungere un'icona inline accanto agli esercizi che hanno un match nel database ufficiale (>=60% somiglianza). Tap sull'icona apre un modal di preview per confermare l'upgrade.

## Decisioni di Design

| Aspetto | Decisione |
|---------|-----------|
| Match type | Fuzzy matching automatico |
| Soglia | 60% somiglianza |
| Posizione icona | Inline accanto al nome esercizio |
| Interazione | Tap diretto apre modal |
| Modal | Preview best match + opzione "Vedi altri" |
| Scope | Opzione checkbox per aggiornare altri workout |
| Dati mantenuti | Set, peso, reps invariati |
| Dati aggiornati | Nome, focus, muscoli, pattern, attrezzatura |

## Architettura

### Componenti Esistenti Riutilizzati

- `ExerciseFuzzyMatcher` - Fuzzy matching con Isolate
- `ExerciseMergeService.findMergeCandidates()` - Trova candidati
- `MergeCandidate` / `ExerciseMatch` - Entità

### Nuovi Componenti

```
lib/features/workout/presentation/
├── providers/
│   └── upgrade_matches_provider.dart    # Cache con keepAlive
└── widgets/
    ├── upgrade_icon_button.dart         # Icona inline
    └── quick_upgrade_modal.dart         # Modal preview
```

### Modifiche a Componenti Esistenti

- `exercise_list_item_header.dart` - Aggiunge icona
- `workout_provider.dart` - Nuovo metodo `updateExerciseMetadata()`

## Data Flow

1. **App Startup:** `upgradeMatchesCacheProvider` calcola tutti i match
2. **Workout Screen:** Header controlla se esercizio ha match in cache
3. **Tap Icona:** Apre `QuickUpgradeModal` con preview
4. **Conferma:** Aggiorna metadati, opzionalmente in tutti i workout
5. **Post-upgrade:** Cache invalidata, icona sparisce

## UI Modal

```
┌─────────────────────────────────────────┐
│  ⬆️ Aggiorna Esercizio                  │
├─────────────────────────────────────────┤
│  "Curl Manubri" → "Curl con Manubri"    │
│                    92% match            │
│                                         │
│  🎯 Muscoli: Bicipiti                   │
│  🏋️ Attrezzatura: Manubri               │
│  📊 Pattern: Pull - Isolamento          │
│                                         │
│  ☑️ Aggiorna anche in altri workout (3) │
│                                         │
│  [Vedi altri match]          [Conferma] │
└─────────────────────────────────────────┘
```

## References

- [NN/g - Notification Patterns](https://www.nngroup.com/articles/indicators-validations-notifications/)
- [Riverpod Caching](https://codewithandrea.com/articles/flutter-riverpod-data-caching-providers-lifecycle/)
