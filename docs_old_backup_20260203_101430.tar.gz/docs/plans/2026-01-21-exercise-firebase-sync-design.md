# Exercise Database Firebase Sync - Design Document

**Data**: 2026-01-21
**Stato**: Approvato
**Autore**: Claude + Michele (brainstorming)

---

## Problema

Discrepanza tra esercizi locali (2282) e Firebase (1550), con multiple inconsistenze nel codebase:

1. `HybridExerciseRepository` cerca `exercises_master` (collection inesistente)
2. `DatabaseManagerService` legge da `exercises_it` ma scrive su `exercises`
3. Firebase non viene mai usato per esercizi master (sempre fallback a JSON locale)
4. Nessuna notifica utente quando sync completa

---

## Obiettivi

- **Aggiornamenti OTA**: Poter aggiornare il database esercizi senza rilasciare nuove versioni app
- **Admin panel**: Gestire esercizi da Firebase console o pannello admin
- **Sync silenzioso**: Aggiornamenti in background con notifica discreta a completamento

---

## Decisioni di Design

| Aspetto | Decisione |
|---------|-----------|
| Collection Firebase | Separate per lingua: `exercises_it`, `exercises_en` |
| Strategia sync | Cache-first con sync periodico (ogni 6h) + notifica aggiornamenti |
| Upload iniziale | Sovrascrivere tutto con `ExercisePublishService.publishNewVersion()` |
| Collection orfane | Eliminare `esercizi` e `exercises` da Firebase |
| Notifica UX | Aggiornamento silenzioso + SnackBar "Database aggiornato!" a completamento |

---

## Architettura Target

```
┌─────────────────────────────────────────────────────────────────┐
│                      FIREBASE (Source of Truth)                  │
│                                                                  │
│  exercises_it (2282)    ← Admin Panel / ExercisePublishService  │
│  exercises_en (2282)    ← Batch writes (500 docs max)           │
│  exercises_metadata     ← version_info + changelog              │
└─────────────────────────────────────────────────────────────────┘
                              ▲
                              │
         ┌────────────────────┴────────────────────┐
         │      ExerciseSyncService (Background)    │
         │                                          │
         │  • Controlla versione ogni 6h (24h)      │
         │  • Scarica solo se version > locale      │
         │  • Batch download con pagination         │
         │  • Rollback se download fallisce         │
         │  • Notifica SnackBar a completamento     │
         └────────────────────┬────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                 HybridExerciseRepository                         │
│                 (Repository Pattern - SSOT)                      │
│                                                                  │
│  getAllExercises():                                             │
│    1. SEMPRE legge da cache (velocità)                          │
│    2. Ritorna immediatamente                                    │
│    3. Background: triggerSync() se stale                        │
│                                                                  │
│  Collection dinamica: exercises_{locale}                        │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      CACHE LOCALE (Hive)                        │
│                                                                  │
│  exercises_cache          │ exercises_metadata                  │
│  • 2282 esercizi          │ • local_version: "2.0.0"            │
│  • Indexed by ID          │ • last_sync: DateTime               │
│  • ~5MB in memoria        │ • exercise_count: 2282              │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼ (solo se cache vuota + offline)
┌─────────────────────────────────────────────────────────────────┐
│                    JSON ASSET (Fallback)                        │
│  assets/data/exercises/*.json                                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## Inconsistenze Trovate e Fix

### 1. HybridExerciseRepository (CRITICO)

**File**: `lib/features/exercise_database/data/repositories/hybrid_exercise_repository.dart`

```dart
// PRIMA (riga 44)
static const String _exercisesCollection = 'exercises_master';

// DOPO - Collection dinamica basata su locale
String get _exercisesCollection => 'exercises_${locale.languageCode}';
```

### 2. DatabaseManagerService (CRITICO)

**File**: `lib/features/admin/data/services/database_manager_service.dart`

| Metodo | Riga | Prima | Dopo |
|--------|------|-------|------|
| `bulkUpdateField()` | 230 | `exercises` | `exercises_it` |
| `updateExercise()` | 267 | `exercises` | `exercises_it` |
| `addExercise()` | 298 | `exercises` | `exercises_it` |
| `deleteExercise()` | 325 | `exercises` | `exercises_it` |
| `bulkDeleteExercises()` | 355 | `exercises` | `exercises_it` |

### 3. Collection Firebase da Eliminare

| Collection | Motivo |
|------------|--------|
| `esercizi` | Orfana, nessun riferimento nel codice |
| `exercises` | Usata erroneamente da admin, da eliminare dopo fix |

---

## Piano di Implementazione

### Fase 1: Fix Inconsistenze Codice
- [ ] Fix `exercises_master` → `exercises_{locale}` in HybridExerciseRepository
- [ ] Fix `exercises` → `exercises_it` in DatabaseManagerService

### Fase 2: Upload Esercizi su Firebase
- [ ] Eseguire `ExercisePublishService.publishNewVersion()` con versione 2.0.0
- [ ] Verificare count esercizi su Firebase Console

### Fase 3: Implementare Notifica Sync
- [ ] Creare `ExerciseSyncListener` widget
- [ ] Integrare nel widget tree
- [ ] Aggiungere stringhe localizzate

### Fase 4: Cleanup Firebase (Manuale)
- [ ] Eliminare collection `esercizi`
- [ ] Eliminare collection `exercises` (se vuota)

---

## Best Practices Integrate

Fonti:
- [Flutter Offline-First Docs](https://docs.flutter.dev/app-architecture/design-patterns/offline-first)
- [Firebase Firestore Best Practices](https://firebase.google.com/docs/firestore/best-practices)
- [OTA Updates Best Practices](https://www.appsonair.com/blogs/best-practices-for-over-the-air-app-updates)

| Best Practice | Implementazione |
|--------------|-----------------|
| Repository come SSOT | HybridExerciseRepository |
| Cache-first | getAllExercises() legge sempre da Hive |
| Background sync | Timer(6h) + connectivity listener |
| Batch operations | Max 500 docs per batch |
| Semantic versioning | MAJOR.MINOR.PATCH |
| Silent updates | Notifica solo a completamento |

---

## Effort Stimato

| Fase | Effort |
|------|--------|
| Fase 1 | 45 min |
| Fase 2 | 10 min |
| Fase 3 | 45 min |
| Fase 4 | 10 min |
| **Totale** | **~2 ore** |

---

## Note

- Il sistema di sync (`ExerciseSyncService`) esiste già ed è ben implementato
- I provider (`exerciseSyncEventsProvider`, `exerciseSyncStatusProvider`) esistono ma non sono usati da UI
- `SnackBarService` è pronto per essere usato per le notifiche
