# User Flow Fixes - Implementation Plan

> Generated via task-master.dev integration | 2026-01-02
> **Updated:** 2026-01-02 with deep research findings from 12 parallel agents

---

## Overview

| Metric | Value |
|--------|-------|
| Total Tasks | 12 |
| Critical (P0) | 4 |
| High Priority (P1) | 4 |
| Medium Priority (P2) | 4 |
| Estimated Duration | ~9.5 weeks (2 dev) |

---

## CRITICAL (P0) Tasks

### P0-1: Ridurre Home Tour da 10 a 5 step
**Effort:** S | **Risk:** Low | **Dependencies:** None

**Files:**
- `lib/features/onboarding/domain/services/home_tour_service.dart`

**Current State:**
- `HomeTourStep` enum con 10 valori + `completed`
- Step counter mostra "/10" in UI
- Tutti gli step hanno GlobalKey targets

**Implementation:**

```dart
// BEFORE: 10 steps
enum HomeTourStep {
  xpProgress, activityRings, startWorkout, templatesCarousel,
  templateSuggestion, proInsights, recoveryInsight, stressPrediction,
  exerciseWiki, settings, completed,
}

// AFTER: 5 steps
enum HomeTourStep {
  xpProgress,        // Step 1: Gamification entry point
  startWorkout,      // Step 2: Core action
  templatesCarousel, // Step 3: Template discovery
  templateSuggestion,// Step 4: AI recommendation
  settings,          // Step 5: Customization
  completed,
}
```

**Changes Required:**
1. Remove enum values: `activityRings`, `proInsights`, `recoveryInsight`, `stressPrediction`, `exerciseWiki`
2. Update `_getStepNumber()` to show "/5" instead of "/10"
3. Update `_getStepConfig()` switch statement
4. Remove GlobalKey references for deleted steps in `minimal_home_screen.dart`

**Acceptance Criteria:**
- [ ] Tour ridotto da 10 a 5 step essenziali
- [ ] Step rimossi: activityRings, proInsights, recoveryInsight, stressPrediction, exerciseWiki
- [ ] Step mantenuti: xpProgress, startWorkout, templatesCarousel, templateSuggestion, settings
- [ ] StateNotifier aggiornato
- [ ] Animazioni TutorialCoachMark fluide

---

### P0-2: Conferma cancellazione esercizio
**Effort:** S | **Risk:** Low | **Dependencies:** None

**Files:**
- `lib/features/workout/presentation/workout_screen.dart` (line 635)
- `lib/shared/domain/entities/app_config.dart` (add preference)

**Current State:**
```dart
// Line 635 - NO confirmation
void _deleteExercise(String exerciseId) {
  ref.read(workoutScreenControllerProvider.notifier).removeExercise(exerciseId);
}
```

**Pattern to Follow:**
Already exists in `exercise_list_item_sets.dart` for SET deletion:
```dart
Future<bool> _showDeleteConfirmation(BuildContext context, ExerciseSet set, int index, bool isWarmup) async {
  final confirmed = await showGeneralDialog<bool>(
    context: context,
    transitionBuilder: (context, animation, secondaryAnimation, child) {
      return ScaleTransition(
        scale: Tween<double>(begin: 0.8, end: 1.0).animate(curvedAnimation),
        child: FadeTransition(opacity: curvedAnimation, child: alertDialog),
      );
    },
  );
  return confirmed == true;
}
```

**Implementation:**
```dart
Future<void> _deleteExercise(String exerciseId, String exerciseName) async {
  final config = ref.read(appConfigProvider);

  if (!config.skipExerciseDeleteConfirmation) {
    final shouldDelete = await _showDeleteExerciseConfirmation(context, exerciseName);
    if (!shouldDelete) return;
  }

  ref.read(workoutScreenControllerProvider.notifier).removeExercise(exerciseId);
}
```

**AppConfig Addition:**
```dart
@HiveField(50)
final bool skipExerciseDeleteConfirmation; // default: false
```

**Existing Translations:**
- `deleteExercise` - already in ARB files
- `deleteExerciseDescription` - already in ARB files

**Acceptance Criteria:**
- [ ] Dialog di conferma prima della cancellazione
- [ ] Opzione "Non chiedere piu" (SharedPreferences)
- [ ] Rispetta tema dark/light
- [ ] Accessibile con VoiceOver

---

### P0-3: Protezione swipe-to-delete template
**Effort:** S | **Risk:** Low | **Dependencies:** None

**Files:**
- `lib/features/workout_templates/presentation/widgets/swipeable_template_card.dart`

**Current Issues:**
1. `extentRatio` too high (0.64-0.80) - should be 0.45-0.60
2. Missing `dismissThreshold` parameter
3. Missing `dragStartBehavior: DragStartBehavior.down`
4. No haptic feedback on complete swipe

**Package:** `flutter_slidable: ^4.0.3`

**Implementation:**
```dart
Slidable(
  key: ValueKey(template.id),
  closeOnScroll: true,  // ADD: Close when scrolling
  endActionPane: ActionPane(
    motion: const BehindMotion(),
    dismissible: DismissiblePane(
      onDismissed: () => _confirmAndDelete(template),
      dismissThreshold: 0.5,  // ADD: Higher threshold
    ),
    extentRatio: 0.5,  // CHANGE: from 0.64-0.80 to 0.5
    dragStartBehavior: DragStartBehavior.down,  // ADD
    children: [
      SlidableAction(
        onPressed: (_) async {
          HapticFeedback.mediumImpact();  // ADD haptic
          await _confirmAndDelete(template);
        },
        backgroundColor: context.colors.error,
        foregroundColor: context.colors.onError,
        icon: AppIcons.delete,
        label: context.l10n.delete,
      ),
    ],
  ),
  child: TemplateCard(template: template),
)
```

**Acceptance Criteria:**
- [ ] Soglia swipe aumentata (0.3 -> 0.5)
- [ ] Scroll verticale non triggera delete
- [ ] Haptic feedback su swipe completo
- [ ] Conferma dopo swipe

---

### P0-4: Progressive Disclosure
**Effort:** L | **Risk:** Medium | **Dependencies:** P0-1

**Files:**
- `lib/features/onboarding/domain/services/home_tour_service.dart`
- `lib/features/onboarding/domain/services/workout_tour_service.dart`
- `lib/features/onboarding/domain/services/template_tutorial_service.dart`
- `lib/features/onboarding/domain/services/timer_tour_service.dart`
- `lib/features/onboarding/domain/services/analytics_tour_service.dart`
- `lib/features/onboarding/domain/services/exercise_search_tutorial_service.dart`
- `lib/features/onboarding/domain/services/onboarding_orchestrator.dart`

**Current Tutorial Steps:**
| Service | Steps | Trigger |
|---------|-------|---------|
| HomeTourService | 10 | First app open |
| WorkoutTutorialService | 6 | First workout start |
| ExerciseSearchTutorialService | 5 | First exercise search |
| AnalyticsTourService | 6 | First analytics view |
| TimerTourService | 4 | First timer activation |
| TemplateTutorialService | 5 | First template create |
| **TOTAL** | **36** | - |

**Target:** Reduce initial tutorials, trigger others contextually

**OnboardingOrchestrator Enhancement:**
```dart
class OnboardingOrchestrator {
  // ADD: Tutorial progress tracking
  TutorialProgress getTutorialProgress() {
    return TutorialProgress(
      homeTour: ref.read(homeTourCompletedProvider),
      workoutTour: ref.read(workoutTourCompletedProvider),
      timerTour: ref.read(timerTourCompletedProvider),
      templateTutorial: ref.read(templateTutorialCompletedProvider),
      exerciseSearch: ref.read(exerciseSearchTutorialCompletedProvider),
      analyticsTour: ref.read(analyticsTourCompletedProvider),
    );
  }

  // ADD: Contextual tutorial suggestions
  TutorialSuggestion? getNextRecommendedTutorial(UserContext context) {
    final progress = getTutorialProgress();

    if (!progress.homeTour) return TutorialSuggestion.homeTour;
    if (context.hasActiveWorkout && !progress.workoutTour) {
      return TutorialSuggestion.workoutTour;
    }
    // ... contextual logic
  }

  // ADD: Reset all tutorials (for settings)
  Future<void> resetAllTutorials() async {
    await ref.read(homeTourProvider.notifier).resetTour();
    await ref.read(workoutTourProvider.notifier).resetTour();
    // ... reset all
  }
}
```

**Settings Integration:**
Add in `lib/features/settings/presentation/screens/settings_screen.dart`:
```dart
ListTile(
  leading: Icon(AppIcons.tutorial),
  title: Text(context.l10n.resetTutorials),
  subtitle: Text(context.l10n.resetTutorialsDescription),
  onTap: () => _confirmResetTutorials(),
)
```

**Analytics Events:**
```dart
analytics.logEvent('tutorial_started', {'tutorial': 'home_tour'});
analytics.logEvent('tutorial_completed', {'tutorial': 'home_tour', 'duration_ms': duration});
analytics.logEvent('tutorial_skipped', {'tutorial': 'home_tour', 'step': currentStep});
```

**Acceptance Criteria:**
- [ ] Tutorial iniziali ridotti a 5 step
- [ ] Tutorial contestuali just-in-time
- [ ] Utente puo ri-abilitare tutorial da settings
- [ ] Analytics su completion rate

---

## HIGH PRIORITY (P1) Tasks

### P1-1: Guest Mode
**Effort:** M | **Risk:** Medium | **Dependencies:** None

**Files:**
- `lib/features/auth/presentation/login_screen.dart`
- `lib/features/auth/data/auth_service.dart`
- `lib/features/auth/presentation/providers/auth_provider.dart`
- `lib/core/providers/guest_user_provider.dart` (NEW)

**Firebase Anonymous Auth:**
```dart
// auth_service.dart - ADD methods
Future<UserCredential?> signInAnonymously() async {
  try {
    return await _auth.signInAnonymously();
  } catch (e) {
    debugPrint('Anonymous sign-in failed: $e');
    return null;
  }
}

Future<UserCredential?> linkAnonymousToEmail({
  required String email,
  required String password,
}) async {
  final user = _auth.currentUser;
  if (user == null || !user.isAnonymous) return null;

  final credential = EmailAuthProvider.credential(
    email: email,
    password: password
  );
  return await user.linkWithCredential(credential);
}

bool get isGuestUser => _auth.currentUser?.isAnonymous ?? false;
```

**AuthState Enhancement:**
```dart
enum AuthState {
  initial,
  authenticated,
  guest,        // ADD
  unauthenticated,
  error,
}
```

**Login Screen Addition:**
```dart
// After social login buttons
const SizedBox(height: 24),
OutlinedButton.icon(
  onPressed: _continueAsGuest,
  icon: Icon(AppIcons.personOutline),
  label: Text(context.l10n.continueAsGuest),
  style: OutlinedButton.styleFrom(
    minimumSize: Size(double.infinity, 48),
  ),
),
Text(
  context.l10n.guestModeDescription,
  style: context.textTheme.bodySmall,
  textAlign: TextAlign.center,
),
```

**Data Migration Strategy:**
```dart
Future<void> migrateGuestData(String newUserId) async {
  final guestId = _auth.currentUser!.uid;

  // Migrate workouts
  final workouts = await _firestore
    .collection('workouts')
    .where('userId', isEqualTo: guestId)
    .get();

  final batch = _firestore.batch();
  for (final doc in workouts.docs) {
    batch.update(doc.reference, {'userId': newUserId});
  }
  await batch.commit();
}
```

**New Translations:**
- `continueAsGuest`: "Esplora senza account" / "Continue as Guest"
- `guestModeDescription`: "I tuoi dati rimarranno sul dispositivo" / "Your data stays on device"
- `registerToSave`: "Registrati per salvare i progressi" / "Register to save progress"

**Acceptance Criteria:**
- [ ] Bottone "Esplora senza account" in login
- [ ] Sessione guest con dati locali
- [ ] Prompt "Registrati per salvare" dopo primo workout
- [ ] Migrazione dati guest -> account reale

---

### P1-2: HealthKit dopo primo workout
**Effort:** S | **Risk:** Low | **Dependencies:** None

**Files:**
- `lib/features/onboarding/presentation/screens/initial/initial_onboarding_screen.dart`
- `lib/features/workout/presentation/screens/workout_completion_celebration.dart`
- `lib/features/health_sync/presentation/widgets/post_workout_healthkit_sheet.dart` (NEW)

**Current State:**
HealthKit permission at onboarding Step 5 (before user sees value)

**Remove from Onboarding:**
```dart
// initial_onboarding_screen.dart
// REMOVE or skip HealthKit step
OnboardingStep.healthKit => _buildHealthKitStep(),  // REMOVE
```

**Post-Workout Trigger:**
```dart
// workout_completion_celebration.dart
@override
void initState() {
  super.initState();
  _checkHealthKitPrompt();
}

Future<void> _checkHealthKitPrompt() async {
  final prefs = await SharedPreferences.getInstance();
  final promptCount = prefs.getInt('healthkit_prompt_count') ?? 0;
  final hasPermission = await HealthService.hasPermission();

  if (!hasPermission && promptCount < 3) {
    await Future.delayed(Duration(seconds: 2)); // After celebration
    if (mounted) {
      _showHealthKitSheet();
      await prefs.setInt('healthkit_prompt_count', promptCount + 1);
    }
  }
}
```

**PostWorkoutHealthKitSheet:**
```dart
class PostWorkoutHealthKitSheet extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return DraggableScrollableSheet(
      initialChildSize: 0.4,
      child: Column(
        children: [
          Icon(AppIcons.healthKit, size: 48, color: Colors.red),
          Text(context.l10n.syncWithHealthKit),
          Text(context.l10n.healthKitBenefits),
          FilledButton(
            onPressed: () => _requestPermission(context, ref),
            child: Text(context.l10n.enableHealthKit),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(context.l10n.maybeLater),
          ),
        ],
      ),
    );
  }
}
```

**Acceptance Criteria:**
- [ ] HealthKit rimosso da onboarding iniziale
- [ ] Prompt dopo primo workout completato
- [ ] Max 3 reminder se rifiutato
- [ ] Degradazione graceful senza permesso

---

### P1-3: Quick Logging < 60 secondi
**Effort:** L | **Risk:** High | **Dependencies:** P1-2

**Files:**
- `lib/features/exercise_database/presentation/exercise_search_screen.dart`
- `lib/features/exercise_database/data/services/exercise_usage_tracker.dart`
- `lib/features/workout/presentation/widgets/inline_set_input.dart` (NEW)

**Current Timing Analysis:**
- Open search: ~2s
- Search + select: ~8-15s
- Add sets: ~10-15s (modal based)
- **Total: 20-30s** (already under 60s target)

**Optimization 1: Reduce Debounce**
```dart
// exercise_search_screen.dart line 89
// BEFORE
_debouncer = Debouncer(milliseconds: 400);
// AFTER
_debouncer = Debouncer(milliseconds: 250);
```

**Optimization 2: Recent Exercises Section**
```dart
// exercise_search_screen.dart - ADD at top of list
Widget _buildRecentExercisesSection() {
  final recentExercises = ref.watch(recentExercisesProvider);

  if (recentExercises.isEmpty) return SizedBox.shrink();

  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Padding(
        padding: EdgeInsets.all(16),
        child: Text(
          context.l10n.recentExercises,
          style: context.textTheme.titleSmall,
        ),
      ),
      SizedBox(
        height: 100,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: min(recentExercises.length, 5),
          itemBuilder: (context, index) => RecentExerciseChip(
            exercise: recentExercises[index],
            onTap: () => _quickAddExercise(recentExercises[index]),
          ),
        ),
      ),
      Divider(),
    ],
  );
}
```

**RecentExercisesProvider:**
```dart
final recentExercisesProvider = FutureProvider<List<Exercise>>((ref) async {
  final tracker = ref.watch(exerciseUsageTrackerProvider);
  final exerciseIds = await tracker.getRecentlyUsed(limit: 5);
  return ref.watch(exerciseRepositoryProvider).getByIds(exerciseIds);
});
```

**New Translations:**
- `recentExercises`: "Esercizi recenti" / "Recent Exercises"

**Acceptance Criteria:**
- [ ] "Recent Exercises" in cima alla ricerca
- [ ] Input inline per peso/reps (no modal)
- [ ] Auto-save debounced
- [ ] Misurato: tempo da open -> save < 60s

---

### P1-4: Localizzazione error messages
**Effort:** M | **Risk:** Medium | **Dependencies:** None

**Files:**
- `lib/shared/domain/failures/failure.dart`
- `lib/features/workout/domain/usecases/complete_workout_usecase.dart`
- `lib/shared/presentation/helpers/failure_translation_helper.dart` (NEW)
- `lib/l10n/app_en.arb`
- `lib/l10n/app_it.arb`

**Current Hardcoded Messages:**
```dart
// complete_workout_usecase.dart - 5 hardcoded messages
ValidationFailure('Workout must be in "in progress" status to complete')
ValidationFailure('Workout has not been started yet')
ValidationFailure('Cannot complete workout without exercises')
ValidationFailure('Workout must have at least one completed set')
ValidationFailure('Workout duration too short (minimum 1 minute)')
```

**Solution: Error Codes + Translation Helper**
```dart
// failure.dart - ADD code field
class ValidationFailure extends Failure {
  final String? code;

  const ValidationFailure(String message, {this.code}) : super(message);
}

// Usage in usecase:
ValidationFailure('invalid_status', code: 'invalid_workout_status')
```

**FailureTranslationHelper:**
```dart
// lib/shared/presentation/helpers/failure_translation_helper.dart
class FailureTranslationHelper {
  static String translate(Failure failure, AppLocalizations l10n) {
    if (failure is ValidationFailure && failure.code != null) {
      return switch (failure.code) {
        'invalid_workout_status' => l10n.errorInvalidWorkoutStatus,
        'workout_not_started' => l10n.errorWorkoutNotStarted,
        'no_exercises' => l10n.errorNoExercises,
        'no_completed_sets' => l10n.errorNoCompletedSets,
        'workout_too_short' => l10n.errorWorkoutTooShort,
        'invalid_weight' => l10n.errorInvalidWeight,
        'invalid_reps' => l10n.errorInvalidReps,
        'template_not_found' => l10n.errorTemplateNotFound,
        'exercise_not_found' => l10n.errorExerciseNotFound,
        'sync_failed' => l10n.errorSyncFailed,
        _ => failure.message,
      };
    }

    if (failure is NetworkFailure) {
      return l10n.errorNetworkUnavailable;
    }

    if (failure is ServerFailure) {
      return l10n.errorServerUnavailable;
    }

    return failure.message;
  }
}
```

**New ARB Keys (30 total):**
```json
// app_en.arb
"errorInvalidWorkoutStatus": "Workout must be in progress to complete",
"errorWorkoutNotStarted": "Please start the workout first",
"errorNoExercises": "Add at least one exercise",
"errorNoCompletedSets": "Complete at least one set",
"errorWorkoutTooShort": "Workout must be at least 1 minute",
"errorInvalidWeight": "Please enter a valid weight",
"errorInvalidReps": "Please enter valid reps",
"errorTemplateNotFound": "Template not found",
"errorExerciseNotFound": "Exercise not found",
"errorSyncFailed": "Sync failed. Please try again",
"errorNetworkUnavailable": "No internet connection",
"errorServerUnavailable": "Server temporarily unavailable"
// ... 18 more for other failures
```

**Acceptance Criteria:**
- [ ] ValidationFailure usa codici, non stringhe
- [ ] Presentation layer traduce codici
- [ ] Nessun messaggio hardcoded in domain
- [ ] Test coverage per traduzioni

---

## MEDIUM PRIORITY (P2) Tasks

### P2-1: Semantic Labels VoiceOver
**Effort:** M | **Risk:** Low | **Dependencies:** None

**Files:**
- 74 files with GestureDetector (only 2.7% have Semantics)
- 113 GestureDetector instances need wrapping

**Audit Results:**
| Priority | File | GestureDetectors |
|----------|------|------------------|
| HIGH | `exercise_list_item_sets.dart` | 5 |
| HIGH | `workout_screen.dart` | 8 |
| HIGH | `minimal_home_screen.dart` | 6 |
| MEDIUM | `template_card.dart` | 3 |
| MEDIUM | `exercise_card.dart` | 4 |

**Pattern to Apply:**
```dart
// BEFORE
GestureDetector(
  onTap: () => _handleDelete(),
  child: Container(child: Icon(AppIcons.delete)),
)

// AFTER
Semantics(
  label: context.l10n.deleteWorkout,
  button: true,
  child: GestureDetector(
    onTap: () => _handleDelete(),
    child: Container(child: Icon(AppIcons.delete)),
  ),
)
```

**Existing Helper:**
`lib/shared/presentation/widgets/semantic_icon.dart` - can extend

**Implementation Order:**
1. Core workout flow (exercise_list_item_sets, workout_screen)
2. Home screen interactions (minimal_home_screen)
3. Template management (template_card, template_list)
4. Settings and navigation
5. Analytics and insights

**Acceptance Criteria:**
- [ ] Audit tutti i GestureDetector
- [ ] Semantics.label su bottoni custom
- [ ] excludeSemantics dove appropriato
- [ ] Test con VoiceOver reale

---

### P2-2: Simple Mode
**Effort:** L | **Risk:** Medium | **Dependencies:** None

**Files:**
- `lib/shared/domain/entities/app_config.dart`
- `lib/features/settings/presentation/screens/settings_screen.dart`
- `lib/features/home/presentation/minimal_home_screen.dart`

**AppConfig Addition:**
```dart
// app_config.dart
@HiveField(49)
final bool simpleMode;  // default: false
```

**Features to Hide in Simple Mode:**
- AI Coach card
- Stress Index widget
- Pro Insights section
- Recovery Insight
- Advanced Analytics (keep basic stats)
- Activity Rings (complex visualization)

**Font Scaling:**
Already exists: `config.fontSize` (0.8-1.2 multiplier)
Simple mode: set to 1.2 automatically

**Settings Toggle:**
```dart
SwitchListTile(
  title: Text(context.l10n.simpleMode),
  subtitle: Text(context.l10n.simpleModeDescription),
  value: config.simpleMode,
  onChanged: (value) {
    ref.read(appConfigProvider.notifier).update(
      simpleMode: value,
      fontSize: value ? 1.2 : 1.0,
    );
  },
)
```

**Conditional Rendering:**
```dart
// minimal_home_screen.dart
if (!config.simpleMode) ...[
  AiCoachCard(),
  StressIndexWidget(),
  ProInsightsSection(),
],

// Always show
QuickStartTemplateCard(),  // Made prominent
BasicStatsCard(),
RecentWorkoutsSection(),
```

**Acceptance Criteria:**
- [ ] Toggle in Settings
- [ ] Nasconde: AI Coach, Stress Index, Analytics avanzate
- [ ] Font size +20%
- [ ] Template "Quick Start" prominente

---

### P2-3: Template Folders per Coach
**Effort:** M | **Risk:** Medium | **Dependencies:** None

**Files:**
- `lib/features/coach/domain/entities/template_folder.dart` (NEW)
- `lib/features/coach/domain/entities/coach_template.dart` (UPDATE)
- `lib/features/coach/data/repositories/coach_templates_repository.dart` (UPDATE)
- `lib/features/coach/presentation/screens/template_folders_screen.dart` (NEW)

**New Entity:**
```dart
// template_folder.dart
@freezed
abstract class TemplateFolder with _$TemplateFolder {
  const factory TemplateFolder({
    required String id,
    required String coachId,
    required String name,
    String? colorHex,
    @Default(TemplateFolderType.custom) TemplateFolderType type,
    @Default(0) int sortOrder,
    @Default(0) int templateCount,
    required DateTime createdAt,
    required DateTime updatedAt,
  }) = _TemplateFolder;

  factory TemplateFolder.fromJson(Map<String, dynamic> json) =>
    _$TemplateFolderFromJson(json);
}

enum TemplateFolderType { all, favorites, shared, custom }
```

**CoachTemplate Update:**
```dart
// coach_template.dart - ADD fields
@Default('') String folderId,
@Default(false) bool isFavorite,
@Default(0) int sortOrder,
```

**Firestore Structure:**
```
users/{coachId}/templateFolders/{folderId}
  - name: "Push Day Templates"
  - colorHex: "#FF5722"
  - sortOrder: 0
  - templateCount: 5

coachTemplates/{templateId}
  - folderId: "folder123"  // NEW field
  - sortOrder: 0           // NEW field
```

**Required Indexes:**
```
Collection: coachTemplates
Fields: coachId ASC, folderId ASC, sortOrder ASC
```

**Drag-Drop Implementation:**
```dart
ReorderableListView.builder(
  onReorder: (oldIndex, newIndex) async {
    await ref.read(templateFoldersProvider.notifier)
      .reorderTemplate(oldIndex, newIndex);
  },
  itemBuilder: (context, index) => DraggableTemplateCard(
    key: ValueKey(templates[index].id),
    template: templates[index],
  ),
)
```

**Acceptance Criteria:**
- [ ] CRUD folders
- [ ] Drag-drop templates
- [ ] Condivisione folder con atleti
- [ ] Migrazione templates esistenti

---

### P2-4: PDF Branding
**Effort:** L | **Risk:** Medium | **Dependencies:** None

**Files:**
- `lib/features/coach/domain/entities/coach_branding.dart` (NEW)
- `lib/features/coach/data/repositories/coach_branding_repository.dart` (NEW)
- `lib/features/workout/services/pdf_template_service.dart` (UPDATE)
- `lib/features/coach/presentation/screens/branding_settings_screen.dart` (NEW)

**New Entity:**
```dart
// coach_branding.dart
@freezed
abstract class CoachBranding with _$CoachBranding {
  const factory CoachBranding({
    required String coachId,
    required String displayName,
    String? businessName,
    String? logoUrl,
    @Default('#2196F3') String primaryColor,
    @Default('#FF9800') String accentColor,
    String? phone,
    String? email,
    String? website,
    String? headerText,
    String? footerTagline,
    @Default(true) bool showCoachName,
    @Default(false) bool showLogo,
    required DateTime createdAt,
    required DateTime updatedAt,
  }) = _CoachBranding;

  factory CoachBranding.fromJson(Map<String, dynamic> json) =>
    _$CoachBrandingFromJson(json);
}
```

**Firebase Storage Path:**
```
users/{coachId}/branding/logo.webp
```

**Logo Upload:**
```dart
Future<String?> uploadLogo(File imageFile) async {
  // Validate
  final bytes = await imageFile.length();
  if (bytes > 2 * 1024 * 1024) {
    throw ValidationFailure('Logo must be under 2MB', code: 'logo_too_large');
  }

  // Compress and upload
  final compressed = await FlutterImageCompress.compressWithFile(
    imageFile.path,
    format: CompressFormat.webp,
    quality: 85,
    minWidth: 400,
    minHeight: 400,
  );

  final ref = _storage.ref('users/$coachId/branding/logo.webp');
  await ref.putData(compressed!);
  return await ref.getDownloadURL();
}
```

**PDF Template Update:**
```dart
// pdf_template_service.dart
pw.Widget _buildHeader(CoachBranding? branding) {
  return pw.Row(
    mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
    children: [
      if (branding?.showLogo == true && branding?.logoUrl != null)
        pw.Image(
          pw.MemoryImage(await _loadImage(branding!.logoUrl!)),
          width: 60,
          height: 60,
        ),
      pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.end,
        children: [
          pw.Text(
            branding?.businessName ?? branding?.displayName ?? 'FitLog Pro',
            style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold),
          ),
          if (branding?.phone != null)
            pw.Text(branding!.phone!, style: pw.TextStyle(fontSize: 10)),
          if (branding?.email != null)
            pw.Text(branding!.email!, style: pw.TextStyle(fontSize: 10)),
        ],
      ),
    ],
  );
}
```

**Acceptance Criteria:**
- [ ] Upload logo (max 2MB, PNG/JPG)
- [ ] Campi: nome, telefono, email, website
- [ ] Preview PDF prima export
- [ ] Persistenza per account coach

---

## Dependency Graph

```
P0-1 ──→ P0-4
         (Home Tour reduction enables Progressive Disclosure)

P0-2 (independent)

P0-3 (independent)

P1-2 ──→ P1-3
         (HealthKit timing affects Quick Logging flow)

P1-1, P1-4 (independent)

P2-* (all independent)
```

## Sprint Plan

| Sprint | Tasks | Effort | Focus |
|--------|-------|--------|-------|
| 1 | P0-1, P0-2, P0-3 | ~1 week | Quick Wins |
| 2 | P0-4, P1-4 | ~2 weeks | Progressive Disclosure |
| 3 | P1-1, P1-2 | ~1.5 weeks | Auth & Permissions |
| 4 | P1-3 | ~2 weeks | Performance |
| 5 | P2-1, P2-2 | ~2 weeks | Accessibility |
| 6 | P2-3, P2-4 | ~2 weeks | Coach Features |

---

## Implementation Checklist

### Before Starting Any Task
- [ ] Read existing code patterns in target files
- [ ] Check for similar implementations in codebase
- [ ] Verify all required translations exist
- [ ] Plan test strategy

### After Completing Any Task
- [ ] Run `flutter analyze`
- [ ] Run `flutter gen-l10n` if translations added
- [ ] Test dark/light mode
- [ ] Test VoiceOver accessibility
- [ ] Update documentation

---

## Research Completed

All 12 tasks analyzed by parallel research agents on 2026-01-02:
- Code patterns identified
- Integration points mapped
- Implementation details specified
- Test strategies defined
- Migration plans where applicable

Ready for implementation.
