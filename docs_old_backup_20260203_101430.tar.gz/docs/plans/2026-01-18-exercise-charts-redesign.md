# Exercise Charts Redesign

> **Status**: Approved
> **Date**: 2026-01-18
> **Screen**: Exercise Detail Screen (`exercise_detail_screen.dart`)

---

## Problem Statement

Current charts in the Exercise Detail Screen use identical line charts for all metrics (weight, volume, reps, RPE). User feedback indicates they don't feel visually engaging, and research shows different chart types better communicate different data types.

## Design Decision

Replace fl_chart with Syncfusion Flutter Charts and use metric-appropriate chart types based on UX research and persona analysis.

---

## Chart Types by Metric

### 1. Weight Progression → Line Chart (Enhanced)

**Rationale**: Line charts are universally understood for "progression over time". Weight tracking benefits from seeing the trend clearly.

**Design**:
- Smooth curved line with gradient fill below
- Prominent data points at each session
- Touch tooltip showing date + weight
- Trend indicator badge (↗ +5%)
- Color: Primary blue

**Personas served**: Luca (PR tracking), Marco (visible progress)

### 2. Volume Progression → Bar Chart (Vertical)

**Rationale**: Volume represents "quantity" - bar charts are more intuitive for discrete amounts. Research shows users understand "I lifted THIS MUCH" better with bars.

**Design**:
- Vertical bars, one per session/day
- Gradient fill from bottom
- Highlighted max bar
- Total volume label
- Color: Warning/Orange

**Personas served**: Sofia (volume per muscle), Luca (detailed analytics)

### 3. Reps Progression → Line Chart (Simplified)

**Rationale**: Reps show consistency patterns over time. Line chart maintains visual consistency with weight chart while showing trends.

**Design**:
- Thinner line, subtle gradient
- Average line overlay (dashed)
- Fewer data points (aggregate by session)
- Color: Success/Green

**Personas served**: Marco (simple), Chiara (quick view)

### 4. RPE/Effort → Gauge + Sparkline

**Rationale**: RPE (1-10 scale) is confusing for beginners. A gauge/dial is immediately intuitive as an "effort meter". Mini sparkline shows recent trend.

**Design**:
- Semi-circular gauge (180°)
- Color zones: Green (1-5), Yellow (6-7), Orange (8), Red (9-10)
- Current average RPE as large number
- Label: "Easy" / "Moderate" / "Challenging" / "Maximum"
- Mini sparkline below showing last 7 sessions
- Color: Error/Red primary

**Personas served**: Luca (RPE tracking), Marco (understandable without jargon)

---

## Visual Mockup

```
┌──────────────────────────────────────┐
│ 💪 WEIGHT         ↗ +5% this month   │
│ ╭─────────────────────────╮          │
│ │    ∿∿∿∿∿↗               │ 85 kg    │
│ │▓▓▓▓▓▓▓▓░░░░░░░░░░░░░░░░│          │
│ ╰─────────────────────────╯          │
├──────────────────────────────────────┤
│ 📊 VOLUME         ↗ +12%             │
│  █ █ ▄ █ █ ▅ █                       │
│  L M M G V S D    2,450 kg total     │
├──────────────────────────────────────┤
│ 🔄 REPS           → Stable           │
│ ╭─────────────────────────╮          │
│ │  ─∿─∿─∿─∿─              │ ~10 avg  │
│ ╰─────────────────────────╯          │
├──────────────────────────────────────┤
│ 🎯 EFFORT (RPE)                      │
│      ╭─────╮                         │
│     ╱  7.5  ╲   "Challenging"        │
│    ╰─────────╯                       │
│    ▁▂▃▅▆▅▄▃  ← mini trend            │
└──────────────────────────────────────┘
```

---

## Technical Implementation

### Library Change

**From**: `fl_chart` (6 chart types, open-source)
**To**: `syncfusion_flutter_charts` (30+ types, free community license)

### New Dependencies

```yaml
dependencies:
  syncfusion_flutter_charts: ^latest
  syncfusion_flutter_gauges: ^latest  # For RPE gauge
```

### Files to Modify

1. `pubspec.yaml` - Add Syncfusion dependencies
2. `lib/features/analytics/presentation/screens/exercise_detail_screen.dart` - Replace chart widgets
3. Create new widget files:
   - `lib/features/analytics/presentation/widgets/charts/weight_line_chart.dart`
   - `lib/features/analytics/presentation/widgets/charts/volume_bar_chart.dart`
   - `lib/features/analytics/presentation/widgets/charts/reps_line_chart.dart`
   - `lib/features/analytics/presentation/widgets/charts/rpe_gauge_widget.dart`

### Syncfusion License

Syncfusion offers free community license for:
- Companies with < $1M annual revenue
- < 5 developers
- < 10 total employees

FitLog qualifies for free community license.

---

## Persona Validation

| Persona | Need | How Design Addresses |
|---------|------|---------------------|
| Marco (Beginner) | Simple, visible progress | Bar chart intuitive, gauge removes RPE confusion |
| Chiara (Busy Mom) | Quick overview | Each chart has summary stat visible |
| Luca (Powerlifter) | Detailed tracking | All data preserved, touch for details |
| Sofia (Aesthetic) | Volume visibility | Bar chart highlights volume clearly |
| Roberto (Professional) | No overload | Clean design, one insight per chart |
| Davide (Tech) | Analytics | All data available, multiple chart types |

---

## UX Research Sources

- [ZFort - Fitness App UX Best Practices](https://www.zfort.com/blog/How-to-Design-a-Fitness-App-UX-UI-Best-Practices-for-Engagement-and-Retention)
- [UXmatters - Fitness Platform Design](https://www.uxmatters.com/mt/archives/2025/07/designing-a-fitness-platform-ux-design-challenges-and-solutions.php)
- [Dataconomy - UX/UI Practices 2025](https://dataconomy.com/2025/11/11/best-ux-ui-practices-for-fitness-apps-retaining-and-re-engaging-users/)
- [Better Charts for Lifting Analysis](https://www.benmcallister.com/better-strength-charts/)

---

## Implementation Steps

1. [ ] Add Syncfusion dependencies to pubspec.yaml
2. [ ] Register Syncfusion license key (free community)
3. [ ] Create WeightLineChart widget
4. [ ] Create VolumeBarChart widget
5. [ ] Create RepsLineChart widget
6. [ ] Create RpeGaugeWidget widget
7. [ ] Update ExerciseDetailScreen to use new charts
8. [ ] Remove fl_chart dependency (if no longer used elsewhere)
9. [ ] Test on iOS and Android
10. [ ] Verify dark/light theme support

---

## Success Metrics

- User engagement with charts (tap interactions)
- Time spent on Exercise Detail Screen
- Qualitative feedback on chart clarity
