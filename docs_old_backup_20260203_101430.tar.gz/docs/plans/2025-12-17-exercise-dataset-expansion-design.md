# Exercise Dataset Expansion Design

**Data**: 2025-12-17
**Status**: Approvato
**Autore**: Claude + Michele

---

## Obiettivo

Espandere il dataset di esercizi da 1545 a ~2282 esercizi, integrando 737 nuovi esercizi dal repository [gartu/free-exercise-db](https://github.com/gartu/free-exercise-db-with-llm-translator-and-wger-insert-script).

## Decisioni Chiave

| Decisione | Scelta | Motivazione |
|-----------|--------|-------------|
| **Hosting immagini** | jsDelivr + GitHub | Gratuito, illimitato, CDN globale |
| **Formato immagini** | WebP animato (2 frame) | Già disponibile nel repo, ~60KB, supportato Flutter |
| **Strategia duplicati** | Merge intelligente | Mantiene dati esistenti ricchi, aggiunge solo nuovi |
| **Target utenti** | 100-1000 DAU | Free tier sufficiente con caching |

## Architettura

### Hosting Immagini

```
GitHub Repository (fork)
        │
        ▼
    jsDelivr CDN ──────► Cache globale
        │
        ▼
https://cdn.jsdelivr.net/gh/{user}/exercise-images@main/exercises/{id}/exercise.webp
        │
        ▼
    Flutter App
        │
        ▼
    GifCacheManager (30 giorni cache locale)
```

**Vantaggi jsDelivr:**
- Bandwidth illimitato gratuito
- CDN globale (server in tutto il mondo)
- Cache automatica
- Nessun rischio downtime per limiti

### Struttura Repository GitHub

```
exercise-images/
├── exercises/
│   ├── 3_4_Sit-Up/
│   │   └── exercise.webp      # WebP animato 2 frame
│   ├── Ab_Roller/
│   │   └── exercise.webp
│   └── ... (737 cartelle)
└── README.md
```

### Mapping Dati

| Campo Sorgente | Campo Target | Trasformazione |
|----------------|--------------|----------------|
| `name` | `nome` | Traduzione italiano |
| `level` | `difficolta` | beginner→Principiante, intermediate→Intermedio, expert→Avanzato |
| `primaryMuscles[0]` | `focus` | Mapping a codici (chest→PETT, shoulders→DELT, etc.) |
| `secondaryMuscles` | `muscoliSecondari` | Mapping a codici |
| `equipment` | `attrezzatura` | Mapping italiano |
| `instructions[]` | `noteTecniche` | Join con " \| " |
| `mechanic` | `tipoEsercizio` | compound→Compound, isolation→Isolation |
| `category` | `patternMovimento` | Mapping diretto |
| N/A | `imageUrl` | URL jsDelivr generato |
| N/A | `countingMode` | Default "reps" o inferito |
| N/A | `aliases` | Generati da nome |
| N/A | `version` | "1.0.0" |

### Mapping Muscoli

```python
MUSCLE_MAP = {
    "chest": "PETT",
    "shoulders": "DELT",
    "triceps": "TRIC",
    "biceps": "BIC",
    "forearms": "AVAMB",
    "lats": "DORSO",
    "middle back": "DORSO",
    "lower back": "LOMB",
    "traps": "TRAP",
    "abdominals": "ADDOM",
    "quadriceps": "QUAD",
    "hamstrings": "FEMO",
    "glutes": "GLUT",
    "calves": "POLL",
    "adductors": "ADDUT",
    "abductors": "ABDUT",
    "neck": "COLLO"
}
```

### Distribuzione per Categoria

| Categoria JSON | Criteri |
|----------------|---------|
| `upper_push.json` | focus in [PETT, DELT, TRIC] |
| `upper_pull.json` | focus in [DORSO, BIC, TRAP, AVAMB] |
| `lower.json` | focus in [QUAD, FEMO, GLUT, POLL, ADDUT, ABDUT] |
| `core.json` | focus in [ADDOM, LOMB] |
| `other.json` | cardio, plyometrics, strongman, olympic weightlifting |

## Nuovi Esercizi per Categoria

| Categoria | Quantità | Esempi |
|-----------|----------|--------|
| strength | 476 | Lying Leg Curls, Standing Concentration Curl |
| stretching | 101 | Standing Elevated Quad Stretch, Rhomboids-SMR |
| plyometrics | 58 | Rocket Jump, Side to Side Box Shuffle |
| powerlifting | 36 | Pin Presses, Sumo Deadlift with Chains |
| olympic weightlifting | 33 | Jerk Balance, Power Jerk |
| strongman | 19 | Axle Deadlift, Rickshaw Carry |
| cardio | 14 | Trail Running, Bicycling |

## Impatto sul Codice Flutter

**Modifiche necessarie: MINIME**

Il widget `ExerciseGifWidget` usa già `CachedNetworkImage` che funziona con qualsiasi URL. L'unica differenza è l'URL nei JSON.

```dart
// Funziona già - nessuna modifica necessaria
CachedNetworkImage(
  imageUrl: gifUrl!,  // Può essere exercisedb.dev O jsdelivr
  cacheManager: GifCacheManager.instance,
  ...
)
```

## Piano di Implementazione

### Fase 1: Setup Repository GitHub
1. Fork `gartu/free-exercise-db-with-llm-translator-and-wger-insert-script`
2. Rimuovere file non necessari (scripts, site/, etc.)
3. Mantenere solo `/exercises/*/exercise.webp`
4. Verificare che jsDelivr serva correttamente

### Fase 2: Script Conversione
1. Creare script Python per:
   - Leggere 737 esercizi dal repo
   - Filtrare duplicati (136 già esistenti)
   - Convertire al formato FitLog
   - Tradurre nomi in italiano
   - Generare URL jsDelivr
   - Distribuire nei file JSON corretti

### Fase 3: Merge e Validazione
1. Aggiungere nuovi esercizi ai JSON esistenti
2. Aggiornare `_index.json`
3. Eseguire `flutter analyze`
4. Test manuale caricamento immagini
5. Verificare nessun duplicato nell'app

### Fase 4: Test Performance
1. Verificare tempi di caricamento immagini
2. Controllare cache funzionante
3. Test offline dopo primo caricamento

## Rischi e Mitigazioni

| Rischio | Probabilità | Impatto | Mitigazione |
|---------|-------------|---------|-------------|
| jsDelivr down | Bassa | Alto | Cache locale 30 giorni copre |
| Memory leak WebP | Bassa | Medio | Flutter 3.38 ha fix, monitoring |
| Traduzioni imprecise | Media | Basso | Review manuale nomi comuni |
| Cache invalidation lenta | Media | Basso | Versioning URL se necessario |

## Metriche di Successo

- [ ] 737 nuovi esercizi aggiunti senza duplicati
- [ ] Immagini caricano in <2s su 4G
- [ ] Cache locale funzionante (offline dopo primo load)
- [ ] Nessun aumento significativo dimensione app bundle
- [ ] `flutter analyze` passa senza errori

## Stima Effort

| Task | Tempo stimato |
|------|---------------|
| Setup GitHub + fork | 30 min |
| Script conversione | 2-3 ore |
| Traduzione/review nomi | 1-2 ore |
| Merge e test | 1 ora |
| **Totale** | **5-7 ore** |

---

## Appendice: Calcolo Bandwidth

```
Scenario: 500 utenti attivi/mese

Primo utilizzo (no cache):
- 50 esercizi visti/utente × 60KB = 3MB/utente
- 500 utenti × 3MB = 1.5GB primo mese

Utilizzo successivo (con cache):
- Cache locale 30 giorni → quasi 0 download
- Solo nuovi esercizi non visti → trascurabile

Conclusione: jsDelivr free tier (illimitato) è più che sufficiente
```
