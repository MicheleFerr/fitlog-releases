# GDPR Compliance Task Plan - FitLog Pro

**Data**: 2025-01-01
**Generato con**: task-master.dev
**Effort Totale**: ~60 story points
**Timeline**: 10 settimane (5 sprint)

---

## Executive Summary

| Severità | Tasks | Effort |
|----------|-------|--------|
| CRITICO (P0) | 7 | 30 pts |
| ALTO (P1) | 7 | 18 pts |
| MEDIO (P2) | 4 | 12 pts |
| **TOTALE** | **18** | **60 pts** |

---

## PHASE 1: CRITICAL INFRASTRUCTURE (Sprint 1-2)

### C1: Delete Account UI Implementation
- **Priority**: P0 | **Effort**: 3 pts | **Dependencies**: None
- **File**: `lib/features/settings/presentation/settings_screen.dart`
- **Tasks**:
  - [ ] Add "Delete Account" button to Settings screen
  - [ ] Create confirmation dialog with data loss warning
  - [ ] Wire to deleteAllUserData() backend method
  - [ ] Add analytics event for deletion request
  - [ ] Test dark/light mode

### C2: Complete deleteAllUserData() Method
- **Priority**: P0 | **Effort**: 5 pts | **Dependencies**: C1
- **File**: `lib/shared/domain/privacy/privacy_manager.dart`
- **Tasks**:
  - [ ] Remove all TODOs from implementation
  - [ ] Delete Firestore: `/users/{userId}/*` (all subcollections)
  - [ ] Delete Firebase Storage: `users/{userId}/progress_photos/*`
  - [ ] Clear Hive boxes: workout_history, templates, analytics, user_profile_cache
  - [ ] Delete Firebase Auth account
  - [ ] Add error handling & rollback logic
  - [ ] Unit tests

### C7: HealthKit Consent Separation
- **Priority**: P0 | **Effort**: 2 pts | **Dependencies**: None
- **Files**:
  - `lib/shared/domain/privacy/consent_type.dart`
  - `ios/Runner/Info.plist`
- **Tasks**:
  - [ ] Add `ConsentType.healthKitData`
  - [ ] Update HealthKitRepository to check consent
  - [ ] Modify onboarding flow for HealthKit consent
  - [ ] Log consent timestamp per Art. 7(4)

---

## PHASE 2: DATA CLASSIFICATION & CONSENT (Sprint 2-3)

### C3: Progress Photos - Biometric Consent
- **Priority**: P0 | **Effort**: 4 pts | **Dependencies**: C7
- **Files**:
  - `lib/features/progress_photos/domain/entities/progress_photo.dart`
  - `lib/shared/domain/privacy/consent_type.dart`
- **Tasks**:
  - [ ] Add `ConsentType.progressPhotos`
  - [ ] Tag collection as "Art. 9" special category
  - [ ] Require explicit opt-in before camera access
  - [ ] Add photo consent revision history to Firestore
  - [ ] Document processing purpose in privacy notice

### C4: Body Measurements Reclassification
- **Priority**: P0 | **Effort**: 3 pts | **Dependencies**: None
- **Files**:
  - `lib/shared/domain/privacy/consent_type.dart`
  - `lib/features/body_measurements/domain/entities/user_consent.dart`
- **Tasks**:
  - [ ] Add `ConsentType.healthData`
  - [ ] Reclassify measurements as Art. 9 health data
  - [ ] Update UI consent labels
  - [ ] Add consent audit log entry

---

## PHASE 3: DATA TRANSFERS & DOCUMENTATION (Sprint 3)

### C5: Transfer Impact Assessment (TIA)
- **Priority**: P0 | **Effort**: 6 pts | **Dependencies**: None
- **Output**: `docs/legal/TIA_FIREBASE.md`
- **Tasks**:
  - [ ] Document Firebase (USA) data transfer mechanism
  - [ ] Identify SCCs with Firebase/Google
  - [ ] Conduct transfer risk assessment (Schrems II)
  - [ ] Add supplementary safeguards if needed
  - [ ] Generate TIA document
  - [ ] Store in compliance repository

### A3: DPA Documentation
- **Priority**: P1 | **Effort**: 2 pts | **Dependencies**: C5
- **Output**: `docs/legal/DPA/`
- **Tasks**:
  - [ ] Verify DPA exists with Firebase
  - [ ] Ensure DPA covers Special Categories
  - [ ] Link DPA version to release notes
  - [ ] Create annual review checklist

---

## PHASE 4: RETENTION & DELETION AUTOMATION (Sprint 4)

### C6: 24-Month Retention Policy Implementation
- **Priority**: P0 | **Effort**: 7 pts | **Dependencies**: C2
- **Files**: Cloud Functions (new)
- **Tasks**:
  - [ ] Add `last_activity_date` field to user documents
  - [ ] Create Cloud Function for monthly inactivity check
  - [ ] Implement soft-delete flag before hard deletion
  - [ ] Send warning email at month 23 (M2 dependency)
  - [ ] Hard-delete at month 24 with audit log
  - [ ] Add lifecycle status to user profile

### M2: Pre-Deletion Warning Email
- **Priority**: P1 | **Effort**: 2 pts | **Dependencies**: C6
- **Tasks**:
  - [ ] Design email template (30-day pre-deletion notice)
  - [ ] Implement Firebase Cloud Function trigger
  - [ ] Add "keep my account" link
  - [ ] Track email delivery status

### A1: Hard-Delete Photos (30-day SLA)
- **Priority**: P1 | **Effort**: 4 pts | **Dependencies**: C6
- **Tasks**:
  - [ ] Create retention policy for progress_photos
  - [ ] Implement Cloud Function for 30-day hard delete
  - [ ] Add photo expiry timestamp on soft-delete
  - [ ] Verify via Cloud Storage audit logs

---

## PHASE 5: ANALYTICS & CONSENT GATING (Sprint 4-5)

### A2: Consent-Gated Analytics Initialization
- **Priority**: P1 | **Effort**: 3 pts | **Dependencies**: C7
- **File**: `lib/main.dart`
- **Tasks**:
  - [ ] Move analytics init after consent check
  - [ ] Add gating logic to FirebaseAnalytics calls
  - [ ] Disable tracking until consent = true
  - [ ] Unit test analytics disabled state

### A4: Export UI Path Alignment
- **Priority**: P1 | **Effort**: 2 pts | **Dependencies**: None
- **Files**:
  - `lib/features/settings/presentation/settings_screen.dart`
  - `docs/legal/PRIVACY_POLICY_IT.md`
- **Tasks**:
  - [ ] Verify privacy policy path matches Settings navigation
  - [ ] Move/add Data Export to correct location
  - [ ] Update privacy policy if needed

### A5: .env Secrets in Release Builds
- **Priority**: P1 | **Effort**: 3 pts | **Dependencies**: None
- **File**: `pubspec.yaml`
- **Tasks**:
  - [ ] Audit .env usage in build process
  - [ ] Verify .env excluded from release builds
  - [ ] Use --dart-define for compile-time config only
  - [ ] Add pre-commit hook to block .env commits

---

## PHASE 6: RESTRICTED PROCESSING & AUDITING (Sprint 5)

### M1: Article 18 Restriction Flag
- **Priority**: P2 | **Effort**: 4 pts | **Dependencies**: C2
- **Tasks**:
  - [ ] Add `is_restricted` boolean to user document
  - [ ] Prevent processing during restriction (read-only mode)
  - [ ] Show "Data Restricted" banner in UI
  - [ ] Log all access attempts to restricted data

### M3: Admin Access Audit Log
- **Priority**: P2 | **Effort**: 5 pts | **Dependencies**: None
- **Tasks**:
  - [ ] Create `admin_access_logs` collection
  - [ ] Log timestamp, admin_id, user_id, action
  - [ ] Implement read-only audit viewer
  - [ ] Set 90-day retention on logs

### M4: Backup Encryption Verification
- **Priority**: P2 | **Effort**: 3 pts | **Dependencies**: None
- **Tasks**:
  - [ ] Verify Firestore backup encryption
  - [ ] Test restore with encrypted data
  - [ ] Document in compliance docs

### M5: Penetration Test Schedule
- **Priority**: P2 | **Effort**: 1 pt | **Dependencies**: None
- **Tasks**:
  - [ ] Schedule pentest with security firm
  - [ ] Include Firebase auth bypass scenarios
  - [ ] Review results before release

---

## SPRINT ROADMAP

```
Sprint 1 (Settimane 1-2):  C1, C2, C7, A5       [14 pts]
Sprint 2 (Settimane 3-4):  C3, C4, C5, A3       [15 pts]
Sprint 3 (Settimane 5-6):  C6, M2, A1, A2       [16 pts]
Sprint 4 (Settimane 7-8):  M1, M3, A4           [11 pts]
Sprint 5 (Settimane 9-10): M4, M5 + Testing     [4 pts]
```

---

## Dipendenze Critiche

```
C1 ──► C2 ──► C6 ──► M2
              │
              └──► A1

C7 ──► C3
   └──► A2

C5 ──► A3
```

---

## Definition of Done per Task

- [ ] Codice implementato seguendo Clean Architecture
- [ ] Unit test con coverage > 80%
- [ ] `flutter analyze` passa senza errori
- [ ] Testato dark/light mode
- [ ] Documentazione aggiornata
- [ ] Privacy policy aggiornata (se necessario)
- [ ] Code review completata

---

## Note Legali

> **DISCLAIMER**: Questo piano è una guida tecnica. Consultare un avvocato specializzato in GDPR per validare la conformità legale delle implementazioni.

---

*Piano generato il 2025-01-01 via task-master.dev*
