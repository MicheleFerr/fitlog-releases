# Template Assignment for Coach Mode - Design Document

## Overview

Allow coaches to assign workout templates to their athletes. Templates are **linked** (not copied), meaning changes by the coach propagate to all assigned athletes.

## User Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Ownership Model | **Link (reference)** | Coach owns template, athletes see reference |
| Coach Library | **Separate section** | Distinct from personal templates |
| Sync Behavior | **Auto-sync by default** | Changes propagate automatically |

## Competitor Research Summary

| App | Pattern | Key Insight |
|-----|---------|-------------|
| TrueCoach | Sync ON/OFF toggle | Coach controls propagation |
| TrainHeroic | Hard copy on assign | Athlete can modify their copy |
| Hevy Coach | Program library + folders | Organization by program |
| Everfit | Drag & drop builder | Visual program creation |

**Our approach**: Link model with auto-sync (simpler than toggle), but athletes can make local notes.

---

## Data Model

### New Firestore Collections

```
/coachTemplates/{templateId}
  - coachId: string (owner)
  - name: string
  - description: string
  - exercises: Exercise[]
  - createdAt: Timestamp
  - updatedAt: Timestamp
  - assignedTo: string[] (athleteIds)
  - isArchived: boolean

/users/{userId}/assignedTemplates/{templateId}
  - coachTemplateId: string (reference)
  - coachId: string
  - assignedAt: Timestamp
  - athleteNotes: string? (local notes)
  - lastSyncedAt: Timestamp
```

### Entity Classes

```dart
// lib/features/coach/domain/entities/coach_template.dart
@freezed
class CoachTemplate with _$CoachTemplate {
  const factory CoachTemplate({
    required String id,
    required String coachId,
    required String name,
    String? description,
    required List<TemplateExercise> exercises,
    required DateTime createdAt,
    required DateTime updatedAt,
    @Default([]) List<String> assignedTo,
    @Default(false) bool isArchived,
  }) = _CoachTemplate;
}

// lib/features/coach/domain/entities/assigned_template.dart
@freezed
class AssignedTemplate with _$AssignedTemplate {
  const factory AssignedTemplate({
    required String id,
    required String coachTemplateId,
    required String coachId,
    required DateTime assignedAt,
    String? athleteNotes,
    required DateTime lastSyncedAt,
    // Denormalized for display
    String? templateName,
    String? coachName,
  }) = _AssignedTemplate;
}
```

---

## UI Components

### 1. CoachTemplatesScreen

**Location**: `lib/features/coach/presentation/screens/coach_templates_screen.dart`

**Tabs**:
1. **My Templates** - Templates created by coach
2. **Assigned** - Templates with at least 1 athlete
3. **Library** - Browse/import from public templates

```
┌─────────────────────────────────────┐
│ ← Template per Atleti          [+] │
├─────────────────────────────────────┤
│ [My] [Assigned] [Library]           │
├─────────────────────────────────────┤
│                                     │
│ ┌─────────────────────────────────┐ │
│ │ 🏋️ Push Day                     │ │
│ │ Chest, Shoulders, Triceps      │ │
│ │ 👥 3 atleti assegnati          │ │
│ │                    [Assegna →] │ │
│ └─────────────────────────────────┘ │
│                                     │
│ ┌─────────────────────────────────┐ │
│ │ 🦵 Leg Day                      │ │
│ │ Quads, Hamstrings, Calves      │ │
│ │ 👥 0 atleti assegnati          │ │
│ │                    [Assegna →] │ │
│ └─────────────────────────────────┘ │
│                                     │
└─────────────────────────────────────┘
```

### 2. CoachTemplateCard

**Location**: `lib/features/coach/presentation/widgets/coach_template_card.dart`

Features:
- Template name and muscle groups
- Badge with assigned athlete count
- Quick actions: Edit, Assign, Delete
- Swipe actions for quick access

### 3. TemplateAssignmentSheet

**Location**: `lib/features/coach/presentation/screens/template_assignment_sheet.dart`

```
┌─────────────────────────────────────┐
│ Assegna "Push Day"                  │
├─────────────────────────────────────┤
│                                     │
│ ATLETI ATTIVI (4)                  │
│                                     │
│ ┌─────────────────────────────────┐ │
│ │ ☑️ Giulia R.                    │ │
│ │    Già assegnato • 3 giorni fa │ │
│ └─────────────────────────────────┘ │
│ ┌─────────────────────────────────┐ │
│ │ ☐ Marco B.                      │ │
│ │    Non assegnato               │ │
│ └─────────────────────────────────┘ │
│ ┌─────────────────────────────────┐ │
│ │ ☑️ Sara T.                      │ │
│ │    Già assegnato • 1 giorno fa │ │
│ └─────────────────────────────────┘ │
│                                     │
├─────────────────────────────────────┤
│ ℹ️ Le modifiche al template si     │
│    propagheranno automaticamente   │
├─────────────────────────────────────┤
│                                     │
│  [Annulla]              [Salva]    │
│                                     │
└─────────────────────────────────────┘
```

### 4. Athlete Templates Tab (Athlete-side)

Add new tab in athlete's template screen showing assigned templates from coach.

```
┌─────────────────────────────────────┐
│ I Miei Template                     │
├─────────────────────────────────────┤
│ [My] [Dal Coach] [Discover]         │
├─────────────────────────────────────┤
│                                     │
│ 📋 DAL TUO COACH                    │
│                                     │
│ ┌─────────────────────────────────┐ │
│ │ 🏋️ Push Day                     │ │
│ │ Da: Coach Marco                │ │
│ │ Ultimo aggiornamento: oggi     │ │
│ │              [Inizia Workout]  │ │
│ └─────────────────────────────────┘ │
│                                     │
└─────────────────────────────────────┘
```

---

## Providers

```dart
// lib/features/coach/presentation/providers/coach_templates_provider.dart

/// All coach templates
final coachTemplatesProvider = StreamProvider<List<CoachTemplate>>((ref) {
  final userId = ref.watch(currentUserIdProvider);
  return ref.watch(coachTemplatesRepositoryProvider)
      .watchCoachTemplates(userId);
});

/// Templates assigned to at least one athlete
final assignedTemplatesProvider = Provider<List<CoachTemplate>>((ref) {
  final templates = ref.watch(coachTemplatesProvider).valueOrNull ?? [];
  return templates.where((t) => t.assignedTo.isNotEmpty).toList();
});

/// Assignment state for a specific template
final templateAssignmentProvider = FutureProvider.family<
    Map<String, bool>, String>((ref, templateId) async {
  final athletes = await ref.watch(athletesListProvider.future);
  final template = await ref.watch(coachTemplateProvider(templateId).future);

  return {
    for (final athlete in athletes)
      athlete.athleteId: template.assignedTo.contains(athlete.athleteId)
  };
});
```

---

## Repository

```dart
// lib/features/coach/data/repositories/coach_templates_repository.dart

class CoachTemplatesRepository {
  final FirebaseFirestore _firestore;

  /// Create a new coach template
  Future<String> createTemplate(CoachTemplate template);

  /// Update template (changes sync to athletes)
  Future<void> updateTemplate(CoachTemplate template);

  /// Delete template (removes from all athletes)
  Future<void> deleteTemplate(String templateId);

  /// Assign template to athletes
  Future<void> assignTemplate({
    required String templateId,
    required List<String> athleteIds,
  });

  /// Remove assignment from athletes
  Future<void> unassignTemplate({
    required String templateId,
    required List<String> athleteIds,
  });

  /// Watch coach templates
  Stream<List<CoachTemplate>> watchCoachTemplates(String coachId);

  /// Watch athlete's assigned templates
  Stream<List<AssignedTemplate>> watchAssignedTemplates(String athleteId);
}
```

---

## Firestore Security Rules

```javascript
// Coach templates - only coach can write
match /coachTemplates/{templateId} {
  allow read: if isAuthenticated() && (
    resource.data.coachId == request.auth.uid ||
    request.auth.uid in resource.data.assignedTo
  );
  allow write: if isAuthenticated() &&
    request.resource.data.coachId == request.auth.uid;
}

// Assigned templates - coach can assign, athlete can add notes
match /users/{userId}/assignedTemplates/{templateId} {
  allow read: if isAuthenticated() && request.auth.uid == userId;
  allow create, delete: if isAuthenticated() &&
    isCoachOf(userId); // Check coach relationship
  allow update: if isAuthenticated() &&
    request.auth.uid == userId &&
    onlyChanging(['athleteNotes']); // Athlete can only edit notes
}
```

---

## Navigation

Add routes in `app_routes.dart`:

```dart
// Coach templates library
static const coachTemplatesPath = '/coach/templates';
static const coachTemplatesName = 'coachTemplates';

// Template assignment
static const templateAssignmentPath = '/coach/templates/:templateId/assign';
static const templateAssignmentName = 'templateAssignment';
```

---

## Localization Keys

### English (app_en.arb)
```json
{
  "coachTemplates": "Templates for Athletes",
  "assignTemplate": "Assign Template",
  "assignedAthletes": "{count, plural, =0{No athletes} =1{1 athlete} other{{count} athletes}}",
  "assignTemplateToAthletes": "Assign \"{name}\" to:",
  "alreadyAssigned": "Already assigned",
  "notAssigned": "Not assigned",
  "changesWillSync": "Changes to this template will automatically sync to assigned athletes",
  "templateAssigned": "Template assigned successfully",
  "templateUnassigned": "Template removed from athlete",
  "fromYourCoach": "From Your Coach",
  "lastUpdated": "Last updated: {date}"
}
```

### Italian (app_it.arb)
```json
{
  "coachTemplates": "Template per Atleti",
  "assignTemplate": "Assegna Template",
  "assignedAthletes": "{count, plural, =0{Nessun atleta} =1{1 atleta} other{{count} atleti}}",
  "assignTemplateToAthletes": "Assegna \"{name}\" a:",
  "alreadyAssigned": "Già assegnato",
  "notAssigned": "Non assegnato",
  "changesWillSync": "Le modifiche a questo template verranno sincronizzate automaticamente agli atleti assegnati",
  "templateAssigned": "Template assegnato con successo",
  "templateUnassigned": "Template rimosso dall'atleta",
  "fromYourCoach": "Dal Tuo Coach",
  "lastUpdated": "Ultimo aggiornamento: {date}"
}
```

---

## Implementation Checklist

### Phase 1: Data Layer
- [ ] Create `CoachTemplate` entity with freezed
- [ ] Create `AssignedTemplate` entity with freezed
- [ ] Implement `CoachTemplatesRepository`
- [ ] Add Firestore security rules
- [ ] Write unit tests for repository

### Phase 2: Coach UI
- [ ] Create `CoachTemplatesScreen` with 3 tabs
- [ ] Create `CoachTemplateCard` widget
- [ ] Create `TemplateAssignmentSheet`
- [ ] Add providers for coach templates
- [ ] Add route in `app_routes.dart`
- [ ] Add button in `CoachDashboardScreen`
- [ ] Add localization keys IT/EN

### Phase 3: Athlete UI
- [ ] Add "From Coach" tab to athlete's templates
- [ ] Show assigned templates with coach info
- [ ] Allow starting workout from assigned template
- [ ] Add athlete notes field (optional)

### Phase 4: Polish
- [ ] Test dark/light mode
- [ ] Add loading states
- [ ] Add error handling
- [ ] Add empty states
- [ ] Performance optimization

---

## File Structure Summary

```
lib/features/coach/
├── domain/
│   └── entities/
│       ├── coach_template.dart          # NEW
│       └── assigned_template.dart       # NEW
├── data/
│   └── repositories/
│       └── coach_templates_repository.dart  # NEW
└── presentation/
    ├── screens/
    │   ├── coach_templates_screen.dart      # NEW
    │   └── template_assignment_sheet.dart   # NEW
    ├── widgets/
    │   ├── coach_template_card.dart         # NEW
    │   └── athlete_selection_list.dart      # NEW
    └── providers/
        └── coach_templates_provider.dart    # NEW
```

---

## Open Questions (for future iterations)

1. **Template versioning**: Should we track versions for audit?
2. **Bulk actions**: Assign multiple templates to multiple athletes?
3. **Scheduling**: Assign template to specific days/weeks?
4. **Notifications**: Notify athlete when template is assigned/updated?
5. **Offline support**: How to handle sync conflicts?

---

*Document created: 2025-06-15*
*Status: Ready for implementation*
