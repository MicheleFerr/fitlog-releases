# Report Analisi di Mercato - FitLog Pro
## Intelligenza Competitiva per la Versione Web

**Data**: 18 Gennaio 2026
**Analista**: Market Intelligence Specialist
**Obiettivo**: Identificare opportunità strategiche per il lancio della versione web di FitLog Pro

---

## Executive Summary

Il mercato delle app fitness sta vivendo una trasformazione verso **piattaforme ibride** (mobile + web), con particolare focus su:
- **Portali coach/trainer** come differenziatore chiave
- **Analitiche avanzate** e reportistica PDF
- **Modelli di monetizzazione ibridi** (subscription + features premium)
- Mercato italiano in crescita al **7.70% CAGR** (2025-2033), proiettato a raggiungere **$5.8 miliardi entro il 2033**

**Opportunità principale**: Solo **1 competitor su 6** (Hevy) offre un portale coach completo. **Gap di mercato enorme**.

---

## 1. ANALISI COMPETITOR - Presenza Web

### 1.1 Strong App
**Website**: [strong.app](https://www.strong.app/)

**Web Dashboard**: ⚠️ **Limitata**
- Sync cloud basic (solo backup dati)
- Nessun portale web vero e proprio
- Focus esclusivo su mobile (iOS/Android)
- Menzione di "lightweight web dashboard" ma senza dettagli pubblici

**Portale Coach**: ❌ **Assente**

**Pricing**:
- Modello freemium con limitazioni
- PRO unlock via mobile

**Features Uniche**:
- Interfaccia minimalista (selling point)
- Muscle heat maps
- Auto rest timer

**Gap Identificato**: Nessuna esperienza web per coach o atleti avanzati.

---

### 1.2 Hevy
**Website**: [hevyapp.com](https://www.hevyapp.com/) | [hevycoach.com](https://hevycoach.com/)

**Web Dashboard**: ✅ **Completa**
- Accesso web a [hevy.com](https://hevy.com)
- Review workouts, creazione routine, modifica profilo
- Analisi performance

**Portale Coach**: ✅ **Hevy Coach** (separato)
- **Trial**: 30 giorni gratuito (no carta credito)
- **Pricing**: Scalabile (da 1 a 500+ clienti), prezzo non pubblico
- **Features**:
  - Gestione clienti completa
  - Creazione e assegnazione programmi personalizzati
  - Monitoraggio progressi
  - Comunicazione integrata
  - Desktop-first interface per coach

**Modello Monetizzazione**:
- Coach pagano subscription
- Clienti usano Hevy **gratis** se seguiti da coach
- Modello B2B2C (business-to-trainer-to-consumer)

**Punti di Forza**:
- Unico competitor con ecosistema completo web + mobile
- Separazione chiara tra app atleta e portale coach
- Free trial generoso per coach

**Debolezza Potenziale**:
- Pricing non trasparente (richiede contatto)
- Due brand separati (Hevy vs Hevy Coach) = possibile confusione

---

### 1.3 Stronglifts 5x5
**Website**: [stronglifts.com](https://stronglifts.com/)

**Web Dashboard**: ❌ **Assente**
- Solo app mobile (iOS/Android + Apple Watch)
- Cloud sync opzionale
- Export dati per analisi esterna (Excel/Google Sheets)

**Portale Coach**: ❌ **Assente**

**Pricing**:
- Subscription obbligatoria dopo 7 giorni trial
- Focus su programma specifico (5x5)

**Features Uniche**:
- Programma rigido e strutturato
- Ottimo per principianti
- Export dati grezzo (CSV)

**Gap Identificato**: Zero presenza web, solo export manuale dati.

---

### 1.4 Gymshark Training
**Website**: [gymshark.com/pages/gymshark-app](https://www.gymshark.com/pages/gymshark-app)

**Web Dashboard**: ❌ **Assente**
- Solo mobile (iOS/Android)
- App gratuita (supporta brand di abbigliamento)

**Portale Coach**: ❌ **Assente**

**Modello**:
- Completamente gratuito
- Marketing tool per vendita merchandise

**Features**:
- Workout con Gymshark Athletes
- Programmi predefiniti
- Community features

**Posizionamento**: Content marketing, non competitor diretto per soluzioni B2B.

---

### 1.5 Fitbod
**Website**: [fitbod.me](https://fitbod.me/) | [app.fitbod.me](https://app.fitbod.me/)

**Web Dashboard**: ⚠️ **Limitata**
- Accesso a [app.fitbod.me](https://app.fitbod.me/)
- Principalmente per subscription e sync
- Possibile review workout da web (non confermato dettagli)

**Portale Coach**: ❌ **Assente**

**Pricing** (2026):
- **Mensile**: $15.99/mese
- **Annuale**: $95.99/anno (~$8/mese)
- Free trial: 3 workouts

**Features Uniche**:
- AI personalizzazione avanzata (algoritmo proprietario)
- Video dimostrativi high-quality
- Recovery-aware programming
- Offline mode completo

**Gap Identificato**: Focus su B2C individuale, zero strumenti per coach.

---

### 1.6 JEFIT
**Website**: [jefit.com](https://www.jefit.com/)

**Web Dashboard**: ✅ **Presente**
- Web app accessibile da desktop/laptop
- Online workout planner con sync mobile
- Setup workout plans, condivisione
- Cloud sync automatico cross-device

**Portale Coach**: ❌ **Assente**

**Features**:
- 1,300+ esercizi
- Progressive overload tracking
- Analytics avanzate
- Community features

**Pricing**: Modello freemium con premium tiers

**Punti di Forza**:
- Web planner ben sviluppato
- Database esercizi enorme
- Community attiva

**Gap Identificato**: Nessun portale dedicato coach, solo condivisione workout.

---

## 2. SINTESI COMPETITIVA

| Competitor | Web Dashboard | Portale Coach | Pricing Web | Differenziatore |
|-----------|---------------|---------------|-------------|-----------------|
| **Strong** | ⚠️ Basic sync | ❌ No | N/A | Semplicità UI |
| **Hevy** | ✅ Completa | ✅ Hevy Coach | Scalabile B2B | **LEADER** ecosistema web |
| **Stronglifts** | ❌ No | ❌ No | N/A | Programma 5x5 rigido |
| **Gymshark** | ❌ No | ❌ No | Gratis | Brand marketing |
| **Fitbod** | ⚠️ Limitata | ❌ No | $15.99/m | AI personalizzazione |
| **JEFIT** | ✅ Web planner | ❌ No | Freemium | Database esercizi |

### Insights Chiave:
1. **Solo Hevy** offre portale coach completo → **enorme gap di mercato**
2. **JEFIT** ha web planner ma senza funzionalità B2B
3. Maggioranza competitor = **mobile-only** o sync basico
4. **Nessuno** offre reportistica PDF nativa avanzata

---

## 3. USER PERSONAS - Target Versione Web

### Persona 1: "Marco - Il Coach Indipendente"

**Demografia**:
- Età: 28-42 anni
- Professione: Personal trainer freelance / Nutrizionista
- Educazione: Diploma CONI/Laurea Scienze Motorie
- Reddito: €25.000-€50.000/anno
- Località: Milano, Roma, Bologna (centri urbani)

**Contesto**:
- Gestisce 15-50 clienti contemporaneamente
- Lavora tra palestra, domicilio clienti, online
- Usa WhatsApp/email per comunicare con clienti (inefficiente)
- Crea schede in Excel o PDF statici

**Pain Points**:
- 😤 "Passo 2 ore al giorno a inviare schede e rispondere messaggi"
- 😤 "Non vedo i progressi dei clienti in tempo reale"
- 😤 "Ogni cliente usa un'app diversa, non ho controllo"
- 😤 "Le schede PDF sono statiche, devo rifarle ogni mese"
- 😤 "Non posso analizzare dati aggregati per migliorare programmazione"

**Goals**:
- ✅ Dashboard centralizzata per vedere tutti i clienti
- ✅ Assegnare programmi con 1 click
- ✅ Monitorare aderenza e progressi real-time
- ✅ Comunicare in-app (no WhatsApp personale)
- ✅ Generare report professionali per clienti

**Willingness to Pay**:
- €15-30/mese per 1-10 clienti
- €40-80/mese per 11-50 clienti
- **Disposto a pagare di più se** clienti possono usare app gratis

**Cosa Vuole dalla Versione Web**:
1. Desktop interface per creare programmi (più veloce che mobile)
2. Analytics dashboard (volume totale, aderenza %, PRs clienti)
3. Template library riutilizzabili
4. Export PDF branded con logo personale
5. Calendario overview tutti clienti

---

### Persona 2: "Sofia - L'Atleta Data-Driven"

**Demografia**:
- Età: 25-38 anni
- Professione: Manager, libera professionista, studentessa magistrale
- Reddito: €30.000-€60.000/anno
- Formazione: Laurea o superiore
- Località: Grandi città italiane

**Contesto**:
- Si allena 4-6 volte/settimana
- Segue programmi strutturati (powerlifting, CrossFit, bodybuilding)
- Tiene traccia di tutto: peso, reps, volume, sensazioni
- Frustrata da app che "non mostrano abbastanza dati"

**Pain Points**:
- 😤 "Voglio vedere grafici dettagliati ma sullo smartphone è scomodo"
- 😤 "Non posso esportare i miei dati per analisi personali"
- 😤 "Vorrei pianificare la settimana da PC, non da telefono"
- 😤 "Le app non mi fanno confrontare periodi di allenamento"

**Goals**:
- ✅ Vedere analytics avanzate su schermo grande
- ✅ Esportare workout history in PDF/Excel
- ✅ Pianificare mesocicli da web (interfaccia drag-drop)
- ✅ Comparare blocchi di allenamento (es. Ottobre vs Gennaio)
- ✅ Condividere progressi con coach via link

**Willingness to Pay**:
- €5-10/mese per versione base
- €12-18/mese per analytics avanzate + export
- **Zero** interesse se solo sync basico

**Cosa Vuole dalla Versione Web**:
1. Dashboard analytics con grafici interattivi (volume, intensità, frequenza)
2. Calendar view mensile/trimestrale
3. Export dati CSV/PDF per periodi custom
4. Workout planner drag-drop (desktop UX)
5. Comparazione periodi (A/B testing programmazione)

---

### Persona 3: "Giuseppe - Il Manager della Palestra"

**Demografia**:
- Età: 35-55 anni
- Ruolo: Titolare/Manager palestra, Responsabile trainer
- Dimensione struttura: 200-1000 iscritti, 3-15 trainer
- Località: Tutta Italia (piccoli centri inclusi)

**Contesto**:
- Supervisiona team di personal trainer
- Vuole offrire "servizi digitali premium" per fidelizzare iscritti
- Cerca soluzioni white-label o brandizzabili
- Budget per tecnologia: €200-€1000/mese

**Pain Points**:
- 😤 "Ogni trainer usa app diversa, nessuna coerenza"
- 😤 "Non ho visibilità su cosa fanno i trainer con i clienti"
- 😤 "Voglio offrire app 'della palestra' ma costi sviluppo proibitivi"
- 😤 "Iscritti chiedono servizi digitali, rischio perderli vs concorrenti"

**Goals**:
- ✅ Soluzione unica per tutti i trainer della palestra
- ✅ Branding personalizzato (logo, colori palestra)
- ✅ Dashboard admin per monitorare attività trainer
- ✅ Offrire valore aggiunto agli iscritti premium
- ✅ Reports aggregati per marketing (es. "1000 workout completati questo mese")

**Willingness to Pay**:
- €150-€400/mese per licenza palestra (trainer + clienti illimitati)
- Oppure €5-10/mese per trainer + revenue share

**Cosa Vuole dalla Versione Web**:
1. Admin dashboard multi-tenant (gestione trainer + clienti)
2. White-label branding (logo, colori, dominio custom opzionale)
3. Statistiche aggregate per marketing
4. Controllo permessi (cosa può fare ogni trainer)
5. Integrazione con gestionale palestra (opzionale)

---

### Persona 4: "Alessia - La Principiante Motivata"

**Demografia**:
- Età: 22-35 anni
- Occupazione: Impiegata, insegnante, professionista entry-level
- Reddito: €20.000-€35.000/anno
- Esperienza fitness: <1 anno allenamento strutturato

**Contesto**:
- Vuole "mettersi in forma" ma si sente persa
- Ha provato 3-4 app, troppe funzioni complesse
- Preferisce seguire programmi guidati
- Cerca motivazione e supporto

**Pain Points**:
- 😤 "Le app sono troppo complicate, troppe opzioni"
- 😤 "Non so se sto facendo progressi veri"
- 😤 "Vorrei un coach ma troppo costoso"
- 😤 "Sullo smartphone faccio fatica a capire gli esercizi"

**Goals**:
- ✅ Interfaccia semplice e guidata
- ✅ Video tutorial esercizi su schermo grande (web)
- ✅ Programmi "chiavi in mano" per principianti
- ✅ Feedback motivazionale
- ✅ Community supporto

**Willingness to Pay**:
- €0-5/mese (preferisce free o freemium)
- Disposta a pagare per coaching 1-1 se accessibile (€20-40/mese)

**Cosa Vuole dalla Versione Web**:
1. Video tutorial HD esercizi (meglio su desktop che mobile)
2. Programmi pre-impostati con spiegazioni chiare
3. Progress tracker visuale (gamification)
4. Chat support con trainer (se disponibile)
5. Biblioteca contenuti educativi

---

## 4. TOP 5 FEATURE DIFFERENZIANTI - Versione Web FitLog Pro

### Feature #1: **Portale Coach Professionale**
#### Descrizione
Dashboard web completa per personal trainer e coach, con gestione clienti, creazione programmi, analytics e comunicazione.

#### Perché Differenziante
- **Gap Competitor**: Solo Hevy ha questo, tutti gli altri ignorano il segmento B2B
- **Mercato Italiano**: Oltre 100.000 personal trainer in Italia (dato ISTAT 2024), molti lavorano freelance e cercano strumenti professionali
- **Recurring Revenue**: Coach pagano, clienti usano gratis → alta retention

#### Features Core
1. **Client Management**
   - Lista clienti con foto, dati, stato abbonamento
   - Note private per cliente
   - Tag/categorie (es. "Powerlifting", "Riabilitazione")

2. **Program Builder** (Desktop-First UX)
   - Drag-drop esercizi da database
   - Template salvabili e riutilizzabili
   - Clona programma tra clienti
   - Assegnazione calendario con date inizio/fine

3. **Real-Time Monitoring**
   - Dashboard overview: chi si è allenato oggi, aderenza settimanale
   - Notifiche quando cliente completa workout
   - Flag automatici: cliente fermo >7 giorni, mancato PRs da >4 settimane

4. **In-App Communication**
   - Chat 1-1 con cliente (evita WhatsApp personale)
   - Invio note post-workout
   - Commenti su singoli esercizi

5. **Analytics & Reporting**
   - Grafici progressi cliente (volume, intensità, frequenza)
   - Export PDF report mensili branded
   - Comparazione clienti (chi progredisce di più)

#### Monetizzazione
- **Tier 1**: €19/mese (1-10 clienti)
- **Tier 2**: €49/mese (11-30 clienti)
- **Tier 3**: €99/mese (31-100 clienti)
- Clienti usano FitLog app **gratis** se collegati a coach

---

### Feature #2: **Analytics Dashboard Avanzate**
#### Descrizione
Visualizzazioni dati interattive, grafici drill-down, comparazioni temporali, export dati — ottimizzato per schermo desktop.

#### Perché Differenziante
- **Gap Competitor**: Fitbod ha analytics AI ma solo mobile; Strong ha muscle maps basiche
- **Personas Target**: Sofia (atleta data-driven) e Marco (coach che vuole insights)
- **Sticky Feature**: Utenti con storico dati >6 mesi non cambiano app (lock-in)

#### Features Core
1. **Performance Dashboard**
   - Grafici volume (tonnellaggio) settimanale/mensile/annuale
   - Intensity tracker (% 1RM medio)
   - Frequency heatmap (giorni allenamento)
   - PRs timeline con annotazioni

2. **Body Part Analysis**
   - Volume per muscolo (interattivo, click per dettagli)
   - Bilanciamento push/pull/legs
   - Alert squilibri (es. "Chest volume 3x > Back")

3. **Program Effectiveness**
   - Comparazione blocchi: Mesociclo A vs B
   - Correlation analysis: volume → PRs
   - Deload tracking e recovery metrics

4. **Export & Share**
   - Export CSV dati grezzi (per Excel pivot table)
   - PDF report con grafici + statistiche
   - Link condivisione pubblico (opzionale, per social)

#### Visualizzazioni Chiave
- Line charts (progressione nel tempo)
- Bar charts (confronti esercizi/periodi)
- Heatmaps (frequenza, intensità)
- Scatter plots (correlazioni)

#### Monetizzazione
- **Free**: Grafici basici ultimi 3 mesi
- **Pro**: ($9/mese) Storico illimitato, export, comparazioni
- **Coach**: Incluso in subscription coach

---

### Feature #3: **Workout Planner Drag-Drop (Desktop)**
#### Descrizione
Editor visuale per pianificare settimane/mesi di allenamento con interfaccia drag-drop, ottimizzato per desktop.

#### Perché Differenziante
- **UX Gap**: Tutti i competitor hanno planning su mobile (scomodo per mesocicli complessi)
- **Productivity**: Coach/atleti avanzati possono programmare 4-12 settimane in 20 minuti vs 2 ore su mobile
- **Professional Feel**: Interfaccia simile a Google Calendar, familiare

#### Features Core
1. **Calendar View**
   - Vista mensile/trimestrale
   - Drag-drop workout tra giorni
   - Colori per tipo allenamento (Upper/Lower, Push/Pull/Legs, etc.)
   - Bulk operations: copia settimana, duplica mesociclo

2. **Template Library**
   - Salvare workout come template
   - Folder organization (es. "Forza", "Ipertrofia", "Deload")
   - Quick insert da library
   - Template condivisi community (opzionale)

3. **Program Phasing**
   - Definire fasi: Accumulo, Intensificazione, Peak, Deload
   - Auto-adjust volume/intensità per fase
   - Progression rules (es. "+2.5kg/settimana su Squat")

4. **Smart Suggestions**
   - AI suggestion esercizi basata su storico
   - Balance checker: "Hai fatto 4x Chest, 0x Back questa settimana"
   - Recovery alerts: "Hai programmato 3 leg days in 4 giorni"

#### Desktop UX Advantage
- Multi-monitor support (planner + analytics su 2 schermi)
- Keyboard shortcuts (Ctrl+C/V workout, Ctrl+D duplica giorno)
- Sidebar con database esercizi sempre visibile
- Hover tooltips con dettagli esercizio

#### Monetizzazione
- **Free**: Planning 1 settimana in avanti
- **Pro**: Planning illimitato + template library
- **Coach**: Illimitato + assign ai clienti

---

### Feature #4: **Report PDF Professionali Branded**
#### Descrizione
Generazione automatica report PDF personalizzati con logo, grafici, statistiche — per atleti che vogliono documentare progressi o coach che offrono servizi premium.

#### Perché Differenziante
- **Gap Enorme**: Nessun competitor offre PDF reports nativi (solo export CSV grezzo)
- **Use Cases Multipli**:
  - Atleta: condivide con medico/fisioterapista
  - Coach: deliverable mensile per giustificare costo coaching
  - Palestra: report "fine anno" per iscritti premium
- **Perceived Value**: PDF professionale = servizio premium

#### Features Core
1. **Report Templates**
   - **Progress Report**: Grafici PRs, volume, foto progressi
   - **Monthly Summary**: Giorni allenati, esercizi top, records
   - **Program Review**: Analisi mesociclo completato
   - **Client Onboarding**: Dati baseline + obiettivi

2. **Customization**
   - Logo upload (coach o palestra)
   - Color scheme personalizzato
   - Footer con contatti/social
   - Watermark opzionale

3. **Content Blocks** (Drag-Drop)
   - Grafici performance
   - Tabelle PRs
   - Body measurements (peso, circonferenze)
   - Progress photos comparison
   - Note coach/atleta
   - Obiettivi next month

4. **Auto-Generation**
   - Scheduled: report automatico ogni 30 giorni
   - Trigger: fine mesociclo, milestone raggiunto
   - Email delivery al cliente

#### Design Professionale
- A4 format, print-ready
- High-res grafici (300dpi)
- Bilingual: Italiano + Inglese
- ATS-friendly (se usato per certificazioni)

#### Monetizzazione
- **Free**: 1 report basico/mese
- **Pro**: Report illimitati + branding
- **Coach**: Branding + auto-send clienti

---

### Feature #5: **Integrazione Ecosistema Fitness**
#### Descrizione
Connessioni bidirezionali con wearables (Garmin, Apple Health, Whoop), app nutrizione (MyFitnessPal), piattaforme video (YouTube form checks) — tutto visualizzato in un'unica dashboard web.

#### Perché Differenziante
- **Trend 2026**: Utenti vogliono "single source of truth" per tutti i dati salute
- **Coach Value**: Vedere workout + sonno + nutrizione + stress in 1 schermo
- **Network Effects**: Più integrazioni = più difficile cambiare app

#### Features Core
1. **Wearable Sync**
   - Import: Passi, sonno, HRV, calorie bruciate
   - Export: Workout completati → Apple Health/Google Fit
   - Dashboard unificata: "Hai dormito 5h, oggi deload consigliato"

2. **Nutrition Integration**
   - Connect MyFitnessPal, Yazio, Lifesum
   - Overlay: Calorie consumate vs bruciate in allenamento
   - Macro tracking + workout volume (per coach bodybuilding)

3. **Video Form Check**
   - Upload video esercizio da mobile
   - Review su web (schermo grande, slow-motion)
   - Annotazioni frame-by-frame (coach)
   - Library video progressi (confronta tecnica mese 1 vs mese 6)

4. **Recovery Metrics**
   - Import HRV da Whoop/Oura
   - Correlazione HRV bassa → performance allenamento
   - Readiness score → suggerimento autoregolazione

5. **API Aperte**
   - Webhook per sviluppatori terze parti
   - Export dati via API (per software gestionali palestre)
   - Zapier integration (automazioni custom)

#### Dashboard Unificata (Web Only)
- **Left Panel**: Workout logs
- **Center**: Grafici performance
- **Right Panel**: Metrics correlate (sonno, HRV, peso, calorie)
- Click su qualsiasi punto → drill-down dettagli

#### Monetizzazione
- **Free**: 2 integrazioni (es. Apple Health + MyFitnessPal)
- **Pro**: Integrazioni illimitate
- **Coach**: Illimitate + API access

---

## 5. PRICING STRATEGY CONSIGLIATA

### Modello Ibrido (B2C + B2B2C)

#### Tier Consumer (B2C)
| Piano | Prezzo | Features |
|-------|--------|----------|
| **Free** | €0 | App mobile, workout tracking basic, 3 mesi storico |
| **Pro** | €8.99/mese o €79/anno | Storico illimitato, analytics avanzate, export PDF (1/mese), web dashboard, 2 integrazioni |
| **Ultimate** | €14.99/mese o €129/anno | Tutto Pro + report PDF illimitati, AI suggestions, video form checks, integrazioni illimitate |

#### Tier Coach (B2B2C)
| Piano | Prezzo | Clienti | Features |
|-------|--------|---------|----------|
| **Starter Coach** | €19/mese | 1-10 | Dashboard coach, client management, program builder, chat, analytics base |
| **Pro Coach** | €49/mese | 11-30 | Tutto Starter + report PDF branded, template library, auto-scheduling |
| **Studio Coach** | €99/mese | 31-100 | Tutto Pro + white-label, sub-accounts trainer, API access |
| **Enterprise** | Custom | 100+ | Multi-location, custom integrations, SLA support |

**Nota**: Clienti collegati a coach usano app **gratis** (no subscription).

#### Tier Palestre (B2B)
- **Gym License**: €199-€499/mese (trainer illimitati + 200-1000 iscritti)
- White-label completo: logo, colori, dominio custom
- Admin dashboard multi-tenant
- Onboarding e training inclusi

### Benchmark Competitor
- **Hevy Coach**: Pricing non pubblico, stimato €30-80/mese
- **Fitbod**: €15.99/mese (solo B2C)
- **TrueCoach** (non analizzato ma noto): $20-$99/mese per coach

**Posizionamento FitLog**: Premium ma competitivo, focus su **value for money** mercato italiano.

---

## 6. GO-TO-MARKET RECOMMENDATIONS

### Fase 1: MVP Web (3-4 mesi)
**Target**: Validare con early adopters

**Features Minime**:
1. Portale coach base (gestione clienti, assegnazione programmi)
2. Analytics dashboard atleti (grafici volume, PRs)
3. Export PDF semplice
4. Sync mobile-web real-time

**Test Utenti**:
- 10-15 personal trainer freelance (Milano, Roma)
- 30-50 atleti beta tester
- Pricing: 50% sconto primi 6 mesi

### Fase 2: Feature Rollout (6 mesi)
**Ordine Implementazione** (per ROI):
1. **Report PDF Branded** → High perceived value, low dev cost
2. **Workout Planner Drag-Drop** → Differenziatore UX
3. **Integrazioni Wearables** → Richiesta da utenti attuali
4. **White-Label Palestre** → High ticket B2B

### Fase 3: Scale (12+ mesi)
- Programma affiliazione coach (referral 20% recurring)
- Marketplace template workout (coach vendono programmi)
- API pubbliche per integrazioni terze parti

### Canali Marketing Prioritari
1. **Coach Outreach**: LinkedIn, Instagram fitness influencers Italia
2. **SEO**: "software gestione clienti personal trainer", "app allenamento per coach"
3. **Content**: Blog guide "come diventare PT digitale", "analizzare progressi clienti"
4. **Partnerships**: Scuole formazione PT (CONI, ISSA Italia), palestre catene

---

## 7. CONCLUSIONI & NEXT STEPS

### Opportunità Strategiche
1. **Gap Portale Coach**: Solo Hevy compete, mercato italiano sotto-servito
2. **Desktop UX**: Competitor mobile-first, FitLog può dominare planning/analytics desktop
3. **Report PDF**: Zero competitor, alta domanda, basso costo sviluppo
4. **Mercato Italiano**: Crescita 7.7% CAGR, pochi player locali forti

### Rischi & Mitigazioni
| Rischio | Probabilità | Impatto | Mitigazione |
|---------|-------------|---------|-------------|
| Hevy lancia versione IT | Media | Alto | First-mover advantage, focus localizzazione |
| Coach non vogliono pagare | Bassa | Alto | Freemium tier, trial 60 giorni |
| Complessità dev web | Alta | Medio | MVP snello, iterazioni rapide |
| Cannibalizzazione app mobile | Bassa | Basso | Web complementare, non sostitutivo |

### KPI Successo (12 mesi)
- **50+** coach paganti
- **500+** atleti attivi su web
- **MRR €3,000+** da subscriptions web
- **NPS 50+** tra coach
- **Retention 80%+** coach dopo 6 mesi

### Decision Points
**Go**: Se MVP validato con 10+ coach paganti in 90 giorni
**Pivot**: Se < 30% beta tester usa web dopo 60 giorni
**Kill**: Se CAC > €200 e LTV < €500 dopo 6 mesi

---

## APPENDICI

### A. Fonti & Link Utili

**Competitor Analysis**:
- [Strong App Review 2026](https://www.prpath.app/blog/strong-app-review-2026.html)
- [Hevy Coach Pricing](https://hevycoach.com/pricing/)
- [Fitbod Review 2026](https://fitnessdrum.com/fitbod-review/)
- [JEFIT Official Site](https://www.jefit.com/)

**Market Research**:
- [Italy Fitness Market Forecast](https://www.statista.com/outlook/hmo/digital-health/digital-fitness-well-being/fitness-apps/italy)
- [Fitness App Revenue Statistics 2026](https://www.businessofapps.com/data/fitness-app-market/)
- [Top Fitness App Features 2026](https://www.mmfinfotech.com/blog/top-fitness-wellness-app-features-2026/)

**User Research**:
- [Fitness App User Personas](https://fastercapital.com/keyword/personal-fitness-goals-and-target-audience-and-pain-points.html)
- [Customer Pain Points Fitness Apps](https://www.linkedin.com/advice/0/what-some-common-customer-pain-points-1c)

**Trends & Monetization**:
- [Fitness App Monetization 2026](https://attractgroup.com/blog/fitness-app-development-in-2026-key-features-monetization-models-and-cost-estimates/)
- [Coach Training Software Review](https://www.garagegymreviews.com/best-personal-training-apps)

### B. Glossario Termini
- **B2B2C**: Business-to-Business-to-Consumer (coach paga, atleta usa gratis)
- **CAC**: Customer Acquisition Cost
- **LTV**: Lifetime Value
- **MRR**: Monthly Recurring Revenue
- **NPS**: Net Promoter Score
- **Mesociclo**: Blocco allenamento 4-12 settimane
- **Deload**: Settimana scarico volume/intensità
- **Progressive Overload**: Aumento graduale carico/volume
- **HRV**: Heart Rate Variability (indicatore recovery)

### C. Template Feature Spec (Esempio)
```markdown
## Feature: Report PDF Branded

**User Story**: Come coach, voglio generare report PDF con il mio logo per inviare ai clienti ogni mese e dimostrare valore del mio servizio.

**Acceptance Criteria**:
- [ ] Upload logo (PNG/JPG, max 2MB)
- [ ] Scelta color scheme (3 preset + custom)
- [ ] Selezione content blocks (drag-drop)
- [ ] Preview PDF prima di generare
- [ ] Download PDF o email automatica
- [ ] Template salvabili (riutilizzo)

**Technical Notes**:
- Library: PDFKit o jsPDF
- Max 10 pagine per report
- A4 format, 300dpi grafici

**Success Metrics**:
- 60% coach genera almeno 1 report/mese
- Tempo medio generazione < 5 minuti
- Customer satisfaction: 4.5/5 stars
```

---

**Fine Report**

Per domande o approfondimenti: contattare il team Product Strategy.
